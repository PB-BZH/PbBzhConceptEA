//+------------------------------------------------------------------+
//|                        PbBzhConceptEA_v2_00.mq5                   |
//|     v2.00 : observation Donchian + ATR, sans position            |
//+------------------------------------------------------------------+
#property copyright "Copyright 2026, PbBzhConcept"
#property version   "2.00"
#property strict
#property description "Recherche : cassures Donchian et volatilité ATR"
#property description "Mode observation uniquement : aucune position"

#include <PbBzhConcept\Signals\DonchianBreakoutSignal.mqh>

input group "Général"
input ENUM_TIMEFRAMES InpSignalTimeframe = PERIOD_H1;

input group "Canaux de Donchian"
input int InpEntryChannelPeriod = 20;
input int InpExitChannelPeriod = 10;

input group "Volatilité"
input int InpAtrPeriod = 14;

input group "Affichage"
input bool InpShowEntryChannel = true;
input bool InpShowExitChannel = true;
input bool InpShowBreakoutArrows = true;
input double InpArrowOffsetAtr = 0.20;
input color InpEntryUpperColor = clrLimeGreen;
input color InpEntryLowerColor = clrTomato;
input color InpExitChannelColor = clrGold;
input color InpBuyArrowColor = clrLimeGreen;
input color InpSellArrowColor = clrTomato;

CDonchianBreakoutSignal g_breakoutSignal;
datetime g_currentBarTime = 0;

string g_objectPrefix = "PB2_";
string g_entryUpperName = "PB2_ENTRY_UPPER";
string g_entryLowerName = "PB2_ENTRY_LOWER";
string g_exitUpperName = "PB2_EXIT_UPPER";
string g_exitLowerName = "PB2_EXIT_LOWER";


//+------------------------------------------------------------------+
//| Met à jour une ligne horizontale                                  |
//+------------------------------------------------------------------+
void UpdateHorizontalLine(
  const string objectName,
  const double price,
  const color lineColor,
  const ENUM_LINE_STYLE lineStyle,
  const int lineWidth) {

  if (ObjectFind(0, objectName) < 0) {
    if (!ObjectCreate(
      0,
      objectName,
      OBJ_HLINE,
      0,
      0,
      price)) {

      PrintFormat(
        "[PbBzhConceptEA v2.00][ERROR] "
        "Création objet %s impossible. Erreur=%d",
        objectName,
        GetLastError());

      return;
    }
  }

  ObjectSetDouble(
    0,
    objectName,
    OBJPROP_PRICE,
    price);

  ObjectSetInteger(
    0,
    objectName,
    OBJPROP_COLOR,
    lineColor);

  ObjectSetInteger(
    0,
    objectName,
    OBJPROP_STYLE,
    lineStyle);

  ObjectSetInteger(
    0,
    objectName,
    OBJPROP_WIDTH,
    lineWidth);

  ObjectSetInteger(
    0,
    objectName,
    OBJPROP_BACK,
    true);

  ObjectSetInteger(
    0,
    objectName,
    OBJPROP_SELECTABLE,
    false);
}


//+------------------------------------------------------------------+
//| Dessine une flèche sur la bougie de cassure                       |
//+------------------------------------------------------------------+
void DrawBreakoutArrow(
  const SPbDonchianSnapshot &snapshot) {

  if (!InpShowBreakoutArrows ||
    snapshot.signal == PB_BREAKOUT_NONE) {

    return;
  }

  string directionText = BreakoutSignalToString(
    snapshot.signal);

  string objectName = StringFormat(
    "%s%s_%I64d",
    g_objectPrefix,
    directionText,
    (long)snapshot.signalBarTime);

  if (ObjectFind(0, objectName) >= 0)
    return;

  ENUM_OBJECT objectType =
    snapshot.signal == PB_BREAKOUT_BUY
    ? OBJ_ARROW_BUY
    : OBJ_ARROW_SELL;

  double offset = snapshot.atrPrice *
    MathMax(0.0, InpArrowOffsetAtr);

  double arrowPrice =
    snapshot.signal == PB_BREAKOUT_BUY
    ? snapshot.signalLow - offset
    : snapshot.signalHigh + offset;

  if (!ObjectCreate(
    0,
    objectName,
    objectType,
    0,
    snapshot.signalBarTime,
    arrowPrice)) {

    PrintFormat(
      "[PbBzhConceptEA v2.00][ERROR] "
      "Création flèche %s impossible. Erreur=%d",
      objectName,
      GetLastError());

    return;
  }

  ObjectSetInteger(
    0,
    objectName,
    OBJPROP_COLOR,
    snapshot.signal == PB_BREAKOUT_BUY
    ? InpBuyArrowColor
    : InpSellArrowColor);

  ObjectSetInteger(
    0,
    objectName,
    OBJPROP_WIDTH,
    2);

  ObjectSetInteger(
    0,
    objectName,
    OBJPROP_SELECTABLE,
    false);
}


//+------------------------------------------------------------------+
//| Met à jour l'affichage du dernier état                            |
//+------------------------------------------------------------------+
void UpdateChartDisplay(
  const SPbDonchianSnapshot &snapshot) {

  if (InpShowEntryChannel) {
    UpdateHorizontalLine(
      g_entryUpperName,
      snapshot.entryUpper,
      InpEntryUpperColor,
      STYLE_SOLID,
      2);

    UpdateHorizontalLine(
      g_entryLowerName,
      snapshot.entryLower,
      InpEntryLowerColor,
      STYLE_SOLID,
      2);
  }
  else {
    ObjectDelete(0, g_entryUpperName);
    ObjectDelete(0, g_entryLowerName);
  }

  if (InpShowExitChannel) {
    UpdateHorizontalLine(
      g_exitUpperName,
      snapshot.exitUpper,
      InpExitChannelColor,
      STYLE_DASH,
      1);

    UpdateHorizontalLine(
      g_exitLowerName,
      snapshot.exitLower,
      InpExitChannelColor,
      STYLE_DASH,
      1);
  }
  else {
    ObjectDelete(0, g_exitUpperName);
    ObjectDelete(0, g_exitLowerName);
  }

  DrawBreakoutArrow(snapshot);

  Comment(
    "PbBzhConceptEA v2.00 — OBSERVATION\n",
    "Symbole : ", _Symbol,
    " | UT : ", EnumToString(InpSignalTimeframe), "\n",
    "Bougie clôturée : ",
    TimeToString(snapshot.signalBarTime, TIME_DATE|TIME_MINUTES), "\n",
    "Signal : ", BreakoutSignalToString(snapshot.signal), "\n",
    "Clôture : ", DoubleToString(snapshot.signalClose, _Digits), "\n",
    "Donchian entrée ", InpEntryChannelPeriod,
    " : ", DoubleToString(snapshot.entryLower, _Digits),
    " / ", DoubleToString(snapshot.entryUpper, _Digits), "\n",
    "Donchian sortie ", InpExitChannelPeriod,
    " : ", DoubleToString(snapshot.exitLower, _Digits),
    " / ", DoubleToString(snapshot.exitUpper, _Digits), "\n",
    "ATR(", InpAtrPeriod, ") : ",
    DoubleToString(snapshot.atrPoints, 1), " points\n",
    "Largeur canal entrée : ",
    DoubleToString(snapshot.entryChannelWidthPoints, 1),
    " points = ",
    DoubleToString(snapshot.entryChannelWidthAtr, 2),
    " ATR\n",
    "Aucune position n'est ouverte dans cette version.");
}


//+------------------------------------------------------------------+
//| Traite la dernière bougie clôturée                                |
//+------------------------------------------------------------------+
void ProcessClosedBar(void) {
  SPbDonchianSnapshot snapshot;

  if (!g_breakoutSignal.EvaluateClosedBar(snapshot) ||
    !snapshot.isValid) {

    return;
  }

  UpdateChartDisplay(snapshot);

  PrintFormat(
    "[PbBzhConceptEA v2.00][INFO] "
    "OBSERVATION | Temps=%s | Signal=%s | "
    "O=%.5f H=%.5f L=%.5f C=%.5f | "
    "EntréeBas=%.5f | EntréeHaut=%.5f | "
    "SortieBas=%.5f | SortieHaut=%.5f | "
    "ATR=%.1f points | Largeur=%.2f ATR",

    TimeToString(
      snapshot.signalBarTime,
      TIME_DATE|TIME_MINUTES),

    BreakoutSignalToString(
      snapshot.signal),

    snapshot.signalOpen,
    snapshot.signalHigh,
    snapshot.signalLow,
    snapshot.signalClose,
    snapshot.entryLower,
    snapshot.entryUpper,
    snapshot.exitLower,
    snapshot.exitUpper,
    snapshot.atrPoints,
    snapshot.entryChannelWidthAtr);
}


//+------------------------------------------------------------------+
//| Vérifie l'apparition d'une nouvelle bougie                        |
//+------------------------------------------------------------------+
bool IsNewBar(void) {
  datetime currentBarTime = iTime(
    _Symbol,
    InpSignalTimeframe,
    0);

  if (currentBarTime <= 0)
    return false;

  if (g_currentBarTime == 0) {
    g_currentBarTime = currentBarTime;
    return true;
  }

  if (currentBarTime == g_currentBarTime)
    return false;

  g_currentBarTime = currentBarTime;
  return true;
}


//+------------------------------------------------------------------+
//| Initialisation                                                    |
//+------------------------------------------------------------------+
int OnInit(void) {
  if (!g_breakoutSignal.Initialize(
    _Symbol,
    InpSignalTimeframe,
    InpEntryChannelPeriod,
    InpExitChannelPeriod,
    InpAtrPeriod)) {

    return INIT_FAILED;
  }

  PrintFormat(
    "[PbBzhConceptEA v2.00][INFO] "
    "DÉMARRAGE | Symbole=%s | UT=%s | "
    "Donchian entrée=%d | Donchian sortie=%d | "
    "ATR=%d | Mode=OBSERVATION",

    _Symbol,
    EnumToString(InpSignalTimeframe),
    InpEntryChannelPeriod,
    InpExitChannelPeriod,
    InpAtrPeriod);

  g_currentBarTime = 0;
  return INIT_SUCCEEDED;
}


//+------------------------------------------------------------------+
//| Désinitialisation                                                 |
//+------------------------------------------------------------------+
void OnDeinit(const int reason) {
  g_breakoutSignal.Release();
  ObjectsDeleteAll(0, g_objectPrefix);
  Comment("");

  PrintFormat(
    "[PbBzhConceptEA v2.00][INFO] "
    "ARRÊT | Raison=%d",
    reason);
}


//+------------------------------------------------------------------+
//| Tick                                                              |
//+------------------------------------------------------------------+
void OnTick(void) {
  if (!IsNewBar())
    return;

  ProcessClosedBar();
}
