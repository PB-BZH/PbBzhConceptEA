PbBzhConceptEA v2.00 — Donchian / ATR Observer
================================================

Cette première étape de la version 2.00 ne simule aucune position.
Elle valide uniquement :
- le canal d'entrée Donchian ;
- le canal de sortie Donchian ;
- la détection d'une cassure confirmée par clôture ;
- l'ATR et la largeur du canal normalisée par l'ATR.

Installation :
1. Copier Experts/PbBzhConcept/PbBzhConceptEA_v2_00.mq5
   dans MQL5/Experts/PbBzhConcept/.
2. Copier Include/PbBzhConcept/Signals/DonchianBreakoutSignal.mqh
   dans MQL5/Include/PbBzhConcept/Signals/.
3. Compiler PbBzhConceptEA_v2_00.mq5.

Paramètres de départ :
- unité de temps : H1 ;
- canal d'entrée : 20 bougies ;
- canal de sortie : 10 bougies ;
- ATR : 14 périodes.

Important : les canaux de la bougie [1] sont calculés uniquement à partir
 des bougies [2] et antérieures. Il n'y a donc pas d'anticipation de la
 bougie utilisée pour confirmer la cassure.
