//+------------------------------------------------------------------+
//|                        PbBzhConceptEA_v2_03.mq5                   |
//|  v2.03 : filtre de régime haussier D1 par EMA                   |
//+------------------------------------------------------------------+
#property copyright "Copyright 2026, PbBzhConcept"
#property version   "2.03"
#property strict
#property description "Recherche : cassures Donchian avec position virtuelle"
#property description "SL initial ATR, aucun TP, sorties Donchian/Chandelier"
#property description "Filtre LONG : clôture D1 au-dessus d'une EMA ascendante"

#include <PbBzhConcept\Signals\DonchianBreakoutSignal.mqh>
#include <PbBzhConcept\Simulation\VirtualDonchianPositionManager.mqh>

enum ENUM_PB_V2_DIRECTION_MODE {
  PB_V2_DIRECTION_LONG_ONLY = 0,
  PB_V2_DIRECTION_SHORT_ONLY,
  PB_V2_DIRECTION_BOTH
};

string V2DirectionModeToString(
  const ENUM_PB_V2_DIRECTION_MODE mode) {

  switch (mode) {
    case PB_V2_DIRECTION_LONG_ONLY:
      return "LONG_ONLY";

    case PB_V2_DIRECTION_SHORT_ONLY:
      return "SHORT_ONLY";

    case PB_V2_DIRECTION_BOTH:
    default:
      return "BOTH";
  }
}

input group "Général"
input ENUM_TIMEFRAMES InpSignalTimeframe = PERIOD_H1;
input ENUM_PB_V2_DIRECTION_MODE InpDirectionMode = PB_V2_DIRECTION_LONG_ONLY;

input group "Canaux de Donchian"
input int InpEntryChannelPeriod = 20;
input int InpExitChannelPeriod = 10;

input group "Volatilité et protection"
input int InpAtrPeriod = 14;
input double InpInitialStopAtrMultiplier = 2.00;
input ENUM_PB_V2_EXIT_MODE InpExitMode = PB_V2_EXIT_CHANDELIER_ONLY;
input double InpChandelierAtrMultiplier = 3.00;

input group "Filtre de tendance LONG"
input bool InpUseTrendFilter = true;
input ENUM_TIMEFRAMES InpTrendTimeframe = PERIOD_D1;
input int InpTrendMaPeriod = 200;
input int InpTrendSlopeLookback = 20;

input group "Simulation virtuelle"
input double InpInitialCapital = 10000.00;
input double InpRiskPercent = 1.00;

input group "Affichage"
input bool InpShowEntryChannel = true;
input bool InpShowExitChannel = true;
input bool InpShowBreakoutArrows = true;
input bool InpShowVirtualPositionLevels = true;
input double InpArrowOffsetAtr = 0.20;
input color InpEntryUpperColor = clrLimeGreen;
input color InpEntryLowerColor = clrTomato;
input color InpExitChannelColor = clrGold;
input color InpBuyArrowColor = clrLimeGreen;
input color InpSellArrowColor = clrTomato;
input color InpVirtualEntryColor = clrDeepSkyBlue;
input color InpVirtualStopColor = clrMagenta;

CDonchianBreakoutSignal g_breakoutSignal;
CVirtualDonchianPositionManager g_virtualPosition;

datetime g_currentBarTime = 0;
bool g_hasLastSnapshot = false;
SPbDonchianSnapshot g_lastSnapshot;

long g_processedBarCount = 0;
long g_buyBreakoutCount = 0;
long g_sellBreakoutCount = 0;
long g_longTrendAcceptedCount = 0;
long g_longTrendRejectedCount = 0;

int g_trendMaHandle = INVALID_HANDLE;

string g_objectPrefix = "PB203_";
string g_entryUpperName = "PB203_ENTRY_UPPER";
string g_entryLowerName = "PB203_ENTRY_LOWER";
string g_exitUpperName = "PB203_EXIT_UPPER";
string g_exitLowerName = "PB203_EXIT_LOWER";
string g_virtualEntryName = "PB203_VIRTUAL_ENTRY";
string g_virtualStopName = "PB203_VIRTUAL_STOP";


//+------------------------------------------------------------------+
//| Initialise le filtre de tendance LONG                            |
//+------------------------------------------------------------------+
bool InitializeLongTrendFilter(void) {
  if (!InpUseTrendFilter)
    return true;

  if (InpTrendMaPeriod < 2 ||
    InpTrendSlopeLookback < 1) {

    PrintFormat(
      "[PbBzhConceptEA v2.03][ERROR] "
      "Paramètres du filtre invalides : "
      "Période EMA=%d | Recul pente=%d",
      InpTrendMaPeriod,
      InpTrendSlopeLookback);

    return false;
  }

  g_trendMaHandle = iMA(
    _Symbol,
    InpTrendTimeframe,
    InpTrendMaPeriod,
    0,
    MODE_EMA,
    PRICE_CLOSE);

  if (g_trendMaHandle == INVALID_HANDLE) {
    PrintFormat(
      "[PbBzhConceptEA v2.03][ERROR] "
      "Création de l'EMA de tendance impossible. Erreur=%d",
      GetLastError());

    return false;
  }

  return true;
}


//+------------------------------------------------------------------+
//| Vérifie le régime haussier sur des données entièrement clôturées |
//+------------------------------------------------------------------+
bool IsLongTrendAllowed(
  double &closedTrendPrice,
  double &currentTrendMa,
  double &pastTrendMa,
  string &reason) {

  closedTrendPrice = 0.0;
  currentTrendMa = 0.0;
  pastTrendMa = 0.0;
  reason = "FILTRE_DÉSACTIVÉ";

  if (!InpUseTrendFilter)
    return true;

  if (g_trendMaHandle == INVALID_HANDLE) {
    reason = "HANDLE_EMA_INVALIDE";
    return false;
  }

  // Décalage 1 : dernière bougie de tendance entièrement clôturée.
  closedTrendPrice = iClose(
    _Symbol,
    InpTrendTimeframe,
    1);

  double currentMaBuffer[1];
  double pastMaBuffer[1];

  ResetLastError();

  if (closedTrendPrice <= 0.0 ||
    CopyBuffer(
      g_trendMaHandle,
      0,
      1,
      1,
      currentMaBuffer) != 1 ||
    CopyBuffer(
      g_trendMaHandle,
      0,
      1 + InpTrendSlopeLookback,
      1,
      pastMaBuffer) != 1) {

    reason = StringFormat(
      "DONNÉES_TENDANCE_INDISPONIBLES_%d",
      GetLastError());

    return false;
  }

  currentTrendMa = currentMaBuffer[0];
  pastTrendMa = pastMaBuffer[0];

  if (closedTrendPrice <= currentTrendMa) {
    reason = "CLÔTURE_SOUS_EMA";
    return false;
  }

  if (currentTrendMa <= pastTrendMa) {
    reason = "EMA_NON_ASCENDANTE";
    return false;
  }

  reason = "RÉGIME_HAUSSIER";
  return true;
}


//+------------------------------------------------------------------+
//| Met à jour une ligne horizontale                                  |
//+------------------------------------------------------------------+
void UpdateHorizontalLine(
  const string objectName,
  const double price,
  const color lineColor,
  const ENUM_LINE_STYLE lineStyle,
  const int lineWidth) {

  if (ObjectFind(0, objectName) < 0) {
    if (!ObjectCreate(
      0,
      objectName,
      OBJ_HLINE,
      0,
      0,
      price)) {

      PrintFormat(
        "[PbBzhConceptEA v2.03][ERROR] "
        "Création objet %s impossible. Erreur=%d",
        objectName,
        GetLastError());

      return;
    }
  }

  ObjectSetDouble(
    0,
    objectName,
    OBJPROP_PRICE,
    price);

  ObjectSetInteger(
    0,
    objectName,
    OBJPROP_COLOR,
    lineColor);

  ObjectSetInteger(
    0,
    objectName,
    OBJPROP_STYLE,
    lineStyle);

  ObjectSetInteger(
    0,
    objectName,
    OBJPROP_WIDTH,
    lineWidth);

  ObjectSetInteger(
    0,
    objectName,
    OBJPROP_BACK,
    true);

  ObjectSetInteger(
    0,
    objectName,
    OBJPROP_SELECTABLE,
    false);
}


//+------------------------------------------------------------------+
//| Dessine une flèche sur la bougie de cassure                       |
//+------------------------------------------------------------------+
void DrawBreakoutArrow(
  const SPbDonchianSnapshot &snapshot) {

  if (!InpShowBreakoutArrows ||
    snapshot.signal == PB_BREAKOUT_NONE) {

    return;
  }

  string directionText = BreakoutSignalToString(
    snapshot.signal);

  string objectName = StringFormat(
    "%s%s_%I64d",
    g_objectPrefix,
    directionText,
    (long)snapshot.signalBarTime);

  if (ObjectFind(0, objectName) >= 0)
    return;

  ENUM_OBJECT objectType =
    snapshot.signal == PB_BREAKOUT_BUY
    ? OBJ_ARROW_BUY
    : OBJ_ARROW_SELL;

  double offset = snapshot.atrPrice *
    MathMax(0.0, InpArrowOffsetAtr);

  double arrowPrice =
    snapshot.signal == PB_BREAKOUT_BUY
    ? snapshot.signalLow - offset
    : snapshot.signalHigh + offset;

  if (!ObjectCreate(
    0,
    objectName,
    objectType,
    0,
    snapshot.signalBarTime,
    arrowPrice)) {

    PrintFormat(
      "[PbBzhConceptEA v2.03][ERROR] "
      "Création flèche %s impossible. Erreur=%d",
      objectName,
      GetLastError());

    return;
  }

  ObjectSetInteger(
    0,
    objectName,
    OBJPROP_COLOR,
    snapshot.signal == PB_BREAKOUT_BUY
    ? InpBuyArrowColor
    : InpSellArrowColor);

  ObjectSetInteger(
    0,
    objectName,
    OBJPROP_WIDTH,
    2);

  ObjectSetInteger(
    0,
    objectName,
    OBJPROP_SELECTABLE,
    false);
}


//+------------------------------------------------------------------+
//| Met à jour les niveaux de la position virtuelle                   |
//+------------------------------------------------------------------+
void UpdateVirtualPositionLines(void) {
  if (!InpShowVirtualPositionLevels ||
    !g_virtualPosition.IsOpen()) {

    ObjectDelete(0, g_virtualEntryName);
    ObjectDelete(0, g_virtualStopName);
    return;
  }

  UpdateHorizontalLine(
    g_virtualEntryName,
    g_virtualPosition.EntryPrice(),
    InpVirtualEntryColor,
    STYLE_DOT,
    1);

  UpdateHorizontalLine(
    g_virtualStopName,
    g_virtualPosition.StopLossPrice(),
    InpVirtualStopColor,
    STYLE_SOLID,
    2);
}


//+------------------------------------------------------------------+
//| Met à jour l'affichage du dernier état                            |
//+------------------------------------------------------------------+
void UpdateChartDisplay(
  const SPbDonchianSnapshot &snapshot) {

  if (InpShowEntryChannel) {
    UpdateHorizontalLine(
      g_entryUpperName,
      snapshot.entryUpper,
      InpEntryUpperColor,
      STYLE_SOLID,
      2);

    UpdateHorizontalLine(
      g_entryLowerName,
      snapshot.entryLower,
      InpEntryLowerColor,
      STYLE_SOLID,
      2);
  }
  else {
    ObjectDelete(0, g_entryUpperName);
    ObjectDelete(0, g_entryLowerName);
  }

  if (InpShowExitChannel) {
    UpdateHorizontalLine(
      g_exitUpperName,
      snapshot.exitUpper,
      InpExitChannelColor,
      STYLE_DASH,
      1);

    UpdateHorizontalLine(
      g_exitLowerName,
      snapshot.exitLower,
      InpExitChannelColor,
      STYLE_DASH,
      1);
  }
  else {
    ObjectDelete(0, g_exitUpperName);
    ObjectDelete(0, g_exitLowerName);
  }

  DrawBreakoutArrow(snapshot);
  UpdateVirtualPositionLines();

  Comment(
    "PbBzhConceptEA v2.03 — DONCHIAN / CHANDELIER\n",
    "Symbole : ", _Symbol,
    " | UT : ", EnumToString(InpSignalTimeframe),
    " | Direction : ",
    V2DirectionModeToString(InpDirectionMode), "\n",
    "Bougie clôturée : ",
    TimeToString(snapshot.signalBarTime, TIME_DATE|TIME_MINUTES), "\n",
    "Signal : ", BreakoutSignalToString(snapshot.signal),
    " | Clôture : ",
    DoubleToString(snapshot.signalClose, _Digits), "\n",
    "Donchian entrée ", InpEntryChannelPeriod,
    " : ", DoubleToString(snapshot.entryLower, _Digits),
    " / ", DoubleToString(snapshot.entryUpper, _Digits), "\n",
    "Donchian sortie ", InpExitChannelPeriod,
    " : ", DoubleToString(snapshot.exitLower, _Digits),
    " / ", DoubleToString(snapshot.exitUpper, _Digits), "\n",
    "ATR(", InpAtrPeriod, ") : ",
    DoubleToString(snapshot.atrPoints, 1), " points",
    " | Largeur : ",
    DoubleToString(snapshot.entryChannelWidthAtr, 2), " ATR\n",
    g_virtualPosition.BuildStatusText(), "\n",
    "SL initial : ",
    DoubleToString(InpInitialStopAtrMultiplier, 2),
    " ATR | TP : AUCUN | Sortie : ",
    V2ExitModeToString(InpExitMode), "\n",
    "Chandelier : ",
    DoubleToString(InpChandelierAtrMultiplier, 2),
    " ATR | Filtre LONG : ",
    InpUseTrendFilter ? "ACTIF" : "INACTIF",
    " | EMA : ", EnumToString(InpTrendTimeframe),
    " ", InpTrendMaPeriod,
    " | Pente : ", InpTrendSlopeLookback, " bougies\n",
    "Bougies traitées : ", g_processedBarCount,
    " | Cassures BUY/SELL : ",
    g_buyBreakoutCount, "/", g_sellBreakoutCount,
    " | Filtre LONG OK/REFUS : ",
    g_longTrendAcceptedCount, "/",
    g_longTrendRejectedCount);
}


//+------------------------------------------------------------------+
//| Traite la dernière bougie clôturée                                |
//+------------------------------------------------------------------+
void ProcessClosedBar(
  const MqlTick &tick,
  const bool positionClosedEarlierThisTick) {

  SPbDonchianSnapshot snapshot;

  if (!g_breakoutSignal.EvaluateClosedBar(snapshot) ||
    !snapshot.isValid) {

    return;
  }

  g_lastSnapshot = snapshot;
  g_hasLastSnapshot = true;

  g_processedBarCount++;

  bool longTrendAllowed = true;

  if (snapshot.signal == PB_BREAKOUT_BUY) {
    g_buyBreakoutCount++;
  
    double closedTrendPrice = 0.0;
    double currentTrendMa = 0.0;
    double pastTrendMa = 0.0;
    string trendReason = "";

    longTrendAllowed = IsLongTrendAllowed(
      closedTrendPrice,
      currentTrendMa,
      pastTrendMa,
      trendReason);

    if (longTrendAllowed)
      g_longTrendAcceptedCount++;
    else
      g_longTrendRejectedCount++;

    PrintFormat(
      "[PbBzhConceptEA v2.03][INFO] "
      "FILTRE LONG | Temps=%s | Résultat=%s | Raison=%s | "
      "Clôture %s=%.5f | EMA(%d) actuelle=%.5f | "
      "EMA il y a %d bougies=%.5f | Acceptés=%I64d | Refusés=%I64d",

      TimeToString(
        snapshot.signalBarTime,
        TIME_DATE|TIME_MINUTES),
      longTrendAllowed ? "ACCEPTÉ" : "REFUSÉ",
      trendReason,
      EnumToString(InpTrendTimeframe),
      closedTrendPrice,
      InpTrendMaPeriod,
      currentTrendMa,
      InpTrendSlopeLookback,
      pastTrendMa,
      g_longTrendAcceptedCount,
      g_longTrendRejectedCount);
  }
  else if (snapshot.signal == PB_BREAKOUT_SELL)
    g_sellBreakoutCount++;

  // L'ATR du Chandelier est actualisé uniquement à partir
  // de la dernière bougie clôturée.
  g_virtualPosition.UpdateAtr(
    snapshot.atrPrice,
    snapshot.atrPoints);

  // Une actualisation de l'ATR peut resserrer le Chandelier.
  bool closedAfterAtrUpdate =
    g_virtualPosition.ProcessTick(tick);

  // Une position existante est d'abord évaluée pour la sortie.
  // Lorsqu'elle est clôturée, aucune réouverture n'est autorisée
  // sur la même bougie : cela évite une inversion instantanée.
  bool closedByDonchian =
    g_virtualPosition.ProcessDonchianExit(
      snapshot,
      tick);

  if (!g_virtualPosition.IsOpen() &&
    !closedByDonchian &&
    !closedAfterAtrUpdate &&
    !positionClosedEarlierThisTick) {

    bool allowLong =
      (InpDirectionMode == PB_V2_DIRECTION_LONG_ONLY ||
       InpDirectionMode == PB_V2_DIRECTION_BOTH) &&
      longTrendAllowed;

    bool allowShort =
      InpDirectionMode == PB_V2_DIRECTION_SHORT_ONLY ||
      InpDirectionMode == PB_V2_DIRECTION_BOTH;

    g_virtualPosition.OpenFromSignal(
      snapshot,
      tick,
      allowLong,
      allowShort);
  }

  UpdateChartDisplay(snapshot);

  PrintFormat(
    "[PbBzhConceptEA v2.03][INFO] "
    "BARRE | Temps=%s | Signal=%s | "
    "O=%.5f H=%.5f L=%.5f C=%.5f | "
    "EntréeBas=%.5f | EntréeHaut=%.5f | "
    "SortieBas=%.5f | SortieHaut=%.5f | "
    "ATR=%.1f points | Largeur=%.2f ATR | "
    "Position=%s | Capital=%.2f EUR | "
    "Bougies=%I64d | Cassures BUY=%I64d SELL=%I64d",

    TimeToString(
      snapshot.signalBarTime,
      TIME_DATE|TIME_MINUTES),

    BreakoutSignalToString(
      snapshot.signal),

    snapshot.signalOpen,
    snapshot.signalHigh,
    snapshot.signalLow,
    snapshot.signalClose,
    snapshot.entryLower,
    snapshot.entryUpper,
    snapshot.exitLower,
    snapshot.exitUpper,
    snapshot.atrPoints,
    snapshot.entryChannelWidthAtr,
    V2PositionDirectionToString(
      g_virtualPosition.Direction()),
    g_virtualPosition.VirtualCapital(),
    g_processedBarCount,
    g_buyBreakoutCount,
    g_sellBreakoutCount);
}


//+------------------------------------------------------------------+
//| Vérifie l'apparition d'une nouvelle bougie                        |
//+------------------------------------------------------------------+
bool IsNewBar(void) {
  datetime currentBarTime = iTime(
    _Symbol,
    InpSignalTimeframe,
    0);

  if (currentBarTime <= 0)
    return false;

  if (g_currentBarTime == 0) {
    g_currentBarTime = currentBarTime;
    return true;
  }

  if (currentBarTime == g_currentBarTime)
    return false;

  g_currentBarTime = currentBarTime;
  return true;
}


//+------------------------------------------------------------------+
//| Initialisation                                                    |
//+------------------------------------------------------------------+
int OnInit(void) {
  if (!g_breakoutSignal.Initialize(
    _Symbol,
    InpSignalTimeframe,
    InpEntryChannelPeriod,
    InpExitChannelPeriod,
    InpAtrPeriod)) {

    return INIT_FAILED;
  }

  if (!InitializeLongTrendFilter()) {
    g_breakoutSignal.Release();
    return INIT_FAILED;
  }

  if (!g_virtualPosition.Initialize(
    _Symbol,
    InpInitialCapital,
    InpRiskPercent,
    InpInitialStopAtrMultiplier,
    InpExitMode,
    InpChandelierAtrMultiplier)) {

    if (g_trendMaHandle != INVALID_HANDLE) {
      IndicatorRelease(g_trendMaHandle);
      g_trendMaHandle = INVALID_HANDLE;
    }

    g_breakoutSignal.Release();
    return INIT_FAILED;
  }

  PrintFormat(
    "[PbBzhConceptEA v2.03][INFO] "
    "DÉMARRAGE | Symbole=%s | UT=%s | Direction=%s | "
    "Donchian entrée=%d | Donchian sortie=%d | "
    "ATR=%d | SL initial=%.2f ATR | TP=AUCUN | "
    "Sortie=%s | Chandelier=%.2f ATR | "
    "Filtre LONG=%s | EMA=%s/%d | Recul pente=%d | "
    "Capital=%.2f EUR | Risque=%.2f%% | Mode=SIMULATION",

    _Symbol,
    EnumToString(InpSignalTimeframe),
    V2DirectionModeToString(InpDirectionMode),
    InpEntryChannelPeriod,
    InpExitChannelPeriod,
    InpAtrPeriod,
    InpInitialStopAtrMultiplier,
    V2ExitModeToString(InpExitMode),
    InpChandelierAtrMultiplier,
    InpUseTrendFilter ? "ACTIF" : "INACTIF",
    EnumToString(InpTrendTimeframe),
    InpTrendMaPeriod,
    InpTrendSlopeLookback,
    InpInitialCapital,
    InpRiskPercent);

  g_currentBarTime = 0;
  g_hasLastSnapshot = false;
  g_processedBarCount = 0;
  g_buyBreakoutCount = 0;
  g_sellBreakoutCount = 0;
  g_longTrendAcceptedCount = 0;
  g_longTrendRejectedCount = 0;
  ZeroMemory(g_lastSnapshot);
  return INIT_SUCCEEDED;
}


//+------------------------------------------------------------------+
//| Désinitialisation                                                 |
//+------------------------------------------------------------------+
void OnDeinit(const int reason) {
  MqlTick tick;

  if (SymbolInfoTick(_Symbol, tick))
    g_virtualPosition.CloseAtTestEnd(tick);

  PrintFormat(
    "[PbBzhConceptEA v2.03][INFO] "
    "Résumé détection : Bougies traitées=%I64d | "
    "Cassures BUY=%I64d | Cassures SELL=%I64d | "
    "Cassures totales=%I64d | UT=%s",

    g_processedBarCount,
    g_buyBreakoutCount,
    g_sellBreakoutCount,
    g_buyBreakoutCount + g_sellBreakoutCount,
    EnumToString(InpSignalTimeframe));

  PrintFormat(
    "[PbBzhConceptEA v2.03][INFO] "
    "Résumé filtre LONG : Détectés=%I64d | "
    "Acceptés=%I64d | Refusés=%I64d | "
    "Filtre=%s | EMA=%s/%d | Recul pente=%d",

    g_buyBreakoutCount,
    g_longTrendAcceptedCount,
    g_longTrendRejectedCount,
    InpUseTrendFilter ? "ACTIF" : "INACTIF",
    EnumToString(InpTrendTimeframe),
    InpTrendMaPeriod,
    InpTrendSlopeLookback);

  g_virtualPosition.PrintFinalSummary();
  g_breakoutSignal.Release();

  if (g_trendMaHandle != INVALID_HANDLE) {
    IndicatorRelease(g_trendMaHandle);
    g_trendMaHandle = INVALID_HANDLE;
  }

  ObjectsDeleteAll(0, g_objectPrefix);
  Comment("");

  PrintFormat(
    "[PbBzhConceptEA v2.03][INFO] "
    "ARRÊT | Raison=%d",
    reason);
}


//+------------------------------------------------------------------+
//| Tick                                                              |
//+------------------------------------------------------------------+
void OnTick(void) {
  MqlTick tick;

  if (!SymbolInfoTick(_Symbol, tick))
    return;

  bool closedByStop =
    g_virtualPosition.ProcessTick(tick);

  if (closedByStop && g_hasLastSnapshot)
    UpdateChartDisplay(g_lastSnapshot);

  if (!IsNewBar())
    return;

  ProcessClosedBar(
    tick,
    closedByStop);
}
