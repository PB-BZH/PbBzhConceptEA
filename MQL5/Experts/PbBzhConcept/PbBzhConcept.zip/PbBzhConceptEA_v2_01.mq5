//+------------------------------------------------------------------+
//|                        PbBzhConceptEA_v2_01.mq5                   |
//|  v2.01 : Donchian + SL initial ATR + sortie Donchian virtuelle   |
//+------------------------------------------------------------------+
#property copyright "Copyright 2026, PbBzhConcept"
#property version   "2.01"
#property strict
#property description "Recherche : cassures Donchian avec position virtuelle"
#property description "SL initial ATR, aucun TP, sortie par canal Donchian"

#include <PbBzhConcept\Signals\DonchianBreakoutSignal.mqh>
#include <PbBzhConcept\Simulation\VirtualDonchianPositionManager.mqh>

enum ENUM_PB_V2_DIRECTION_MODE {
  PB_V2_DIRECTION_LONG_ONLY = 0,
  PB_V2_DIRECTION_SHORT_ONLY,
  PB_V2_DIRECTION_BOTH
};

string V2DirectionModeToString(
  const ENUM_PB_V2_DIRECTION_MODE mode) {

  switch (mode) {
    case PB_V2_DIRECTION_LONG_ONLY:
      return "LONG_ONLY";

    case PB_V2_DIRECTION_SHORT_ONLY:
      return "SHORT_ONLY";

    case PB_V2_DIRECTION_BOTH:
    default:
      return "BOTH";
  }
}

input group "Général"
input ENUM_TIMEFRAMES InpSignalTimeframe = PERIOD_H1;
input ENUM_PB_V2_DIRECTION_MODE InpDirectionMode = PB_V2_DIRECTION_BOTH;

input group "Canaux de Donchian"
input int InpEntryChannelPeriod = 20;
input int InpExitChannelPeriod = 10;

input group "Volatilité et protection"
input int InpAtrPeriod = 14;
input double InpInitialStopAtrMultiplier = 2.00;

input group "Simulation virtuelle"
input double InpInitialCapital = 10000.00;
input double InpRiskPercent = 1.00;

input group "Affichage"
input bool InpShowEntryChannel = true;
input bool InpShowExitChannel = true;
input bool InpShowBreakoutArrows = true;
input bool InpShowVirtualPositionLevels = true;
input double InpArrowOffsetAtr = 0.20;
input color InpEntryUpperColor = clrLimeGreen;
input color InpEntryLowerColor = clrTomato;
input color InpExitChannelColor = clrGold;
input color InpBuyArrowColor = clrLimeGreen;
input color InpSellArrowColor = clrTomato;
input color InpVirtualEntryColor = clrDeepSkyBlue;
input color InpVirtualStopColor = clrMagenta;

CDonchianBreakoutSignal g_breakoutSignal;
CVirtualDonchianPositionManager g_virtualPosition;

datetime g_currentBarTime = 0;
bool g_hasLastSnapshot = false;
SPbDonchianSnapshot g_lastSnapshot;

string g_objectPrefix = "PB201_";
string g_entryUpperName = "PB201_ENTRY_UPPER";
string g_entryLowerName = "PB201_ENTRY_LOWER";
string g_exitUpperName = "PB201_EXIT_UPPER";
string g_exitLowerName = "PB201_EXIT_LOWER";
string g_virtualEntryName = "PB201_VIRTUAL_ENTRY";
string g_virtualStopName = "PB201_VIRTUAL_STOP";


//+------------------------------------------------------------------+
//| Met à jour une ligne horizontale                                  |
//+------------------------------------------------------------------+
void UpdateHorizontalLine(
  const string objectName,
  const double price,
  const color lineColor,
  const ENUM_LINE_STYLE lineStyle,
  const int lineWidth) {

  if (ObjectFind(0, objectName) < 0) {
    if (!ObjectCreate(
      0,
      objectName,
      OBJ_HLINE,
      0,
      0,
      price)) {

      PrintFormat(
        "[%s][ERROR] "
        "Création objet %s impossible. Erreur=%d",
        __FILE__,
        objectName,
        GetLastError());

      return;
    }
  }

  ObjectSetDouble(
    0,
    objectName,
    OBJPROP_PRICE,
    price);

  ObjectSetInteger(
    0,
    objectName,
    OBJPROP_COLOR,
    lineColor);

  ObjectSetInteger(
    0,
    objectName,
    OBJPROP_STYLE,
    lineStyle);

  ObjectSetInteger(
    0,
    objectName,
    OBJPROP_WIDTH,
    lineWidth);

  ObjectSetInteger(
    0,
    objectName,
    OBJPROP_BACK,
    true);

  ObjectSetInteger(
    0,
    objectName,
    OBJPROP_SELECTABLE,
    false);
}


//+------------------------------------------------------------------+
//| Dessine une flèche sur la bougie de cassure                       |
//+------------------------------------------------------------------+
void DrawBreakoutArrow(
  const SPbDonchianSnapshot &snapshot) {

  if (!InpShowBreakoutArrows ||
    snapshot.signal == PB_BREAKOUT_NONE) {

    return;
  }

  string directionText = BreakoutSignalToString(
    snapshot.signal);

  string objectName = StringFormat(
    "%s%s_%I64d",
    g_objectPrefix,
    directionText,
    (long)snapshot.signalBarTime);

  if (ObjectFind(0, objectName) >= 0)
    return;

  ENUM_OBJECT objectType =
    snapshot.signal == PB_BREAKOUT_BUY
    ? OBJ_ARROW_BUY
    : OBJ_ARROW_SELL;

  double offset = snapshot.atrPrice *
    MathMax(0.0, InpArrowOffsetAtr);

  double arrowPrice =
    snapshot.signal == PB_BREAKOUT_BUY
    ? snapshot.signalLow - offset
    : snapshot.signalHigh + offset;

  if (!ObjectCreate(
    0,
    objectName,
    objectType,
    0,
    snapshot.signalBarTime,
    arrowPrice)) {

    PrintFormat(
      "[%s][ERROR] "
      "Création flèche %s impossible. Erreur=%d",
      __FILE__,
      objectName,
      GetLastError());

    return;
  }

  ObjectSetInteger(
    0,
    objectName,
    OBJPROP_COLOR,
    snapshot.signal == PB_BREAKOUT_BUY
    ? InpBuyArrowColor
    : InpSellArrowColor);

  ObjectSetInteger(
    0,
    objectName,
    OBJPROP_WIDTH,
    2);

  ObjectSetInteger(
    0,
    objectName,
    OBJPROP_SELECTABLE,
    false);
}


//+------------------------------------------------------------------+
//| Met à jour les niveaux de la position virtuelle                   |
//+------------------------------------------------------------------+
void UpdateVirtualPositionLines(void) {
  if (!InpShowVirtualPositionLevels ||
    !g_virtualPosition.IsOpen()) {

    ObjectDelete(0, g_virtualEntryName);
    ObjectDelete(0, g_virtualStopName);
    return;
  }

  UpdateHorizontalLine(
    g_virtualEntryName,
    g_virtualPosition.EntryPrice(),
    InpVirtualEntryColor,
    STYLE_DOT,
    1);

  UpdateHorizontalLine(
    g_virtualStopName,
    g_virtualPosition.StopLossPrice(),
    InpVirtualStopColor,
    STYLE_SOLID,
    2);
}


//+------------------------------------------------------------------+
//| Met à jour l'affichage du dernier état                            |
//+------------------------------------------------------------------+
void UpdateChartDisplay(
  const SPbDonchianSnapshot &snapshot) {

  if (InpShowEntryChannel) {
    UpdateHorizontalLine(
      g_entryUpperName,
      snapshot.entryUpper,
      InpEntryUpperColor,
      STYLE_SOLID,
      2);

    UpdateHorizontalLine(
      g_entryLowerName,
      snapshot.entryLower,
      InpEntryLowerColor,
      STYLE_SOLID,
      2);
  }
  else {
    ObjectDelete(0, g_entryUpperName);
    ObjectDelete(0, g_entryLowerName);
  }

  if (InpShowExitChannel) {
    UpdateHorizontalLine(
      g_exitUpperName,
      snapshot.exitUpper,
      InpExitChannelColor,
      STYLE_DASH,
      1);

    UpdateHorizontalLine(
      g_exitLowerName,
      snapshot.exitLower,
      InpExitChannelColor,
      STYLE_DASH,
      1);
  }
  else {
    ObjectDelete(0, g_exitUpperName);
    ObjectDelete(0, g_exitLowerName);
  }

  DrawBreakoutArrow(snapshot);
  UpdateVirtualPositionLines();

  Comment(
    __FILE__, " — SIMULATION VIRTUELLE\n",
    "Symbole : ", _Symbol,
    " | UT : ", EnumToString(InpSignalTimeframe),
    " | Direction : ",
    V2DirectionModeToString(InpDirectionMode), "\n",
    "Bougie clôturée : ",
    TimeToString(snapshot.signalBarTime, TIME_DATE|TIME_MINUTES), "\n",
    "Signal : ", BreakoutSignalToString(snapshot.signal),
    " | Clôture : ",
    DoubleToString(snapshot.signalClose, _Digits), "\n",
    "Donchian entrée ", InpEntryChannelPeriod,
    " : ", DoubleToString(snapshot.entryLower, _Digits),
    " / ", DoubleToString(snapshot.entryUpper, _Digits), "\n",
    "Donchian sortie ", InpExitChannelPeriod,
    " : ", DoubleToString(snapshot.exitLower, _Digits),
    " / ", DoubleToString(snapshot.exitUpper, _Digits), "\n",
    "ATR(", InpAtrPeriod, ") : ",
    DoubleToString(snapshot.atrPoints, 1), " points",
    " | Largeur : ",
    DoubleToString(snapshot.entryChannelWidthAtr, 2), " ATR\n",
    g_virtualPosition.BuildStatusText(), "\n",
    "SL initial : ",
    DoubleToString(InpInitialStopAtrMultiplier, 2),
    " ATR | TP : AUCUN | Sortie : Donchian ",
    InpExitChannelPeriod);
}


//+------------------------------------------------------------------+
//| Traite la dernière bougie clôturée                                |
//+------------------------------------------------------------------+
void ProcessClosedBar(
  const MqlTick &tick) {

  SPbDonchianSnapshot snapshot;

  if (!g_breakoutSignal.EvaluateClosedBar(snapshot) ||
    !snapshot.isValid) {

    return;
  }

  g_lastSnapshot = snapshot;
  g_hasLastSnapshot = true;

  // Une position existante est d'abord évaluée pour la sortie.
  // Lorsqu'elle est clôturée, aucune réouverture n'est autorisée
  // sur la même bougie : cela évite une inversion instantanée.
  bool closedByDonchian =
    g_virtualPosition.ProcessDonchianExit(
      snapshot,
      tick);

  if (!g_virtualPosition.IsOpen() &&
    !closedByDonchian) {

    bool allowLong =
      InpDirectionMode == PB_V2_DIRECTION_LONG_ONLY ||
      InpDirectionMode == PB_V2_DIRECTION_BOTH;

    bool allowShort =
      InpDirectionMode == PB_V2_DIRECTION_SHORT_ONLY ||
      InpDirectionMode == PB_V2_DIRECTION_BOTH;

    g_virtualPosition.OpenFromSignal(
      snapshot,
      tick,
      allowLong,
      allowShort);
  }

  UpdateChartDisplay(snapshot);

  PrintFormat(
    "[PbBzhConceptEA v2.01][INFO] "
    "BARRE | Temps=%s | Signal=%s | "
    "O=%.5f H=%.5f L=%.5f C=%.5f | "
    "EntréeBas=%.5f | EntréeHaut=%.5f | "
    "SortieBas=%.5f | SortieHaut=%.5f | "
    "ATR=%.1f points | Largeur=%.2f ATR | "
    "Position=%s | Capital=%.2f EUR",

    TimeToString(
      snapshot.signalBarTime,
      TIME_DATE|TIME_MINUTES),

    BreakoutSignalToString(
      snapshot.signal),

    snapshot.signalOpen,
    snapshot.signalHigh,
    snapshot.signalLow,
    snapshot.signalClose,
    snapshot.entryLower,
    snapshot.entryUpper,
    snapshot.exitLower,
    snapshot.exitUpper,
    snapshot.atrPoints,
    snapshot.entryChannelWidthAtr,
    V2PositionDirectionToString(
      g_virtualPosition.Direction()),
    g_virtualPosition.VirtualCapital());
}


//+------------------------------------------------------------------+
//| Vérifie l'apparition d'une nouvelle bougie                        |
//+------------------------------------------------------------------+
bool IsNewBar(void) {
  datetime currentBarTime = iTime(
    _Symbol,
    InpSignalTimeframe,
    0);

  if (currentBarTime <= 0)
    return false;

  if (g_currentBarTime == 0) {
    g_currentBarTime = currentBarTime;
    return true;
  }

  if (currentBarTime == g_currentBarTime)
    return false;

  g_currentBarTime = currentBarTime;
  return true;
}


//+------------------------------------------------------------------+
//| Initialisation                                                    |
//+------------------------------------------------------------------+
int OnInit(void) {
  if (!g_breakoutSignal.Initialize(
    _Symbol,
    InpSignalTimeframe,
    InpEntryChannelPeriod,
    InpExitChannelPeriod,
    InpAtrPeriod)) {

    return INIT_FAILED;
  }

  if (!g_virtualPosition.Initialize(
    _Symbol,
    InpInitialCapital,
    InpRiskPercent,
    InpInitialStopAtrMultiplier)) {

    g_breakoutSignal.Release();
    return INIT_FAILED;
  }

  PrintFormat(
    "[PbBzhConceptEA v2.01][INFO] "
    "DÉMARRAGE | Symbole=%s | UT=%s | Direction=%s | "
    "Donchian entrée=%d | Donchian sortie=%d | "
    "ATR=%d | SL initial=%.2f ATR | TP=AUCUN | "
    "Capital=%.2f EUR | Risque=%.2f%% | Mode=SIMULATION",

    _Symbol,
    EnumToString(InpSignalTimeframe),
    V2DirectionModeToString(InpDirectionMode),
    InpEntryChannelPeriod,
    InpExitChannelPeriod,
    InpAtrPeriod,
    InpInitialStopAtrMultiplier,
    InpInitialCapital,
    InpRiskPercent);

  g_currentBarTime = 0;
  g_hasLastSnapshot = false;
  ZeroMemory(g_lastSnapshot);
  return INIT_SUCCEEDED;
}


//+------------------------------------------------------------------+
//| Désinitialisation                                                 |
//+------------------------------------------------------------------+
void OnDeinit(const int reason) {
  MqlTick tick;

  if (SymbolInfoTick(_Symbol, tick))
    g_virtualPosition.CloseAtTestEnd(tick);

  g_virtualPosition.PrintFinalSummary();
  g_breakoutSignal.Release();

  ObjectsDeleteAll(0, g_objectPrefix);
  Comment("");

  PrintFormat(
    "[PbBzhConceptEA v2.01][INFO] "
    "ARRÊT | Raison=%d",
    reason);
}


//+------------------------------------------------------------------+
//| Tick                                                              |
//+------------------------------------------------------------------+
void OnTick(void) {
  MqlTick tick;

  if (!SymbolInfoTick(_Symbol, tick))
    return;

  bool closedByStop =
    g_virtualPosition.ProcessTick(tick);

  if (closedByStop && g_hasLastSnapshot)
    UpdateChartDisplay(g_lastSnapshot);

  if (!IsNewBar())
    return;

  ProcessClosedBar(tick);
}
