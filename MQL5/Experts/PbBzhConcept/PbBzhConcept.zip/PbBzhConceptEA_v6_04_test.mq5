//+------------------------------------------------------------------+
//|                       PbBzhConceptEA_v6_04_test.mq5                   |
//|  v6.04 : protection des gains et verrou de réentrée             |
//+------------------------------------------------------------------+
#property copyright "Copyright 2026, PbBzhConcept"
#property version   "6.04"
#property strict
#property description "GOLD LONG_ONLY : swing momentum avec contexte supérieur"
#property description "Base : signal H1, contexte H8 EMA 200 ascendante"
#property description "Protection : Chandelier ATR activé après une MFE de 2 R"
#property description "Réentrée : attente d'un nouveau cycle après protection"
#property description "Mesures : équité tick par tick, MAE, MFE et gain restitué"

#include <PbBzhConcept\Simulation\VirtualGoldSwingBreakoutReentryPositionManager.mqh>

struct SPbGoldSwingSnapshot {
  bool isValid;
  datetime signalBarTime;

  double signalOpen;
  double signalHigh;
  double signalLow;
  double signalClose;
  double pastClose;

  double momentumPercent;
  double atrPrice;
  double atrPoints;

  double trendClose;
  double trendEma;
  double trendEmaPast;
  bool trendAllowed;

  ENUM_PB_V603_POSITION_DIRECTION rawMomentumDirection;
  ENUM_PB_V603_POSITION_DIRECTION tradeDirection;
};

input group "Général"
input ENUM_TIMEFRAMES InpSignalTimeframe = PERIOD_H1;

input group "Momentum du signal"
input int InpMomentumLookback = 120;

input group "Contexte de tendance"
input ENUM_TIMEFRAMES InpTrendTimeframe = PERIOD_H8;
input int InpTrendEmaPeriod = 200;
input int InpTrendSlopeLookback = 20;

input group "Volatilité et stop initial"
input int InpAtrPeriod = 20;
input double InpInitialStopAtrMultiplier = 3.00;

input group "Protection des gains"
input bool InpUseProfitProtection = true;
input double InpProfitProtectionActivationR = 2.00;
input double InpProfitProtectionAtrMultiplier = 3.00;
input bool InpLockReentryAfterProfitProtection = true;

input group "Simulation virtuelle"
input double InpInitialCapital = 10000.00;
input double InpRiskPercent = 1.00;

input group "Coûts GOLD"
input double InpCommissionPerLotRoundTurn = 0.00;
input double InpAnnualLongSwapPercent = 9.50;
input int InpSwapRolloverHour = 21;

input group "Affichage"
input bool InpShowMomentumReference = true;
input bool InpShowEntryArrows = true;
input bool InpShowVirtualPositionLevels = true;
input double InpArrowOffsetAtr = 0.20;
input color InpMomentumReferenceColor = clrGold;
input color InpBuyArrowColor = clrLimeGreen;
input color InpVirtualEntryColor = clrDeepSkyBlue;
input color InpVirtualStopColor = clrMagenta;

CVirtualGoldSwingReentryPositionManager g_virtualPosition;

int g_atrHandle = INVALID_HANDLE;
int g_trendEmaHandle = INVALID_HANDLE;

datetime g_currentBarTime = 0;
bool g_hasLastSnapshot = false;
SPbGoldSwingSnapshot g_lastSnapshot;

ENUM_PB_V603_POSITION_DIRECTION g_previousMomentumDirection =
  PB_V603_POSITION_FLAT;

long g_processedBarCount = 0;
long g_longRegimeBarCount = 0;
long g_shortRegimeBarCount = 0;
long g_neutralRegimeBarCount = 0;
long g_longTransitionCount = 0;
long g_shortTransitionCount = 0;
long g_longOpenCount = 0;
long g_shortOpenCount = 0;
long g_trendAcceptedBarCount = 0;
long g_trendRejectedBarCount = 0;
bool g_profitProtectionReentryLocked = false;
long g_profitProtectionLockCount = 0;
long g_profitProtectionRearmCount = 0;
long g_profitProtectionBlockedBarCount = 0;
double g_profitProtectionReentryPrice = 0.0;

datetime g_analysisStartTime = 0;
double g_firstGoldPrice = 0.0;
double g_lastGoldPrice = 0.0;

string g_objectPrefix = "PB603_";
string g_momentumReferenceName = "PB603_MOMENTUM_REFERENCE";
string g_virtualEntryName = "PB603_VIRTUAL_ENTRY";
string g_virtualStopName = "PB603_VIRTUAL_STOP";


//+------------------------------------------------------------------+
//| Vérifie que le nom du symbole ressemble à GOLD ou XAU           |
//+------------------------------------------------------------------+
bool SymbolLooksLikeGold(void) {
  string symbolName = _Symbol;
  StringToUpper(symbolName);

  return StringFind(symbolName, "GOLD") >= 0 ||
    StringFind(symbolName, "XAU") >= 0;
}


//+------------------------------------------------------------------+
//| Libère l'indicateur ATR                                          |
//+------------------------------------------------------------------+
void ReleaseIndicators(void) {
  if (g_atrHandle != INVALID_HANDLE) {
    IndicatorRelease(g_atrHandle);
    g_atrHandle = INVALID_HANDLE;
  }

  if (g_trendEmaHandle != INVALID_HANDLE) {
    IndicatorRelease(g_trendEmaHandle);
    g_trendEmaHandle = INVALID_HANDLE;
  }
}


//+------------------------------------------------------------------+
//| Initialise l'ATR                                                  |
//+------------------------------------------------------------------+
bool InitializeIndicators(void) {
  if (InpMomentumLookback < 2 ||
    InpAtrPeriod < 2 ||
    InpTrendEmaPeriod < 2 ||
    InpTrendSlopeLookback < 1 ||
    InpProfitProtectionActivationR <= 0.0 ||
    InpProfitProtectionAtrMultiplier <= 0.0 ||
    InpSwapRolloverHour < 0 ||
    InpSwapRolloverHour > 23) {

    PrintFormat(
      "[%s][ERROR] Paramètres d'indicateurs invalides.",
      __FILE__);

    return false;
  }

  g_atrHandle = iATR(
    _Symbol,
    InpSignalTimeframe,
    InpAtrPeriod);

  if (g_atrHandle == INVALID_HANDLE) {
    PrintFormat(
      "[%s][ERROR] Création de l'ATR impossible. Erreur=%d",
      __FILE__,
      GetLastError());

    return false;
  }

  g_trendEmaHandle = iMA(
    _Symbol,
    InpTrendTimeframe,
    InpTrendEmaPeriod,
    0,
    MODE_EMA,
    PRICE_CLOSE);

  if (g_trendEmaHandle == INVALID_HANDLE) {
    PrintFormat(
      "[%s][ERROR] Création de l'EMA de tendance impossible. Erreur=%d",
      __FILE__,
      GetLastError());

    ReleaseIndicators();
    return false;
  }

  return true;
}


//+------------------------------------------------------------------+
//| Lit une valeur d'indicateur                                      |
//+------------------------------------------------------------------+
bool ReadIndicatorValue(
  const int handle,
  const int bufferIndex,
  const int shift,
  double &value) {

  double buffer[1];
  ResetLastError();

  if (handle == INVALID_HANDLE ||
    CopyBuffer(
      handle,
      bufferIndex,
      shift,
      1,
      buffer) != 1) {

    return false;
  }

  value = buffer[0];
  return true;
}


//+------------------------------------------------------------------+
//| Évalue le momentum avec des bougies clôturées                    |
//+------------------------------------------------------------------+
bool EvaluateClosedBar(
  SPbGoldSwingSnapshot &snapshot) {

  ZeroMemory(snapshot);
  snapshot.rawMomentumDirection = PB_V603_POSITION_FLAT;
  snapshot.tradeDirection = PB_V603_POSITION_SHORT;

  snapshot.signalBarTime = iTime(
    _Symbol,
    InpSignalTimeframe,
    1);

  snapshot.signalOpen = iOpen(
    _Symbol,
    InpSignalTimeframe,
    1);

  snapshot.signalHigh = iHigh(
    _Symbol,
    InpSignalTimeframe,
    1);

  snapshot.signalLow = iLow(
    _Symbol,
    InpSignalTimeframe,
    1);

  snapshot.signalClose = iClose(
    _Symbol,
    InpSignalTimeframe,
    1);

  snapshot.pastClose = iClose(
    _Symbol,
    InpSignalTimeframe,
    1 + InpMomentumLookback);

  snapshot.trendClose = iClose(
    _Symbol,
    InpTrendTimeframe,
    1);

  bool dataAvailable =
    snapshot.signalBarTime > 0 &&
    snapshot.signalOpen > 0.0 &&
    snapshot.signalHigh > 0.0 &&
    snapshot.signalLow > 0.0 &&
    snapshot.signalClose > 0.0 &&
    snapshot.pastClose > 0.0 &&
    snapshot.trendClose > 0.0 &&
    ReadIndicatorValue(
    g_atrHandle,
    0,
    1,
    snapshot.atrPrice) &&
    ReadIndicatorValue(
    g_trendEmaHandle,
    0,
    1,
    snapshot.trendEma) &&
    ReadIndicatorValue(
    g_trendEmaHandle,
    0,
    1 + InpTrendSlopeLookback,
    snapshot.trendEmaPast);

  if (!dataAvailable || snapshot.atrPrice <= 0.0)
  return false;

  snapshot.atrPoints = snapshot.atrPrice / _Point;
  snapshot.momentumPercent =
    (snapshot.signalClose / snapshot.pastClose - 1.0) * 100.0;

  snapshot.trendAllowed =
    snapshot.trendClose > snapshot.trendEma &&
    snapshot.trendEma > snapshot.trendEmaPast;

  if (snapshot.signalClose > snapshot.pastClose)
  snapshot.rawMomentumDirection = PB_V603_POSITION_LONG;
  else if (snapshot.signalClose < snapshot.pastClose)
  snapshot.rawMomentumDirection = PB_V603_POSITION_SHORT;

  if (snapshot.trendAllowed &&
    snapshot.rawMomentumDirection == PB_V603_POSITION_LONG) {

    snapshot.tradeDirection = PB_V603_POSITION_LONG;
  }

  snapshot.isValid = true;
  return true;
}


//+------------------------------------------------------------------+
//| Vérifie si une direction est autorisée                           |
//+------------------------------------------------------------------+
bool DirectionIsAllowed(
  const ENUM_PB_V603_POSITION_DIRECTION direction) {
  return direction == PB_V603_POSITION_LONG;
}


//+------------------------------------------------------------------+
//| Libellé du régime réellement négociable                         |
//+------------------------------------------------------------------+
string TradeRegimeToString(
  const ENUM_PB_V603_POSITION_DIRECTION direction) {

  return direction == PB_V603_POSITION_LONG
    ? "LONG_AUTORISÉ"
    : "FLAT";
}


//+------------------------------------------------------------------+
//| Met à jour une ligne horizontale                                 |
//+------------------------------------------------------------------+
void UpdateHorizontalLine(
  const string objectName,
  const double price,
  const color lineColor,
  const ENUM_LINE_STYLE lineStyle,
  const int lineWidth) {

  if (price <= 0.0)
  return;

  if (ObjectFind(0, objectName) < 0) {
    if (!ObjectCreate(
        0,
        objectName,
        OBJ_HLINE,
        0,
        0,
        price)) {

      PrintFormat(
        "[%s][ERROR] Création objet %s impossible. Erreur=%d",
        __FILE__,
        objectName,
        GetLastError());

      return;
    }
  }

  ObjectSetDouble(0, objectName, OBJPROP_PRICE, price);
  ObjectSetInteger(0, objectName, OBJPROP_COLOR, lineColor);
  ObjectSetInteger(0, objectName, OBJPROP_STYLE, lineStyle);
  ObjectSetInteger(0, objectName, OBJPROP_WIDTH, lineWidth);
  ObjectSetInteger(0, objectName, OBJPROP_BACK, true);
  ObjectSetInteger(0, objectName, OBJPROP_SELECTABLE, false);
}


//+------------------------------------------------------------------+
//| Dessine une flèche lorsqu'une position est ouverte               |
//+------------------------------------------------------------------+
void DrawEntryArrow(
  const SPbGoldSwingSnapshot &snapshot,
  const ENUM_PB_V603_POSITION_DIRECTION direction) {

  if (!InpShowEntryArrows ||
    direction == PB_V603_POSITION_FLAT) {

    return;
  }

  string objectName = StringFormat(
    "%sENTRY_%s_%I64d",
    g_objectPrefix,
    V603PositionDirectionToString(direction),
    (long)snapshot.signalBarTime);

  if (ObjectFind(0, objectName) >= 0)
  return;

  ENUM_OBJECT objectType =
    direction == PB_V603_POSITION_LONG
    ? OBJ_ARROW_BUY
    : OBJ_ARROW_SELL;

  double offset = snapshot.atrPrice *
    MathMax(0.0, InpArrowOffsetAtr);

  double arrowPrice =
    direction == PB_V603_POSITION_LONG
    ? snapshot.signalLow - offset
    : snapshot.signalHigh + offset;

  if (!ObjectCreate(
      0,
      objectName,
      objectType,
      0,
      snapshot.signalBarTime,
      arrowPrice)) {

    return;
  }

  ObjectSetInteger(
    0,
    objectName,
    OBJPROP_COLOR,
    InpBuyArrowColor);

  ObjectSetInteger(0, objectName, OBJPROP_WIDTH, 2);
  ObjectSetInteger(0, objectName, OBJPROP_SELECTABLE, false);
}


//+------------------------------------------------------------------+
//| Met à jour les niveaux de la position virtuelle                  |
//+------------------------------------------------------------------+
void UpdateVirtualPositionLines(void) {
  if (!InpShowVirtualPositionLevels ||
    !g_virtualPosition.IsOpen()) {

    ObjectDelete(0, g_virtualEntryName);
    ObjectDelete(0, g_virtualStopName);
    return;
  }

  UpdateHorizontalLine(
    g_virtualEntryName,
    g_virtualPosition.EntryPrice(),
    InpVirtualEntryColor,
    STYLE_DOT,
    1);

  UpdateHorizontalLine(
    g_virtualStopName,
    g_virtualPosition.StopLossPrice(),
    InpVirtualStopColor,
    STYLE_SOLID,
    2);
}


//+------------------------------------------------------------------+
//| Met à jour l'affichage                                           |
//+------------------------------------------------------------------+
void UpdateChartDisplay(
  const SPbGoldSwingSnapshot &snapshot) {

  if (InpShowMomentumReference) {
    UpdateHorizontalLine(
      g_momentumReferenceName,
      snapshot.pastClose,
      InpMomentumReferenceColor,
      STYLE_DASH,
      1);
  } else {
    ObjectDelete(0, g_momentumReferenceName);
  }

  UpdateVirtualPositionLines();

  Comment(
    __FILE__, " — SWING GOLD\n",
    "Symbole : ", _Symbol,
    " | UT : ", EnumToString(InpSignalTimeframe),
    " | Direction : LONG_ONLY\n",
    "Bougie clôturée : ",
    TimeToString(snapshot.signalBarTime, TIME_DATE|TIME_MINUTES), "\n",
    "Clôture actuelle : ", DoubleToString(snapshot.signalClose, _Digits),
    " | Clôture il y a ", InpMomentumLookback, " bougies : ",
    DoubleToString(snapshot.pastClose, _Digits), "\n",
    "Momentum : ", DoubleToString(snapshot.momentumPercent, 2), "%",
    " | Direction brute : ",
    V603PositionDirectionToString(snapshot.rawMomentumDirection), "\n",
    "Contexte ", EnumToString(InpTrendTimeframe),
    " : clôture=", DoubleToString(snapshot.trendClose, _Digits),
    " | EMA(", InpTrendEmaPeriod, ")=",
    DoubleToString(snapshot.trendEma, _Digits),
    " | Pente=", snapshot.trendEma > snapshot.trendEmaPast
    ? "HAUSSIÈRE" : "NON HAUSSIÈRE",
    " | Autorisation=", snapshot.trendAllowed ? "OUI" : "NON", "\n",
    "Régime négociable : ",
    TradeRegimeToString(snapshot.tradeDirection), "\n",
    "ATR(", InpAtrPeriod, ") : ",
    DoubleToString(snapshot.atrPoints, 1), " points",
    " | Stop initial : ",
    DoubleToString(InpInitialStopAtrMultiplier, 2), " ATR",
    " | Protection : ", InpUseProfitProtection ? "ACTIVE" : "INACTIVE",
    " après ", DoubleToString(InpProfitProtectionActivationR, 2), " R",
    " à ", DoubleToString(InpProfitProtectionAtrMultiplier, 2), " ATR\n",
    g_virtualPosition.BuildStatusText(), "\n",
    "Bougies : ", g_processedBarCount,
    " | Activations/Désactivations : ",
    g_longTransitionCount, "/", g_shortTransitionCount,
    " | Ouvertures LONG/SHORT : ",
    g_longOpenCount, "/", g_shortOpenCount, "\n",
    "Réentrée après protection : ",
    g_profitProtectionReentryLocked ? "VERROUILLÉE" : "AUTORISÉE",
    " | Verrous/Réarmements : ",
    g_profitProtectionLockCount, "/", g_profitProtectionRearmCount);
}


//+------------------------------------------------------------------+
//| Met à jour les statistiques de régime                            |
//+------------------------------------------------------------------+
void UpdateRegimeCounters(
  const ENUM_PB_V603_POSITION_DIRECTION direction) {

  if (direction == PB_V603_POSITION_LONG)
  g_longRegimeBarCount++;
  else if (direction == PB_V603_POSITION_SHORT)
  g_shortRegimeBarCount++;
  else
  g_neutralRegimeBarCount++;

  if (g_previousMomentumDirection != PB_V603_POSITION_FLAT &&
    direction != PB_V603_POSITION_FLAT &&
    direction != g_previousMomentumDirection) {

    if (direction == PB_V603_POSITION_LONG)
    g_longTransitionCount++;
    else
    g_shortTransitionCount++;
  }

  if (direction != PB_V603_POSITION_FLAT)
  g_previousMomentumDirection = direction;
}


//+------------------------------------------------------------------+
//| Traite la dernière bougie clôturée                               |
//+------------------------------------------------------------------+
void ProcessClosedBar(
  const MqlTick &tick,
  const bool positionClosedEarlierThisTick) {

  SPbGoldSwingSnapshot snapshot;

  if (!EvaluateClosedBar(snapshot) || !snapshot.isValid)
  return;

  g_lastSnapshot = snapshot;
  g_hasLastSnapshot = true;
  g_processedBarCount++;

  if (g_analysisStartTime == 0) {
    g_analysisStartTime = snapshot.signalBarTime;
    g_firstGoldPrice = snapshot.signalClose;
  }

  g_lastGoldPrice = snapshot.signalClose;

  // L'ATR de la dernière bougie clôturée pilote le Chandelier
  // jusqu'à la clôture de la prochaine bougie du signal.
  g_virtualPosition.UpdateCurrentAtr(snapshot.atrPrice);

  if (snapshot.trendAllowed)
  g_trendAcceptedBarCount++;
  else
  g_trendRejectedBarCount++;

  UpdateRegimeCounters(snapshot.tradeDirection);

  bool rearmByRegimeReset =
    snapshot.tradeDirection != PB_V603_POSITION_LONG;

  bool rearmByBreakout =
    snapshot.tradeDirection == PB_V603_POSITION_LONG &&
    g_profitProtectionReentryPrice > 0.0 &&
    snapshot.signalClose > g_profitProtectionReentryPrice;

  if (g_profitProtectionReentryLocked &&
    (rearmByRegimeReset || rearmByBreakout)) {

    string rearmReason =
      rearmByBreakout
      ? "CASSURE_ANCIEN_SOMMET"
      : "SORTIE_REGIME_LONG";

    double previousReentryPrice =
      g_profitProtectionReentryPrice;

    g_profitProtectionReentryLocked = false;
    g_profitProtectionReentryPrice = 0.0;
    g_profitProtectionRearmCount++;

    PrintFormat(
      "[%s][INFO] RÉENTRÉE RÉARMÉE | Temps=%s | "
      "Motif=%s | Clôture=%.*f | Ancien sommet=%.*f",
      __FILE__,
      TimeToString(
        snapshot.signalBarTime,
        TIME_DATE|TIME_MINUTES),
      rearmReason,
      _Digits,
      snapshot.signalClose,
      _Digits,
      previousReentryPrice);
  }

  bool entryBlockedByProtection =
    g_profitProtectionReentryLocked &&
    DirectionIsAllowed(snapshot.tradeDirection);

  if (entryBlockedByProtection)
  g_profitProtectionBlockedBarCount++;

  // La position LONG est clôturée dès que le momentum devient
  // négatif ou que le contexte supérieur n'autorise plus les achats.
  g_virtualPosition.ProcessSignalExit(
    snapshot.tradeDirection,
    tick);

  bool opened = false;

  if (!g_virtualPosition.IsOpen() &&
    !positionClosedEarlierThisTick &&
    !g_profitProtectionReentryLocked &&
    DirectionIsAllowed(snapshot.tradeDirection)) {

    opened = g_virtualPosition.OpenPosition(
      snapshot.tradeDirection,
      snapshot.signalBarTime,
      snapshot.atrPrice,
      snapshot.atrPoints,
      tick);

    if (opened) {
      if (snapshot.tradeDirection == PB_V603_POSITION_LONG)
      g_longOpenCount++;
      else
      g_shortOpenCount++;

      DrawEntryArrow(
        snapshot,
        snapshot.tradeDirection);
    }
  }

  UpdateChartDisplay(snapshot);

  PrintFormat(
    "[%s][INFO] BARRE | Temps=%s | "
    "O=%.5f H=%.5f L=%.5f C=%.5f | "
    "Clôture passée=%.5f | Momentum=%.2f%% | Direction brute=%s | "
    "Contexte C=%.5f EMA=%.5f EMA passée=%.5f | "
    "Tendance contexte=%s | Régime négociable=%s | "
    "ATR=%.1f points | Ouverture=%s | Position=%s | "
    "Réentrée=%s | Capital=%.2f",
    __FILE__,
    TimeToString(snapshot.signalBarTime, TIME_DATE|TIME_MINUTES),
    snapshot.signalOpen,
    snapshot.signalHigh,
    snapshot.signalLow,
    snapshot.signalClose,
    snapshot.pastClose,
    snapshot.momentumPercent,
    V603PositionDirectionToString(snapshot.rawMomentumDirection),
    snapshot.trendClose,
    snapshot.trendEma,
    snapshot.trendEmaPast,
    snapshot.trendAllowed ? "OUI" : "NON",
    TradeRegimeToString(snapshot.tradeDirection),
    snapshot.atrPoints,
    opened ? "OUI" : "NON",
    V603PositionDirectionToString(g_virtualPosition.Direction()),
    entryBlockedByProtection ? "VERROUILLÉE" : "AUTORISÉE",
    g_virtualPosition.VirtualCapital());
}


//+------------------------------------------------------------------+
//| Vérifie l'apparition d'une nouvelle bougie                       |
//+------------------------------------------------------------------+
bool IsNewBar(void) {
  datetime currentBarTime = iTime(
    _Symbol,
    InpSignalTimeframe,
    0);

  if (currentBarTime <= 0)
  return false;

  if (g_currentBarTime == 0) {
    g_currentBarTime = currentBarTime;
    return true;
  }

  if (currentBarTime == g_currentBarTime)
  return false;

  g_currentBarTime = currentBarTime;
  return true;
}


//+------------------------------------------------------------------+
//| Initialisation                                                   |
//+------------------------------------------------------------------+
int OnInit(void) {
  if (!SymbolLooksLikeGold()) {
    PrintFormat(
      "[%s][WARNING] La v6.03 est calibrée pour GOLD/XAU. "
      "Symbole courant=%s",
      __FILE__,
      _Symbol);
  }

  if (!InitializeIndicators())
  return INIT_FAILED;

  if (!g_virtualPosition.Initialize(
      _Symbol,
      InpInitialCapital,
      InpRiskPercent,
      InpInitialStopAtrMultiplier,
      InpCommissionPerLotRoundTurn,
      InpAnnualLongSwapPercent,
      InpSwapRolloverHour,
      InpUseProfitProtection,
      InpProfitProtectionActivationR,
      InpProfitProtectionAtrMultiplier)) {

    ReleaseIndicators();
    return INIT_FAILED;
  }

  g_currentBarTime = 0;
  g_hasLastSnapshot = false;
  g_previousMomentumDirection = PB_V603_POSITION_FLAT;
  g_processedBarCount = 0;
  g_longRegimeBarCount = 0;
  g_shortRegimeBarCount = 0;
  g_neutralRegimeBarCount = 0;
  g_longTransitionCount = 0;
  g_shortTransitionCount = 0;
  g_longOpenCount = 0;
  g_shortOpenCount = 0;
  g_trendAcceptedBarCount = 0;
  g_trendRejectedBarCount = 0;
  g_profitProtectionReentryLocked = false;
  g_profitProtectionReentryPrice = 0.0;
  g_profitProtectionLockCount = 0;
  g_profitProtectionRearmCount = 0;
  g_profitProtectionBlockedBarCount = 0;
  g_analysisStartTime = 0;
  g_firstGoldPrice = 0.0;
  g_lastGoldPrice = 0.0;
  ZeroMemory(g_lastSnapshot);

  PrintFormat(
    "[%s][INFO] DÉMARRAGE | Profil=GOLD SWING LONG_ONLY | "
    "Symbole=%s | Signal=%s/%d | "
    "Contexte=%s EMA=%d pente=%d | ATR=%d | SL=%.2f ATR | "
    "Sortie=SIGNAL_OR_TREND_REVERSAL | "
    "Protection=%s après %.2f R à %.2f ATR | "
    "Verrou réentrée=%s | "
    "Capital=%.2f | Risque=%.2f%% | "
    "Commission=%.2f/lot AR | Swap LONG=%.2f%% annuel | "
    "Rollover=%02dh | "
    "Mode=SIMULATION",
    __FILE__,
    _Symbol,
    EnumToString(InpSignalTimeframe),
    InpMomentumLookback,
    EnumToString(InpTrendTimeframe),
    InpTrendEmaPeriod,
    InpTrendSlopeLookback,
    InpAtrPeriod,
    InpInitialStopAtrMultiplier,
    InpUseProfitProtection ? "ACTIVE" : "INACTIVE",
    InpProfitProtectionActivationR,
    InpProfitProtectionAtrMultiplier,
    InpLockReentryAfterProfitProtection ? "ACTIF" : "INACTIF",
    InpInitialCapital,
    InpRiskPercent,
    InpCommissionPerLotRoundTurn,
    InpAnnualLongSwapPercent,
    InpSwapRolloverHour);

  return INIT_SUCCEEDED;
}


//+------------------------------------------------------------------+
//| Désinitialisation                                                |
//+------------------------------------------------------------------+
void OnDeinit(const int reason) {
  MqlTick tick;
  datetime analysisEndTime =
    g_hasLastSnapshot
    ? g_lastSnapshot.signalBarTime
    : g_analysisStartTime;

  if (SymbolInfoTick(_Symbol, tick)) {
    g_virtualPosition.CloseAtTestEnd(tick);
    analysisEndTime = (datetime)tick.time;
  }

  PrintFormat(
    "[%s][INFO] Résumé swing : Bougies traitées=%I64d | "
    "Contexte accepté=%I64d | Refusé=%I64d | "
    "Régime négociable LONG=%I64d | Hors régime=%I64d | Neutre=%I64d | "
    "Activations=%I64d | Désactivations=%I64d | "
    "Ouvertures LONG=%I64d | Ouvertures SHORT=%I64d | "
    "Verrous réentrée=%I64d | Réarmements=%I64d | "
    "Bougies LONG bloquées=%I64d | "
    "Signal=%s/%d | Contexte=%s EMA=%d pente=%d",
    __FILE__,
    g_processedBarCount,
    g_trendAcceptedBarCount,
    g_trendRejectedBarCount,
    g_longRegimeBarCount,
    g_shortRegimeBarCount,
    g_neutralRegimeBarCount,
    g_longTransitionCount,
    g_shortTransitionCount,
    g_longOpenCount,
    g_shortOpenCount,
    g_profitProtectionLockCount,
    g_profitProtectionRearmCount,
    g_profitProtectionBlockedBarCount,
    EnumToString(InpSignalTimeframe),
    InpMomentumLookback,
    EnumToString(InpTrendTimeframe),
    InpTrendEmaPeriod,
    InpTrendSlopeLookback);

  g_virtualPosition.PrintFinalSummary();

  g_virtualPosition.PrintAutomaticAnalysis(
    g_analysisStartTime,
    analysisEndTime,
    g_firstGoldPrice,
    g_lastGoldPrice);

  ReleaseIndicators();

  ObjectsDeleteAll(0, g_objectPrefix);
  Comment("");

  PrintFormat(
    "[%s][INFO] ARRÊT | Raison=%d",
    __FILE__,
    reason);
}


//+------------------------------------------------------------------+
//| Tick                                                             |
//+------------------------------------------------------------------+
void OnTick(void) {
  MqlTick tick;

  if (!SymbolInfoTick(_Symbol, tick))
  return;

  bool closedByStop =
    g_virtualPosition.ProcessTick(tick);

  if (closedByStop &&
    InpLockReentryAfterProfitProtection &&
    g_virtualPosition.LastExitReason() ==
    PB_V603_EXIT_PROFIT_PROTECTION) {

    g_profitProtectionReentryPrice =
      g_virtualPosition.LastProfitProtectionPeakPrice();

    g_profitProtectionReentryLocked =
      g_profitProtectionReentryPrice > 0.0;

    if (g_profitProtectionReentryLocked) {
      g_profitProtectionLockCount++;

      PrintFormat(
        "[%s][INFO] RÉENTRÉE VERROUILLÉE | Temps=%s | "
        "Cassure requise au-dessus de %.*f",
        __FILE__,
        TimeToString(
          (datetime)tick.time,
          TIME_DATE|TIME_MINUTES),
        _Digits,
        g_profitProtectionReentryPrice);
    }
  }

  if (closedByStop && g_hasLastSnapshot)
  UpdateChartDisplay(g_lastSnapshot);

  if (!IsNewBar())
  return;

  ProcessClosedBar(
    tick,
    closedByStop);
}
