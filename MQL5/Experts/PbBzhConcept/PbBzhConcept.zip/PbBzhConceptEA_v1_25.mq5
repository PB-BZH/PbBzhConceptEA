//+------------------------------------------------------------------+
//|                                              PbBzhConceptEA.mq5  |
//|          v1.25 : stratégie candidate + rapports persistants      |
//+------------------------------------------------------------------+
#property copyright "Copyright 2026, PbBzhConcept"
#property link      "https://www.mql5.com"
#property version   "1.25"
#property strict
#property description "EA pédagogique : signaux et positions virtuelles"

#include <PbBzhConcept\Core\BarClock.mqh>
#include <PbBzhConcept\Core\EaLogger.mqh>
#include <PbBzhConcept\Signals\MaPriceCrossSignal.mqh>
#include <PbBzhConcept\Presentation\ChartSignalRenderer.mqh>
#include <PbBzhConcept\Statistics\SignalStatistics.mqh>
#include <PbBzhConcept\Simulation\VirtualPositionManager.mqh>
#include <PbBzhConcept\Simulation\ExecutionQuoteProvider.mqh>
#include <PbBzhConcept\Simulation\VirtualVolumeCalculator.mqh>
#include <PbBzhConcept\Analysis\LocalPriceWindowAnalyzer.mqh>
#include <PbBzhConcept\Domain\LocalMarketDynamics.mqh>

//--- Paramètres généraux
input group "Général"
input string InpExpertName = "PbBzhConceptEA";
input ENUM_TIMEFRAMES InpSignalTimeframe = PERIOD_H1;
//--- Paramètres du signal
input group "Signal : croisement cours / moyenne mobile"
input int InpMaPeriod = 12;
input int InpMaShift = 0;
input ENUM_MA_METHOD InpMaMethod = MODE_SMA;
input ENUM_APPLIED_PRICE InpMaAppliedPrice = PRICE_CLOSE;

//--- Paramètres d'affichage
input group "Affichage graphique"
input bool InpShowSignalArrows = true;
input int InpSignalArrowOffsetPoints = 50;
input color InpBuyArrowColor = clrLimeGreen;
input color InpSellArrowColor = clrTomato;

input group "Simulation : protections virtuelles"
input int InpVirtualStopLossPoints = 200;
input int InpVirtualTakeProfitPoints = 400;

input group "Simulation : gestion du volume"
input ENUM_PB_VIRTUAL_VOLUME_MODE InpVirtualVolumeMode = PB_VIRTUAL_VOLUME_RISK_PERCENT;
input double InpVirtualFixedVolumeLots = 0.10;
input double InpVirtualRiskPercent = 1.00;

input group "Signal : confirmation de tendance"
input bool InpUseMaSlopeFilter = true;

input group "Analyse locale multi-timeframe"
input ENUM_TIMEFRAMES InpLocalTimeframe = PERIOD_M5;
input int InpLocalWindowMinutes = 60;

input group "Contexte tendance H4"
input ENUM_TIMEFRAMES InpTrendTimeframe = PERIOD_H4;
input int InpTrendMaPeriod = 12;

input group "Volatilité ATR H1"
input ENUM_TIMEFRAMES InpAtrTimeframe = PERIOD_H1;
input int InpAtrPeriod = 14;

input group "Simulation : protections adaptées à l'ATR"
input bool InpUseAtrBasedProtection = false;
input double InpAtrStopLossMultiplier = 2.00;
input double InpAtrTakeProfitMultiplier = 4.00;

input group "Simulation : break-even virtuel"
input bool InpUseVirtualBreakEven = true;
input int InpVirtualBreakEvenTriggerPoints = 200;

input group "Simulation : verrouillage de gain virtuel"
input bool InpUseVirtualProfitLock = false;
input int InpVirtualProfitLockTriggerPoints = 300;
input int InpVirtualProfitLockPoints = 100;

input group "Rapports de test persistants"
input bool InpWritePersistentReports = true;
input string InpReportFolder = "PbBzhConceptEA\\Reports";


//--- Objets principaux
CEaLogger g_logger;
CBarClock g_barClock;
CMaPriceCrossSignal g_signal;
CLocalPriceWindowAnalyzer g_localPriceAnalyzer;
CChartSignalRenderer g_renderer;
CSignalStatistics g_statistics;
CVirtualPositionManager g_virtualPositions;
CExecutionQuoteProvider g_quoteProvider;

ENUM_TIMEFRAMES g_timeframe = PERIOD_CURRENT;

int g_trendMaHandle = INVALID_HANDLE;
int g_atrHandle = INVALID_HANDLE;

datetime g_testFirstQuoteTime = 0;
datetime g_testLastQuoteTime = 0;

string g_testHistoryFileName = "PbBzhConceptEA_TestHistory_" + _Symbol + ".csv";
string g_annualResultsFileName = "PbBzhConceptEA_AnnualResults_" + _Symbol + ".csv";

//--- Entonnoir statistique des configurations BUY.
// Les compteurs sont cumulatifs : chaque étape ne peut être
// franchie que si toutes les étapes précédentes le sont aussi.
int g_buyFunnelEvaluatedBars = 0;
int g_buyFunnelRawCrosses = 0;
int g_buyFunnelSlopeAccepted = 0;
int g_buyFunnelContinuationRegime = 0;
int g_buyFunnelLocalValid = 0;
int g_buyFunnelQuadrantI = 0;
int g_buyFunnelTrendStrength = 0;
int g_buyFunnelDirectionalEfficiency = 0;
int g_buyFunnelExecutedOpenings = 0;


//+------------------------------------------------------------------+
//| Réinitialise l'entonnoir statistique BUY                          |
//+------------------------------------------------------------------+
void ResetBuySignalFunnel(void) {
  g_buyFunnelEvaluatedBars = 0;
  g_buyFunnelRawCrosses = 0;
  g_buyFunnelSlopeAccepted = 0;
  g_buyFunnelContinuationRegime = 0;
  g_buyFunnelLocalValid = 0;
  g_buyFunnelQuadrantI = 0;
  g_buyFunnelTrendStrength = 0;
  g_buyFunnelDirectionalEfficiency = 0;
  g_buyFunnelExecutedOpenings = 0;
}


//+------------------------------------------------------------------+
//| Calcule un taux de passage sécurisé                               |
//+------------------------------------------------------------------+
double BuyFunnelRate(
  const int acceptedCount,
  const int previousStageCount) {

  if (previousStageCount <= 0)
  return 0.0;

  return 100.0 *
    (double)acceptedCount /
    (double)previousStageCount;
}


//+------------------------------------------------------------------+
//| Première ligne du résumé de l'entonnoir BUY                       |
//+------------------------------------------------------------------+
string BuildBuySignalFunnelSummary1(void) {
  return StringFormat(
    "Entonnoir BUY [1/3] : "
    "Filtre pente=%s | "
    "Bougies évaluées=%d | "
    "Croisements BUY bruts=%d | "
    "Après filtre pente=%d | "
    "Régime H1 +++=%d | "
    "Analyse M5 valide=%d",

    InpUseMaSlopeFilter
    ? "ACTIF"
    : "INACTIF",

    g_buyFunnelEvaluatedBars,
    g_buyFunnelRawCrosses,
    g_buyFunnelSlopeAccepted,
    g_buyFunnelContinuationRegime,
    g_buyFunnelLocalValid);
}


//+------------------------------------------------------------------+
//| Deuxième ligne du résumé de l'entonnoir BUY                       |
//+------------------------------------------------------------------+
string BuildBuySignalFunnelSummary2(void) {
  int configurationsWithoutOpening =
    g_buyFunnelTrendStrength -
    g_buyFunnelExecutedOpenings;

  if (configurationsWithoutOpening < 0)
  configurationsWithoutOpening = 0;

  return StringFormat(
    "Entonnoir BUY [2/3] : "
    "Quadrant M5 I=%d | "
    "Force locale >= 1.50=%d | "
    "Efficacité >= 0.60 (observation)=%d | "
    "Configurations retenues=%d | "
    "Ouvertures LONG exécutées=%d | "
    "Configurations sans ouverture=%d",

    g_buyFunnelQuadrantI,
    g_buyFunnelTrendStrength,
    g_buyFunnelDirectionalEfficiency,
    g_buyFunnelTrendStrength,
    g_buyFunnelExecutedOpenings,
    configurationsWithoutOpening);
}


//+------------------------------------------------------------------+
//| Taux de passage entre les étapes de l'entonnoir BUY               |
//+------------------------------------------------------------------+
string BuildBuySignalFunnelSummary3(void) {
  return StringFormat(
    "Entonnoir BUY [3/3] - Taux de passage : "
    "Pente/Brut=%.1f%% | "
    "Régime/Pente=%.1f%% | "
    "M5 valide/Régime=%.1f%% | "
    "Quadrant/M5=%.1f%% | "
    "Force/Quadrant=%.1f%% | "
    "Efficacité/Force (observation)=%.1f%% | "
    "Ouvertures/Configurations retenues=%.1f%%",

    BuyFunnelRate(
      g_buyFunnelSlopeAccepted,
      g_buyFunnelRawCrosses),

    BuyFunnelRate(
      g_buyFunnelContinuationRegime,
      g_buyFunnelSlopeAccepted),

    BuyFunnelRate(
      g_buyFunnelLocalValid,
      g_buyFunnelContinuationRegime),

    BuyFunnelRate(
      g_buyFunnelQuadrantI,
      g_buyFunnelLocalValid),

    BuyFunnelRate(
      g_buyFunnelTrendStrength,
      g_buyFunnelQuadrantI),

    BuyFunnelRate(
      g_buyFunnelDirectionalEfficiency,
      g_buyFunnelTrendStrength),

    BuyFunnelRate(
      g_buyFunnelExecutedOpenings,
      g_buyFunnelTrendStrength));
}


//+------------------------------------------------------------------+
//| Construit un chemin relatif dans le dossier commun                |
//+------------------------------------------------------------------+
string BuildReportRelativePath(
  const string fileName) {

  if (InpReportFolder == "")
  return fileName;

  return InpReportFolder+"\\"+fileName;
}


//+------------------------------------------------------------------+
//| Ajoute une ligne dans un fichier texte CSV du dossier commun      |
//+------------------------------------------------------------------+
bool AppendPersistentReportLine(
  const string relativePath,
  const string header,
  const string line,
  string &errorMessage) {

  errorMessage = "";

  ResetLastError();

  int fileHandle = FileOpen(
    relativePath,
    FILE_READ|
    FILE_WRITE|
    FILE_TXT|
    FILE_ANSI|
    FILE_COMMON|
    FILE_SHARE_READ|
    FILE_SHARE_WRITE,
    0,
    CP_UTF8);

  if (fileHandle == INVALID_HANDLE) {
    errorMessage = StringFormat(
      "Impossible d'ouvrir le rapport %s | Erreur=%d",
      relativePath,
      GetLastError());

    return false;
  }

  bool fileIsEmpty =
    FileSize(fileHandle) == 0;

  FileSeek(
    fileHandle,
    0,
    SEEK_END);

  if (fileIsEmpty && header != "") {
    FileWriteString(
      fileHandle,
      header+"\r\n");
  }

  FileWriteString(
    fileHandle,
    line+"\r\n");

  FileFlush(fileHandle);
  FileClose(fileHandle);

  return true;
}


//+------------------------------------------------------------------+
//| Description compacte de la stratégie candidate                   |
//+------------------------------------------------------------------+
string BuildReportStrategyDescription(void) {
  return
  "LONG depuis FLAT uniquement | "
  "H1 +++ | M5 quadrant I | "
  "force locale >= 1.50 | "
  "efficacite observee non filtrante | "
  "post-inversion interdit";
}


//+------------------------------------------------------------------+
//| Description compacte des paramètres du test                      |
//+------------------------------------------------------------------+
string BuildReportParameterDescription(void) {
  return StringFormat(
    "MA=%d | Pente=%s | LocalTF=%s | Fenetre=%d min | "
    "SL=%d | TP=%d | BE=%s@%d | "
    "ATRProtection=%s | ProfitLock=%s | Risque=%.2f%%",

    InpMaPeriod,
    InpUseMaSlopeFilter ? "ON" : "OFF",
    EnumToString(InpLocalTimeframe),
    InpLocalWindowMinutes,
    InpVirtualStopLossPoints,
    InpVirtualTakeProfitPoints,
    InpUseVirtualBreakEven ? "ON" : "OFF",
    InpVirtualBreakEvenTriggerPoints,
    InpUseAtrBasedProtection ? "ON" : "OFF",
    InpUseVirtualProfitLock ? "ON" : "OFF",
    InpVirtualRiskPercent);
}


//+------------------------------------------------------------------+
//| Description compacte de l'entonnoir BUY                          |
//+------------------------------------------------------------------+
string BuildReportBuyFunnelDescription(void) {
  return StringFormat(
    "Bars=%d | Raw=%d | Slope=%d | Regime=%d | "
    "M5=%d | QuadrantI=%d | Strength=%d | "
    "EfficiencyObs=%d | Openings=%d",

    g_buyFunnelEvaluatedBars,
    g_buyFunnelRawCrosses,
    g_buyFunnelSlopeAccepted,
    g_buyFunnelContinuationRegime,
    g_buyFunnelLocalValid,
    g_buyFunnelQuadrantI,
    g_buyFunnelTrendStrength,
    g_buyFunnelDirectionalEfficiency,
    g_buyFunnelExecutedOpenings);
}


//+------------------------------------------------------------------+
//| Écrit les rapports global et annuels persistants                  |
//+------------------------------------------------------------------+
void WritePersistentTestReports(void) {
  if (!InpWritePersistentReports)
  return;

  if (g_testFirstQuoteTime <= 0 ||
    g_testLastQuoteTime <= 0) {

    g_logger.Warning(
      "Rapports persistants non écrits : période de test indisponible.");

    return;
  }

  string SimulationEnd =
    TimeToString(
    TimeLocal(),
    TIME_DATE|TIME_SECONDS);

  string runId = StringFormat(
    "v1.25_%s_%s_%s",
    _Symbol,
    TimeToString(g_testFirstQuoteTime, TIME_DATE),
    SimulationEnd);

  string historyPath =
    BuildReportRelativePath(
    g_testHistoryFileName);

  string annualPath =
    BuildReportRelativePath(
    g_annualResultsFileName);

  string errorMessage;

  string globalLine =
    g_virtualPositions.BuildPersistentGlobalCsvLine(
    runId,
    SimulationEnd,
    "1.25",
    __FILE__,
    _Symbol,
    EnumToString(g_timeframe),
    g_testFirstQuoteTime,
    g_testLastQuoteTime,
    BuildReportStrategyDescription(),
    BuildReportParameterDescription(),
    BuildReportBuyFunnelDescription());

  if (!AppendPersistentReportLine(
      historyPath,
      g_virtualPositions.BuildPersistentGlobalCsvHeader(),
      globalLine,
      errorMessage)) {

    g_logger.Error(
      StringFormat(
        "Échec rapport global : %s",
        errorMessage));
  }

  int annualCount =
    g_virtualPositions.AnnualStatisticsCount();

  for (int index = 0;
    index < annualCount;
    index++) {

    string annualLine =
      g_virtualPositions.BuildPersistentAnnualCsvLine(
      index,
      runId,
      "1.25",
      _Symbol,
      EnumToString(g_timeframe),
      g_testFirstQuoteTime,
      g_testLastQuoteTime);

    if (annualLine == "")
    continue;

    if (!AppendPersistentReportLine(
        annualPath,
        g_virtualPositions.BuildPersistentAnnualCsvHeader(),
        annualLine,
        errorMessage)) {

      g_logger.Error(
        StringFormat(
          "Échec rapport annuel : %s",
          errorMessage));

      break;
    }
  }

  string commonReportFolder =
    TerminalInfoString(TERMINAL_COMMONDATA_PATH)+
    "\\Files\\"+
    InpReportFolder;

  g_logger.Info(
    StringFormat(
      "RAPPORTS PERSISTANTS | Dossier=%s | Global=%s | Annuel=%s",
      commonReportFolder,
      g_testHistoryFileName,
      g_annualResultsFileName));
}


//+------------------------------------------------------------------+
//| Initialisation                                                    |
//+------------------------------------------------------------------+
int OnInit(void) {
  // ==================================================
  // 1. Initialisation générale.
  // ==================================================
  g_logger.Init(InpExpertName);
  g_statistics.Reset();
  ResetBuySignalFunnel();

  g_testFirstQuoteTime = 0;
  g_testLastQuoteTime = 0;

  g_timeframe =
    (InpSignalTimeframe == PERIOD_CURRENT)
    ? (ENUM_TIMEFRAMES)_Period
    : InpSignalTimeframe;

  g_testHistoryFileName =
    "PbBzhConceptEA_TestHistory_" +
    _Symbol +
    ".csv";

  g_annualResultsFileName =
    "PbBzhConceptEA_AnnualResults_" +
    _Symbol +
    ".csv";

  // ==================================================
  // 2. Identification explicite de la version testée.
  // ==================================================
  g_logger.Info(
    StringFormat(
      "DÉMARRAGE | "
      "Version=1.25 | "
      "Source=%s | "
      "Compilation=%s | "
      "Mode volume=%s | "
      "Risque=%.2f%% | "
      "Filtre pente MA=%s",

      __FILE__,

      TimeToString(
        __DATETIME__,
        TIME_DATE|TIME_SECONDS),

      VirtualVolumeModeToString(
        InpVirtualVolumeMode),

      InpVirtualRiskPercent,

      InpUseMaSlopeFilter
      ? "ACTIF"
      : "INACTIF"));

  if (InpUseAtrBasedProtection &&
    (InpAtrStopLossMultiplier <= 0.0 ||
      InpAtrTakeProfitMultiplier <= 0.0)) {

    g_logger.Error(
      "Les multiplicateurs ATR du SL et du TP doivent être supérieurs à zéro.");

    return INIT_PARAMETERS_INCORRECT;
  }


  // ==================================================
  // 3. Horloge de bougies.
  // ==================================================
  if (!g_barClock.Init(
      _Symbol,
      g_timeframe)) {
    g_logger.Error(
      "Initialisation de l'horloge de bougies impossible.");

    return INIT_FAILED;
  }


  // ==================================================
  // 4. Signal de moyenne mobile.
  // ==================================================
  if (!g_signal.Init(
      _Symbol,
      g_timeframe,
      InpMaPeriod,
      InpMaShift,
      InpMaMethod,
      InpMaAppliedPrice,
      InpUseMaSlopeFilter)) {
    g_logger.Error(
      "Initialisation du signal de moyenne mobile impossible.");

    return INIT_FAILED;
  }

  // ==================================================
  // 5. Analyse locale multi-timeframe.
  // ==================================================
  if (!g_localPriceAnalyzer.Init(
      _Symbol,
      InpLocalTimeframe,
      InpLocalWindowMinutes)) {
    g_logger.Error(
      "Initialisation de l'analyse locale impossible.");

    return INIT_FAILED;
  }

  g_trendMaHandle = iMA(
    _Symbol,
    InpTrendTimeframe,
    InpTrendMaPeriod,
    0,
    MODE_SMA,
    PRICE_CLOSE);

  if (g_trendMaHandle == INVALID_HANDLE) {
    g_logger.Error(
      StringFormat(
        "Impossible de créer la MA de tendance | TF=%s | Période=%d | Erreur=%d",
        EnumToString(InpTrendTimeframe),
        InpTrendMaPeriod,
        GetLastError()));

    return INIT_FAILED;
  }

  // ==================================================
  // 6. ATR de volatilité H1.
  // ==================================================
  g_atrHandle = iATR(
    _Symbol,
    InpAtrTimeframe,
    InpAtrPeriod);

  if (g_atrHandle == INVALID_HANDLE) {
    g_logger.Error(
      StringFormat(
        "Impossible de créer l'ATR | "
        "TF=%s | Période=%d | Erreur=%d",

        EnumToString(
          InpAtrTimeframe),

        InpAtrPeriod,
        GetLastError()));

    return INIT_FAILED;
  }

  // ==================================================
  // 6. Affichage graphique.
  // ==================================================
  if (!g_renderer.Init(
      ChartID(),
      InpExpertName,
      _Symbol,
      g_timeframe,
      InpShowSignalArrows,
      InpSignalArrowOffsetPoints,
      InpBuyArrowColor,
      InpSellArrowColor)) {
    g_logger.Error(
      "Initialisation de l'affichage graphique impossible.");

    return INIT_FAILED;
  }


  // ==================================================
  // 7. Fournisseur de cotations.
  // ==================================================
  if (!g_quoteProvider.Init(_Symbol)) {
    g_logger.Error(
      "Initialisation du fournisseur de cotations impossible.");

    return INIT_FAILED;
  }


  // ==================================================
  // 8. Gestionnaire de positions virtuelles.
  // ==================================================
  string virtualPositionInitError;

  if (!g_virtualPositions.Init(
      _Symbol,
      InpVirtualStopLossPoints,
      InpVirtualTakeProfitPoints,
      InpVirtualVolumeMode,
      InpVirtualFixedVolumeLots,
      InpVirtualRiskPercent,
      virtualPositionInitError)) {
    g_logger.Error(
      StringFormat(
        "Initialisation du gestionnaire de positions "
        "virtuelles impossible : %s",
        virtualPositionInitError));

    return INIT_FAILED;
  }

  g_virtualPositions.ConfigureBreakEven(
    InpUseVirtualBreakEven,
    InpVirtualBreakEvenTriggerPoints);

  g_virtualPositions.ConfigureProfitLock(
    InpUseVirtualProfitLock,
    InpVirtualProfitLockTriggerPoints,
    InpVirtualProfitLockPoints);

  // ==================================================
  // 9. Fin de l'initialisation.
  // ==================================================
  g_logger.Warning(
    "Cette version simule des positions en mémoire "
    "mais ne peut envoyer aucun ordre.");

  g_logger.Info(
    StringFormat(
      "Prêt : symbole=%s, période=%s, MA=%d, "
      "filtre pente=%s, flèches=%s.",
      _Symbol,
      EnumToString(g_timeframe),
      InpMaPeriod,
      InpUseMaSlopeFilter ? "ACTIF" : "INACTIF",
      InpShowSignalArrows ? "OUI" : "NON"));

  return INIT_SUCCEEDED;
}

//+------------------------------------------------------------------+
//| Libération des ressources                                         |
//+------------------------------------------------------------------+
void OnDeinit(const int reason) {
  if (!g_virtualPositions.IsConsistent()) {
    g_logger.Error(
      "Incohérence détectée dans les statistiques "
      "des positions virtuelles.");
  } else {
    g_logger.Info(
      "Contrôle de cohérence des positions "
      "virtuelles : OK.");
  }

  if (g_trendMaHandle != INVALID_HANDLE) {
    IndicatorRelease(g_trendMaHandle);
    g_trendMaHandle = INVALID_HANDLE;
  }

  if (g_atrHandle != INVALID_HANDLE) {
    IndicatorRelease(g_atrHandle);
    g_atrHandle = INVALID_HANDLE;
  }

  g_logger.Info(StringFormat("Résumé MA=%d : %s", InpMaPeriod, g_statistics.BuildSummary()));

  g_logger.Info("---------------------------------------------");
  g_logger.Info(BuildBuySignalFunnelSummary1());
  g_logger.Info(BuildBuySignalFunnelSummary2());
  g_logger.Info(BuildBuySignalFunnelSummary3());

  LogVirtualPositionSummary();
  g_logger.Info("---------------------------------------------");
  g_logger.Info(g_virtualPositions.BuildLongSummary());
  g_logger.Info(g_virtualPositions.BuildShortSummary());
  g_logger.Info(g_virtualPositions.BuildInversionTradeSummary());
  g_logger.Info(g_virtualPositions.BuildFlatEntryTradeSummary());
  g_logger.Info("---------------------------------------------");
  g_logger.Info(g_virtualPositions.BuildInversionDirectionSummary());
  g_logger.Info(g_virtualPositions.BuildFlatEntryDirectionSummary());
  g_logger.Info("---------------------------------------------");
  g_logger.Info(g_virtualPositions.BuildFlatWinningMaDynamicsSummary());
  g_logger.Info(g_virtualPositions.BuildFlatLosingMaDynamicsSummary());
  g_logger.Info("---------------------------------------------");
  g_logger.Info(g_virtualPositions.BuildFlatWinningLocalDynamicsSummary());
  g_logger.Info(g_virtualPositions.BuildFlatLosingLocalDynamicsSummary());
  g_logger.Info("---------------------------------------------");
  g_logger.Info(g_virtualPositions.BuildLosingTradeMfeSummary());
  g_logger.Info(g_virtualPositions.BuildEntryAtrSummary());
  g_logger.Info(g_virtualPositions.BuildDrawdownTimingSummary());
  g_logger.Info(g_virtualPositions.BuildLongExitMatrixSummary());
  g_logger.Info(g_virtualPositions.BuildShortExitMatrixSummary());
  g_logger.Info(g_virtualPositions.BuildLongSignalDetailSummary());
  g_logger.Info(g_virtualPositions.BuildShortSignalDetailSummary());
  g_logger.Info(g_virtualPositions.BuildFlatEntryExitMatrixSummary());
  g_logger.Info(g_virtualPositions.BuildInversionEntryExitMatrixSummary());
  g_logger.Info(g_virtualPositions.BuildSignalExitSummary());
  g_logger.Info(g_virtualPositions.BuildStopLossSummary());
  g_logger.Info(g_virtualPositions.BuildTakeProfitSummary());
  g_logger.Info(g_virtualPositions.BuildFlatEntrySlopeSummary());
  g_logger.Info(g_virtualPositions.BuildInversionEntrySlopeSummary());
  g_logger.Info(g_virtualPositions.BuildInversionWinningMaDynamicsSummary());
  g_logger.Info(g_virtualPositions.BuildInversionLosingMaDynamicsSummary());
  g_logger.Info(g_virtualPositions.BuildFlatLocalQuadrantSummary());
  g_logger.Info(g_virtualPositions.BuildInversionLocalQuadrantSummary());
  g_logger.Info(g_virtualPositions.BuildInversionMaRegimeLocalQuadrantSummary(PB_MA_REGIME_CONTINUATION));
  g_logger.Info(g_virtualPositions.BuildInversionMaRegimeLocalQuadrantSummary(PB_MA_REGIME_REVERSAL_EARLY));
  g_logger.Info(g_virtualPositions.BuildInversionMaRegimeLocalQuadrantSummary(PB_MA_REGIME_REVERSAL_LATE));
  g_logger.Info(g_virtualPositions.BuildInversionMaRegimeLocalQuadrantSummary(PB_MA_REGIME_OSCILLATION));
  g_logger.Info(g_virtualPositions.BuildInversionReversalLateQuadrantIIIProfileSummary());
  g_logger.Info(g_virtualPositions.BuildInversionReversalLateQuadrantIIIWinningProfileSummary());
  g_logger.Info(g_virtualPositions.BuildInversionReversalLateQuadrantIIILosingProfileSummary());
  g_logger.Info(g_virtualPositions.BuildInversionReversalLateQuadrantIIIWinningTurningTimeSummary());
  g_logger.Info(g_virtualPositions.BuildInversionReversalLateQuadrantIIILosingTurningTimeSummary());
  g_logger.Info(g_virtualPositions.BuildInversionContinuationQuadrantIProfileSummary());
  g_logger.Info(g_virtualPositions.BuildInversionWinningLocalDynamicsSummary());
  g_logger.Info(g_virtualPositions.BuildInversionLosingLocalDynamicsSummary());

  g_logger.Info("---------------------------------------------");
  g_logger.Info("BILANS ANNUELS DU TEST CONTINU");

  int annualCount =
    g_virtualPositions.AnnualStatisticsCount();

  for (int annualIndex = 0;
    annualIndex < annualCount;
    annualIndex++) {

    g_logger.Info(
      g_virtualPositions.BuildAnnualSummary(
        annualIndex));
  }

  WritePersistentTestReports();

  g_signal.Deinit();
  g_logger.Info(StringFormat("Arrêt de l'EA. Motif=%d.", reason));
}


//+------------------------------------------------------------------+
//| Traitement d'un nouveau tick                                      |
//+------------------------------------------------------------------+
void OnTick(void) {
  // ==================================================
  // 1. Lecture de la cotation à CHAQUE tick.
  // ==================================================
  SExecutionQuote executionQuote;

  if (!g_quoteProvider.Read(executionQuote)) {
    // CExecutionQuoteProvider écrit déjà le détail
    // de l'erreur dans le journal.
    return;
  }

  if (g_testFirstQuoteTime == 0)
  g_testFirstQuoteTime = executionQuote.time;

  g_testLastQuoteTime = executionQuote.time;


  // ==================================================
  // 2. Surveillance de la position à CHAQUE tick.
  // ==================================================
  string protectionEvent;

  if (!g_virtualPositions.ProcessTick(
      executionQuote.time,
      executionQuote.bid,
      executionQuote.ask,
      protectionEvent)) {
    g_logger.Error(
      StringFormat(
        "Erreur de surveillance virtuelle : %s",
        protectionEvent));

    return;
  }

  if (protectionEvent != "") {
    g_logger.Info(
      StringFormat(
        "SIMULATION | %s",
        protectionEvent));
  }


  // ==================================================
  // 3. Le signal reste limité aux nouvelles bougies.
  // ==================================================
  if (!g_barClock.IsNewBar())
  return;


  // ==================================================
  // 4. Calcul du signal sur les bougies clôturées.
  // ==================================================
  SMaPriceCrossSnapshot snapshot;

  if (!g_signal.Evaluate(snapshot)) {
    g_statistics.RecordError();

    g_logger.Error(
      "Le signal n'a pas pu être calculé "
      "pour la nouvelle bougie.");

    return;
  }

  g_statistics.RecordSignal(snapshot.signal);

  // --------------------------------------------------
  // Premières étapes de l'entonnoir BUY.
  // Le croisement brut est recalculé à partir des
  // mêmes données que CMaPriceCrossSignal.
  // --------------------------------------------------
  g_buyFunnelEvaluatedBars++;

  bool rawBuyCross =
    snapshot.bar2Close <= snapshot.bar2Ma &&
    snapshot.bar1Close > snapshot.bar1Ma;

  bool buyAcceptedBySlopeFilter =
    rawBuyCross &&
    snapshot.signal == PB_SIGNAL_BUY;

  if (rawBuyCross)
  g_buyFunnelRawCrosses++;

  if (buyAcceptedBySlopeFilter)
  g_buyFunnelSlopeAccepted++;


  string message = StringFormat(
    "SignalBar[1]=%s | "
    "Bar[0]=%s Open[0]=%.*f | "
    "Close[2]=%.*f MA[2]=%.*f | "
    "Close[1]=%.*f MA[1]=%.*f | "
    "Décision=%s",

    TimeToString(
      snapshot.bar1OpenTime,
      TIME_DATE|TIME_MINUTES),

    TimeToString(
      snapshot.bar0OpenTime,
      TIME_DATE|TIME_MINUTES),

    _Digits,
    snapshot.bar0Open,

    _Digits,
    snapshot.bar2Close,

    _Digits,
    snapshot.bar2Ma,

    _Digits,
    snapshot.bar1Close,

    _Digits,
    snapshot.bar1Ma,

    TradeSignalToString(snapshot.signal));


  // ==================================================
  // 5. Journalisation et affichage.
  // ==================================================
  if (snapshot.signal == PB_SIGNAL_NONE) {
    g_logger.Info(message);
  } else {
    g_logger.Signal(message);

    g_logger.Info(
      StringFormat(
        "COTATION | Date=%s | "
        "Open[0]=%.*f | "
        "Bid=%.*f | Ask=%.*f | "
        "Spread=%.1f points",

        TimeToString(
          executionQuote.time,
          TIME_DATE|TIME_MINUTES),

        _Digits,
        snapshot.bar0Open,

        _Digits,
        executionQuote.bid,

        _Digits,
        executionQuote.ask,

        executionQuote.spreadPoints));

    if (!g_renderer.Draw(
        snapshot.signal,
        snapshot.bar1OpenTime,
        snapshot.bar1High,
        snapshot.bar1Low)) {
      g_logger.Warning(
        "Le signal a été calculé, mais sa flèche "
        "n'a pas pu être affichée.");
    }
  }


  // ==================================================
  // 6. Traitement du signal à la nouvelle bougie.
  // ==================================================
  string virtualEvent;

  SLocalMarketDynamics localDynamics;

  ZeroMemory(localDynamics);

  localDynamics.isValid = false;


  // --------------------------------------------------
  // Diagnostic temporaire de la pente de MA
  // au moment du signal.
  // --------------------------------------------------
  if (snapshot.signal != PB_SIGNAL_NONE) {
    string signalText =
      snapshot.signal == PB_SIGNAL_BUY
      ? "BUY"
      : "SELL";

    ENUM_PB_MA_DYNAMICS_REGIME maRegime =
      DetermineMaDynamicsRegime(
      snapshot.directionalMaDynamics);

    string maRegimeText =
      MaDynamicsRegimeToString(
      maRegime);

    g_logger.Info(
      StringFormat(
        "DIAG DYNAMIQUE | Signal=%s | "
        "S2=%.2f | S1=%.2f | S0=%.2f pts | "
        "A1=%.2f | A0=%.2f pts/bougie^2 | "
        "Régime=%s",

        signalText,

        snapshot.directionalMaDynamics.slopeEarlier,
        snapshot.directionalMaDynamics.slopePrevious,
        snapshot.directionalMaDynamics.slopeCurrent,
        snapshot.directionalMaDynamics.accelerationPrevious,
        snapshot.directionalMaDynamics.accelerationCurrent,
        maRegimeText));
    SLocalPriceWindowSnapshot localWindow;

    datetime localReferenceTime =
      snapshot.bar1OpenTime+
      PeriodSeconds(InpSignalTimeframe);

    if (g_localPriceAnalyzer.Analyze(
        localReferenceTime,
        localWindow)) {

      double direction =
        snapshot.signal == PB_SIGNAL_BUY
        ? 1.0
        : -1.0;

      double directionalChange =
        localWindow.netChangePoints*
        direction;

      double directionalSlope =
        localWindow.localSlopePointsPerHour*
        direction;

      double directionalCurvature =
        localWindow.localCurvaturePointsPerHour2*
        direction;

      localDynamics.isValid =
        localWindow.isComplete &&
        localWindow.quadraticFitValid;

      localDynamics.directionalChangePoints =
        directionalChange;

      localDynamics.rangePoints =
        localWindow.rangePoints;

      localDynamics.directionalSlopePointsPerHour =
        directionalSlope;

      localDynamics.directionalCurvaturePointsPerHour2 =
        directionalCurvature;

      localDynamics.quadraticRSquared =
        localWindow.quadraticRSquared;

      ENUM_PB_LOCAL_DYNAMICS_QUADRANT localQuadrant =
        DetermineLocalDynamicsQuadrant(
        localDynamics);

      string localQuadrantText =
        LocalDynamicsQuadrantToString(
        localQuadrant);

      if (!localDynamics.isValid) {
        g_logger.Warning(
          StringFormat(
            "DIAG LOCAL INVALIDE | "
            "Signal=%s | Heure=%s | "
            "Barres=%d/%d | Complète=%s | Fit=%s",

            signalText,

            TimeToString(
              localReferenceTime,
              TIME_DATE|TIME_MINUTES),

            localWindow.barCount,
            localWindow.expectedBars,

            localWindow.isComplete
            ? "OUI"
            : "NON",

            localWindow.quadraticFitValid
            ? "OUI"
            : "NON"));
      }


      g_logger.Info(
        StringFormat(
          "DIAG LOCAL | "
          "TF=%s | Signal=%s | "
          "Fenêtre=%s -> %s | "
          "Barres=%d/%d | "
          "Complète=%s | "
          "Variation=%.2f pts | "
          "Variation dir.=%.2f pts | "
          "Amplitude=%.2f pts | "
          "Fit=%s | "
          "Points fit=%d | "
          "Pente dir.=%.2f pts/h | "
          "Courbure dir.=%.2f pts/h^2 | "
          "Quadrant=%s | "
          "R2=%.4f",

          EnumToString(
            InpLocalTimeframe),

          signalText,

          TimeToString(
            localWindow.windowStartTime,
            TIME_DATE|TIME_MINUTES),

          TimeToString(
            localWindow.referenceTime,
            TIME_DATE|TIME_MINUTES),

          localWindow.barCount,
          localWindow.expectedBars,

          localWindow.isComplete
          ? "OUI"
          : "NON",

          localWindow.netChangePoints,
          directionalChange,
          localWindow.rangePoints,

          localWindow.quadraticFitValid
          ? "OK"
          : "NON",

          localWindow.fitPointCount,

          directionalSlope,
          directionalCurvature,

          localQuadrantText,

          localWindow.quadraticRSquared));
    } else {
      g_logger.Warning(
        StringFormat(
          "DIAG LOCAL ECHEC | "
          "Signal=%s | Heure=%s | "
          "TF=%s | Fenêtre=%d min",

          signalText,

          TimeToString(
            snapshot.bar0OpenTime,
            TIME_DATE|TIME_MINUTES),

          EnumToString(
            InpLocalTimeframe),

          InpLocalWindowMinutes));
    }
  }

  ENUM_PB_MA_DYNAMICS_REGIME maRegime =
    DetermineMaDynamicsRegime(
    snapshot.directionalMaDynamics);

  ENUM_PB_LOCAL_DYNAMICS_QUADRANT localQuadrant =
    DetermineLocalDynamicsQuadrant(
    localDynamics);


  double localTrendStrength = 0.0;

  if (localDynamics.isValid &&
    localDynamics.rangePoints > 0.0) {

    localTrendStrength =
      localDynamics.directionalSlopePointsPerHour /
      localDynamics.rangePoints;
  }

  double localDirectionalEfficiency = 0.0;

  if (localDynamics.isValid &&
    localDynamics.rangePoints > 0.0) {

    localDirectionalEfficiency =
      localDynamics.directionalChangePoints /
      localDynamics.rangePoints;
  }

  // --------------------------------------------------
  // Étapes cumulatives suivantes de l'entonnoir BUY.
  // Ces compteurs restent purement observateurs et ne
  // modifient aucune décision de la stratégie.
  // --------------------------------------------------
  bool buyContinuationAccepted =
    buyAcceptedBySlopeFilter &&
    maRegime == PB_MA_REGIME_CONTINUATION;

  bool buyLocalAnalysisAccepted =
    buyContinuationAccepted &&
    localDynamics.isValid;

  bool buyQuadrantAccepted =
    buyLocalAnalysisAccepted &&
    localQuadrant == PB_LOCAL_QUADRANT_I;

  bool buyTrendStrengthAccepted =
    buyQuadrantAccepted &&
    localTrendStrength >= 1.50;

  bool buyDirectionalEfficiencyAccepted =
    buyTrendStrengthAccepted &&
    localDirectionalEfficiency >= 0.60;

  if (buyContinuationAccepted)
  g_buyFunnelContinuationRegime++;

  if (buyLocalAnalysisAccepted)
  g_buyFunnelLocalValid++;

  if (buyQuadrantAccepted)
  g_buyFunnelQuadrantI++;

  if (buyTrendStrengthAccepted)
  g_buyFunnelTrendStrength++;

  if (buyDirectionalEfficiencyAccepted)
  g_buyFunnelDirectionalEfficiency++;

  // --------------------------------------------------
  // Contexte H4.
  // --------------------------------------------------
  double trendClose1 = 0.0;
  double trendMa1 = 0.0;
  double trendMa2 = 0.0;

  bool trendContextValid =
    TryGetTrendContext(
    trendClose1,
    trendMa1,
    trendMa2);

  if (snapshot.signal != PB_SIGNAL_NONE) {

    if (trendContextValid) {

      g_logger.Info(
        StringFormat(
          "DIAG H4 | TF=%s | Close[1]=%.*f | MA[1]=%.*f | MA[2]=%.*f | "
          "Cours/MA=%s | Pente MA=%s",
          EnumToString(InpTrendTimeframe),
          _Digits,
          trendClose1,
          _Digits,
          trendMa1,
          _Digits,
          trendMa2,
          trendClose1 > trendMa1
          ? "AU-DESSUS"
          : trendClose1 < trendMa1
          ? "EN-DESSOUS"
          : "EGAL",
          trendMa1 > trendMa2
          ? "HAUSSE"
          : trendMa1 < trendMa2
          ? "BAISSE"
          : "PLATE"));
    } else {

      g_logger.Warning(
        StringFormat(
          "DIAG H4 | Contexte indisponible | TF=%s",
          EnumToString(InpTrendTimeframe)));
    }
  }

  bool trendAligned = false;

  if (trendContextValid) {

    if (snapshot.signal == PB_SIGNAL_BUY) {

      trendAligned =
        trendClose1 > trendMa1 &&
        trendMa1 > trendMa2;
    } else if (snapshot.signal == PB_SIGNAL_SELL) {

      trendAligned =
        trendClose1 < trendMa1 &&
        trendMa1 < trendMa2;
    }
  }

  // Entrée depuis FLAT :
  // tendance H1 établie, dynamique M5 favorable
  // et mouvement local suffisamment énergique.
  bool allowFlatEntry =
    snapshot.signal == PB_SIGNAL_BUY &&
    maRegime == PB_MA_REGIME_CONTINUATION &&
    localQuadrant == PB_LOCAL_QUADRANT_I &&
    localTrendStrength >= 1.50;

  // Réouverture après une sortie sur signal :
  // configuration de retournement retenue par l'étude v1.20.
  bool allowReversalEntry = false;
  //maRegime == PB_MA_REGIME_REVERSAL_LATE &&
  //localQuadrant == PB_LOCAL_QUADRANT_III;

  // --------------------------------------------------
  // ATR H1 de la dernière bougie clôturée.
  // Les distances calculées ici sont figées pour
  // toute la durée de la nouvelle position.
  // --------------------------------------------------
  double entryAtrPrice = 0.0;
  double entryAtrPoints = 0.0;

  bool entryAtrValid = false;

  if (snapshot.signal != PB_SIGNAL_NONE) {
    entryAtrValid =
      TryGetAtrContext(
      entryAtrPrice,
      entryAtrPoints);
  }

  int entryStopLossPoints =
    InpVirtualStopLossPoints;

  int entryTakeProfitPoints =
    InpVirtualTakeProfitPoints;

  int entryBreakEvenTriggerPoints =
    InpVirtualBreakEvenTriggerPoints;

  bool entryProtectionUsesAtr =
    InpUseAtrBasedProtection &&
    entryAtrValid &&
    entryAtrPoints > 0.0;

  if (entryProtectionUsesAtr) {
    entryStopLossPoints =
      (int)MathRound(
      entryAtrPoints *
      InpAtrStopLossMultiplier);

    entryTakeProfitPoints =
      (int)MathRound(
      entryAtrPoints *
      InpAtrTakeProfitMultiplier);

    // Le break-even reste déclenché à +1R.
    entryBreakEvenTriggerPoints =
      entryStopLossPoints;

    // Repli de sécurité en cas de distance invalide.
    if (entryStopLossPoints <= 0 ||
      entryTakeProfitPoints <= 0) {

      entryProtectionUsesAtr = false;

      entryStopLossPoints =
        InpVirtualStopLossPoints;

      entryTakeProfitPoints =
        InpVirtualTakeProfitPoints;

      entryBreakEvenTriggerPoints =
        InpVirtualBreakEvenTriggerPoints;
    }
  }


  if (!g_virtualPositions.ProcessSignal(
      snapshot.signal,
      snapshot.directionalMaDynamics,
      localDynamics,
      executionQuote.time,
      executionQuote.bid,
      executionQuote.ask,
      virtualEvent,
      allowFlatEntry,
      allowReversalEntry,
      entryAtrValid,
      entryAtrPoints,
      entryStopLossPoints,
      entryTakeProfitPoints,
      entryBreakEvenTriggerPoints)) {

    g_logger.Error(
      StringFormat(
        "Erreur de simulation : %s",
        virtualEvent));

    return;
  }

  if (virtualEvent != "") {
    g_logger.Info(
      StringFormat(
        "SIMULATION | %s",
        virtualEvent));
  }


  // --------------------------------------------------
  // Dernière étape de l'entonnoir : ouverture LONG
  // réellement exécutée depuis une position FLAT.
  // --------------------------------------------------
  bool longFlatOpeningExecuted =
    snapshot.signal == PB_SIGNAL_BUY &&
    StringFind(
    virtualEvent,
    "OUVERTURE VIRTUELLE |") == 0;

  if (longFlatOpeningExecuted)
  g_buyFunnelExecutedOpenings++;


  // --------------------------------------------------
  // Une observation ATR n'est enregistrée que si le
  // signal a réellement ouvert une nouvelle position.
  // --------------------------------------------------
  bool positionOpened =
    StringFind(
    virtualEvent,
    "OUVERTURE VIRTUELLE |") == 0 ||
    StringFind(
    virtualEvent,
    "INVERSION VIRTUELLE |") == 0;


  if (positionOpened) {

    string protectionMode = "FIXE";

    if (entryProtectionUsesAtr)
    protectionMode = "ATR";
    else if (InpUseAtrBasedProtection)
    protectionMode = "FIXE_REPLI";

    if (entryAtrValid &&
      entryAtrPoints > 0.0) {

      double stopLossAtr =
        (double)entryStopLossPoints /
        entryAtrPoints;

      double takeProfitAtr =
        (double)entryTakeProfitPoints /
        entryAtrPoints;

      double breakEvenAtr =
        (double)entryBreakEvenTriggerPoints /
        entryAtrPoints;


      g_logger.Info(
        StringFormat(
          "DIAG PROTECTIONS ENTRÉE | "
          "Mode=%s | "
          "TF=%s | "
          "Période=%d | "
          "ATR[1]=%.*f | "
          "ATR=%.1f points | "
          "SL=%d points (%.2f ATR) | "
          "TP=%d points (%.2f ATR) | "
          "BE=%d points (%.2f ATR)",

          protectionMode,

          EnumToString(
            InpAtrTimeframe),

          InpAtrPeriod,

          _Digits,
          entryAtrPrice,

          entryAtrPoints,

          entryStopLossPoints,
          stopLossAtr,

          entryTakeProfitPoints,
          takeProfitAtr,

          entryBreakEvenTriggerPoints,
          breakEvenAtr));
    } else {

      g_logger.Warning(
        StringFormat(
          "DIAG PROTECTIONS ENTRÉE | "
          "Mode=FIXE_REPLI | "
          "ATR indisponible | "
          "TF=%s | Période=%d | "
          "SL=%d points | TP=%d points | "
          "BE=%d points",

          EnumToString(
            InpAtrTimeframe),

          InpAtrPeriod,
          entryStopLossPoints,
          entryTakeProfitPoints,
          entryBreakEvenTriggerPoints));
    }
  }
}


bool TryGetTrendContext(
  double &close1,
  double &ma1,
  double &ma2) {

  close1 = 0.0;
  ma1 = 0.0;
  ma2 = 0.0;

  if (g_trendMaHandle == INVALID_HANDLE)
  return false;

  if (BarsCalculated(g_trendMaHandle) < 3)
  return false;


  double closeBuffer[1];
  double ma1Buffer[1];
  double ma2Buffer[1];

  if (CopyClose(
      _Symbol,
      InpTrendTimeframe,
      1,
      1,
      closeBuffer) != 1) {

    return false;
  }

  if (CopyBuffer(
      g_trendMaHandle,
      0,
      1,
      1,
      ma1Buffer) != 1) {

    return false;
  }

  if (CopyBuffer(
      g_trendMaHandle,
      0,
      2,
      1,
      ma2Buffer) != 1) {

    return false;
  }


  close1 = closeBuffer[0];
  ma1 = ma1Buffer[0];
  ma2 = ma2Buffer[0];

  return true;
}


//+------------------------------------------------------------------+
//| Lecture de l'ATR de la dernière bougie clôturée                   |
//+------------------------------------------------------------------+
bool TryGetAtrContext(
  double &atrPrice,
  double &atrPoints) {

  atrPrice = 0.0;
  atrPoints = 0.0;

  if (g_atrHandle == INVALID_HANDLE)
  return false;

  if (InpAtrPeriod <= 0)
  return false;

  if (BarsCalculated(g_atrHandle) <
    InpAtrPeriod + 1) {

    return false;
  }

  double atrBuffer[1];

  if (CopyBuffer(
      g_atrHandle,
      0,
      1,
      1,
      atrBuffer) != 1) {

    return false;
  }

  atrPrice = atrBuffer[0];

  if (atrPrice <= 0.0 ||
    _Point <= 0.0) {

    return false;
  }

  atrPoints =
    atrPrice / _Point;

  return true;
}


// --------------------------------------------------
// Affiche le résumé des positions virtuelles sur
// plusieurs lignes afin d'éviter sa troncature dans
// le journal du Testeur.
// --------------------------------------------------
void LogVirtualPositionSummary(void) {
  string summary =
    g_virtualPositions.BuildSummary();


  // Les marqueurs correspondent aux séparations
  // déjà présentes dans BuildSummary().
  string performanceMarker =
    " | Somme gains=";

  string capitalMarker =
    " | Mode volume=";

  string positionMarker =
    " | Position ouverte=";


  int performancePosition =
    StringFind(
    summary,
    performanceMarker);

  int capitalPosition =
    StringFind(
    summary,
    capitalMarker);

  int positionPosition =
    StringFind(
    summary,
    positionMarker);


  // ------------------------------------------------
  // Sécurité :
  // si la structure du résumé a été modifiée et que
  // les marqueurs ne sont plus trouvés, on conserve
  // l'ancien affichage.
  // ------------------------------------------------
  if (performancePosition < 0 ||
    capitalPosition < 0 ||
    positionPosition < 0 ||
    performancePosition >= capitalPosition ||
    capitalPosition >= positionPosition) {
    g_logger.Info(
      StringFormat(
        "Résumé positions virtuelles : %s",
        summary));

    return;
  }


  // Longueur de la chaîne séparatrice " | ".
  const int separatorLength = 3;


  // ------------------------------------------------
  // Ligne 1 : nombres de trades et résultats points.
  // ------------------------------------------------
  string positionsSummary =
    StringSubstr(
    summary,
    0,
    performancePosition);


  // ------------------------------------------------
  // Ligne 2 : performances monétaires.
  // ------------------------------------------------
  int performanceStart =
    performancePosition+
    separatorLength;

  string performanceSummary =
    StringSubstr(
    summary,
    performanceStart,
    capitalPosition-
    performanceStart);


  // ------------------------------------------------
  // Ligne 3 : capital et gestion du volume.
  // ------------------------------------------------
  int capitalStart =
    capitalPosition+
    separatorLength;

  string capitalSummary =
    StringSubstr(
    summary,
    capitalStart,
    positionPosition-
    capitalStart);


  // ------------------------------------------------
  // Ligne 4 : position éventuellement encore ouverte.
  // ------------------------------------------------
  int positionStart =
    positionPosition+
    separatorLength;

  string openPositionSummary =
    StringSubstr(
    summary,
    positionStart);


  g_logger.Info(
    StringFormat(
      "Résumé positions [1/4] : %s",
      positionsSummary));

  g_logger.Info(
    StringFormat(
      "Résumé performances [2/4] : %s",
      performanceSummary));

  g_logger.Info(
    StringFormat(
      "Résumé capital [3/4] : %s",
      capitalSummary));

  g_logger.Info(
    StringFormat(
      "Résumé position finale [4/4] : %s",
      openPositionSummary));
}
