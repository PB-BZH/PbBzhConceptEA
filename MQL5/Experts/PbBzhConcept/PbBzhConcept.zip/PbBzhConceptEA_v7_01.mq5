//+------------------------------------------------------------------+
//|                       PbBzhConceptEA_v7_01.mq5                   |
//|  v7.01 : profileur intrajournalier GOLD M15/H1 optimisé         |
//+------------------------------------------------------------------+
#property copyright "Copyright 2026, PbBzhConcept"
#property version   "7.01"
#property strict
#property description "GOLD : analyse intrajournalière par sessions"
#property description "Observation M15, contexte ATR/ADX H1"
#property description "Cassures, fausses cassures et prolongements"
#property description "Aucun ordre réel ou virtuel n'est ouvert"

#include <PbBzhConcept\Analysis\GoldIntradaySessionProfiler_v7_01.mqh>

input group "Unités de temps"
input ENUM_TIMEFRAMES InpSignalTimeframe = PERIOD_M15;
input ENUM_TIMEFRAMES InpContextTimeframe = PERIOD_H1;

input group "Contexte descriptif"
input int InpContextAtrPeriod = 14;
input int InpContextAdxPeriod = 14;

input group "Étude des cassures"
input int InpBreakoutLookbackBars = 4;
input int InpFollowThroughBars = 4;
input double InpFollowThroughAtrThreshold = 0.50;

input group "Sessions — heures du serveur MT5"
input int InpEuropeStartHour = 7;
input int InpEuropeUsaStartHour = 13;
input int InpUsaStartHour = 17;
input int InpRolloverStartHour = 21;
input int InpAsiaStartHour = 22;

input group "Affichage"
input bool InpShowStatusOnChart = true;

CGoldIntradaySessionProfiler g_sessionProfiler;


//+------------------------------------------------------------------+
//| Vérifie que le symbole ressemble à GOLD ou XAU                  |
//+------------------------------------------------------------------+
bool SymbolLooksLikeGold(void) {
  string symbolName = _Symbol;
  StringToUpper(symbolName);

  return StringFind(symbolName, "GOLD") >= 0 ||
    StringFind(symbolName, "XAU") >= 0;
}


//+------------------------------------------------------------------+
//| Initialisation                                                   |
//+------------------------------------------------------------------+
int OnInit(void) {
  if (!SymbolLooksLikeGold()) {
    PrintFormat(
      "[%s][WARNING] La v7.01 est conçue pour GOLD/XAU. "
      "Symbole courant=%s",
      __FILE__,
      _Symbol);
  }

  if (!g_sessionProfiler.Initialize(
    _Symbol,
    InpSignalTimeframe,
    InpContextTimeframe,
    InpContextAtrPeriod,
    InpContextAdxPeriod,
    InpBreakoutLookbackBars,
    InpFollowThroughBars,
    InpFollowThroughAtrThreshold,
    InpEuropeStartHour,
    InpEuropeUsaStartHour,
    InpUsaStartHour,
    InpRolloverStartHour,
    InpAsiaStartHour)) {

    return INIT_FAILED;
  }

  PrintFormat(
    "[%s][INFO] DÉMARRAGE | Profil=GOLD SESSION PROFILER | "
    "Symbole=%s | Signal=%s | Contexte=%s | ATR=%d | ADX=%d | "
    "Cassure=%d bougies | Prolongement=%d bougies | Seuil=%.2f ATR | "
    "Sessions serveur : ASIE=%02dh-%02dh | EUROPE=%02dh-%02dh | "
    "EUROPE_USA=%02dh-%02dh | USA=%02dh-%02dh | "
    "ROLLOVER=%02dh-%02dh | Mode=ANALYSE_SANS_TRADING",
    __FILE__,
    _Symbol,
    EnumToString(InpSignalTimeframe),
    EnumToString(InpContextTimeframe),
    InpContextAtrPeriod,
    InpContextAdxPeriod,
    InpBreakoutLookbackBars,
    InpFollowThroughBars,
    InpFollowThroughAtrThreshold,
    InpAsiaStartHour,
    InpEuropeStartHour,
    InpEuropeStartHour,
    InpEuropeUsaStartHour,
    InpEuropeUsaStartHour,
    InpUsaStartHour,
    InpUsaStartHour,
    InpRolloverStartHour,
    InpRolloverStartHour,
    InpAsiaStartHour);

  return INIT_SUCCEEDED;
}


//+------------------------------------------------------------------+
//| Désinitialisation                                                |
//+------------------------------------------------------------------+
void OnDeinit(const int reason) {
  g_sessionProfiler.PrintFinalReport();
  g_sessionProfiler.Shutdown();
  Comment("");

  PrintFormat(
    "[%s][INFO] ARRÊT | Raison=%d",
    __FILE__,
    reason);
}


//+------------------------------------------------------------------+
//| Tick                                                             |
//+------------------------------------------------------------------+
void OnTick(void) {
  MqlTick tick;

  if (!SymbolInfoTick(_Symbol, tick))
    return;

  bool newSignalBar = g_sessionProfiler.ProcessTick(tick);

  // L'affichage n'est reconstruit qu'au premier tick de chaque bougie.
  if (InpShowStatusOnChart && newSignalBar) {
    Comment(
      __FILE__, "\n",
      g_sessionProfiler.BuildStatusText((datetime)tick.time));
  }
}
