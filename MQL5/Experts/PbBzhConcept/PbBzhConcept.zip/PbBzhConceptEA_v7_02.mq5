//+------------------------------------------------------------------+
//|                       PbBzhConceptEA_v7_02.mq5                   |
//|  v7.02 : recherche conditionnelle d'un signal GOLD M15/H1       |
//+------------------------------------------------------------------+
#property copyright "Copyright 2026, PbBzhConcept"
#property version   "7.02"
#property strict
#property description "GOLD : analyse conditionnelle des cassures M15"
#property description "Direction, heure, contexte EMA H1 et compression"
#property description "Mesures à 1 h, 2 h et 4 h normalisées par ATR"
#property description "Aucun ordre réel ou virtuel n'est ouvert"

#include <PbBzhConcept\Analysis\GoldIntradayConditionalProfiler_v7_02.mqh>

input group "Unités de temps"
input ENUM_TIMEFRAMES InpSignalTimeframe = PERIOD_M15;
input ENUM_TIMEFRAMES InpContextTimeframe = PERIOD_H1;

input group "Contexte H1"
input int InpContextAtrPeriod = 14;
input int InpContextTrendEmaPeriod = 50;
input double InpTrendNeutralAtrBand = 0.10;

input group "Cassure et volatilité préalable"
input int InpBreakoutLookbackBars = 4;
input double InpCompressionMaximumAtr = 0.75;
input double InpExpansionMinimumAtr = 1.25;
input double InpSuccessThresholdAtr = 0.50;

input group "Sessions — heures du serveur MT5"
input int InpEuropeStartHour = 7;
input int InpEuropeUsaStartHour = 13;
input int InpUsaStartHour = 17;
input int InpRolloverStartHour = 21;
input int InpAsiaStartHour = 22;

input group "Rapport horaire"
input int InpHourlyReportStartHour = 7;
input int InpHourlyReportEndHour = 21;

input group "Affichage"
input bool InpShowStatusOnChart = true;

CGoldIntradayConditionalProfiler g_conditionalProfiler;


//+------------------------------------------------------------------+
//| Vérifie que le symbole ressemble à GOLD ou XAU                  |
//+------------------------------------------------------------------+
bool SymbolLooksLikeGold(void) {
  string symbolName = _Symbol;
  StringToUpper(symbolName);

  return StringFind(symbolName, "GOLD") >= 0 ||
    StringFind(symbolName, "XAU") >= 0;
}


//+------------------------------------------------------------------+
//| Initialisation                                                   |
//+------------------------------------------------------------------+
int OnInit(void) {
  if (!SymbolLooksLikeGold()) {
    PrintFormat(
      "[%s][WARNING] La v7.02 est conçue pour GOLD/XAU. "
      "Symbole courant=%s",
      __FILE__,
      _Symbol);
  }

  if (!g_conditionalProfiler.Initialize(
    _Symbol,
    InpSignalTimeframe,
    InpContextTimeframe,
    InpContextAtrPeriod,
    InpContextTrendEmaPeriod,
    InpTrendNeutralAtrBand,
    InpBreakoutLookbackBars,
    InpCompressionMaximumAtr,
    InpExpansionMinimumAtr,
    InpSuccessThresholdAtr,
    InpEuropeStartHour,
    InpEuropeUsaStartHour,
    InpUsaStartHour,
    InpRolloverStartHour,
    InpAsiaStartHour,
    InpHourlyReportStartHour,
    InpHourlyReportEndHour)) {

    return INIT_FAILED;
  }

  PrintFormat(
    "[%s][INFO] DÉMARRAGE | Profil=GOLD CONDITIONAL PROFILER | "
    "Symbole=%s | Signal=%s | Contexte=%s | ATR=%d | EMA=%d | "
    "Bande neutre=%.2f ATR | Cassure=%d bougies | "
    "Compression<%.2f ATR | Expansion>%.2f ATR | "
    "Succès>=%.2f ATR | Horizons=1h/2h/4h | "
    "Périodes=A:2019-2020 B:2021-2023 C:2024-fin | "
    "Mode=ANALYSE_SANS_TRADING",
    __FILE__,
    _Symbol,
    EnumToString(InpSignalTimeframe),
    EnumToString(InpContextTimeframe),
    InpContextAtrPeriod,
    InpContextTrendEmaPeriod,
    InpTrendNeutralAtrBand,
    InpBreakoutLookbackBars,
    InpCompressionMaximumAtr,
    InpExpansionMinimumAtr,
    InpSuccessThresholdAtr);

  return INIT_SUCCEEDED;
}


//+------------------------------------------------------------------+
//| Désinitialisation                                                |
//+------------------------------------------------------------------+
void OnDeinit(const int reason) {
  g_conditionalProfiler.PrintFinalReport();
  g_conditionalProfiler.Shutdown();
  Comment("");

  PrintFormat(
    "[%s][INFO] ARRÊT | Raison=%d",
    __FILE__,
    reason);
}


//+------------------------------------------------------------------+
//| Tick                                                             |
//+------------------------------------------------------------------+
void OnTick(void) {
  MqlTick tick;

  if (!SymbolInfoTick(_Symbol, tick))
    return;

  bool newSignalBar = g_conditionalProfiler.ProcessTick(tick);

  if (InpShowStatusOnChart && newSignalBar) {
    Comment(
      __FILE__, "\n",
      g_conditionalProfiler.BuildStatusText((datetime)tick.time));
  }
}
