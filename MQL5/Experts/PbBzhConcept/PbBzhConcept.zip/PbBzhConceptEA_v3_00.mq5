//+------------------------------------------------------------------+
//|                       PbBzhConceptEA_v3_00.mq5                   |
//|  v3.00 : continuation de tendance après repli EMA / RSI         |
//+------------------------------------------------------------------+
#property copyright "Copyright 2026, PbBzhConcept"
#property version   "3.00"
#property strict
#property description "Recherche : continuation de tendance après repli"
#property description "Régime EMA 50/200 D1, reprise RSI 50 sur H1"
#property description "LONG et SHORT, SL initial ATR, Chandelier Exit"

#include <PbBzhConcept\Simulation\VirtualTrendPositionManager.mqh>

enum ENUM_PB_V3_DIRECTION_MODE {
  PB_V3_DIRECTION_LONG_ONLY = 0,
  PB_V3_DIRECTION_SHORT_ONLY,
  PB_V3_DIRECTION_BOTH
};

enum ENUM_PB_V3_TREND_REGIME {
  PB_V3_REGIME_NEUTRAL = 0,
  PB_V3_REGIME_BULLISH,
  PB_V3_REGIME_BEARISH
};

enum ENUM_PB_V3_SIGNAL {
  PB_V3_SIGNAL_NONE = 0,
  PB_V3_SIGNAL_LONG,
  PB_V3_SIGNAL_SHORT
};

struct SPbTrendSignalSnapshot {
  bool isValid;
  datetime signalBarTime;

  double signalOpen;
  double signalHigh;
  double signalLow;
  double signalClose;

  double previousHigh;
  double previousLow;
  double pullbackEma;
  double previousPullbackEma;
  double currentRsi;
  double previousRsi;
  double atrPrice;
  double atrPoints;

  double fastTrendEma;
  double slowTrendEma;
  double pastSlowTrendEma;

  ENUM_PB_V3_TREND_REGIME regime;
  ENUM_PB_V3_SIGNAL signal;
  bool rawLongTrigger;
  bool rawShortTrigger;
};

string V3DirectionModeToString(
  const ENUM_PB_V3_DIRECTION_MODE mode) {

  switch (mode) {
    case PB_V3_DIRECTION_LONG_ONLY:
      return "LONG_ONLY";

    case PB_V3_DIRECTION_SHORT_ONLY:
      return "SHORT_ONLY";

    case PB_V3_DIRECTION_BOTH:
    default:
      return "BOTH";
  }
}

string V3TrendRegimeToString(
  const ENUM_PB_V3_TREND_REGIME regime) {

  switch (regime) {
    case PB_V3_REGIME_BULLISH:
      return "HAUSSIER";

    case PB_V3_REGIME_BEARISH:
      return "BAISSIER";

    case PB_V3_REGIME_NEUTRAL:
    default:
      return "NEUTRE";
  }
}

string V3SignalToString(
  const ENUM_PB_V3_SIGNAL signal) {

  switch (signal) {
    case PB_V3_SIGNAL_LONG:
      return "LONG";

    case PB_V3_SIGNAL_SHORT:
      return "SHORT";

    case PB_V3_SIGNAL_NONE:
    default:
      return "NONE";
  }
}

input group "Général"
input ENUM_TIMEFRAMES InpSignalTimeframe = PERIOD_H1;
input ENUM_PB_V3_DIRECTION_MODE InpDirectionMode = PB_V3_DIRECTION_BOTH;

input group "Régime de tendance"
input ENUM_TIMEFRAMES InpTrendTimeframe = PERIOD_D1;
input int InpFastTrendEmaPeriod = 50;
input int InpSlowTrendEmaPeriod = 200;
input int InpSlowTrendSlopeLookback = 20;

input group "Signal de reprise après repli"
input int InpPullbackEmaPeriod = 20;
input int InpRsiPeriod = 14;
input double InpRsiResumeLevel = 50.0;

input group "Volatilité et protection"
input int InpAtrPeriod = 14;
input double InpInitialStopAtrMultiplier = 2.00;
input double InpChandelierAtrMultiplier = 3.00;

input group "Simulation virtuelle"
input double InpInitialCapital = 10000.00;
input double InpRiskPercent = 1.00;

input group "Affichage"
input bool InpShowTrendEmaLevels = true;
input bool InpShowPullbackEmaLevel = true;
input bool InpShowSignalArrows = true;
input bool InpShowVirtualPositionLevels = true;
input double InpArrowOffsetAtr = 0.20;
input color InpFastTrendEmaColor = clrDeepSkyBlue;
input color InpSlowTrendEmaColor = clrOrange;
input color InpPullbackEmaColor = clrGold;
input color InpBuyArrowColor = clrLimeGreen;
input color InpSellArrowColor = clrTomato;
input color InpVirtualEntryColor = clrDeepSkyBlue;
input color InpVirtualStopColor = clrMagenta;

CVirtualTrendPositionManager g_virtualPosition;

int g_fastTrendEmaHandle = INVALID_HANDLE;
int g_slowTrendEmaHandle = INVALID_HANDLE;
int g_pullbackEmaHandle = INVALID_HANDLE;
int g_rsiHandle = INVALID_HANDLE;
int g_atrHandle = INVALID_HANDLE;

datetime g_currentBarTime = 0;
bool g_hasLastSnapshot = false;
SPbTrendSignalSnapshot g_lastSnapshot;

long g_processedBarCount = 0;
long g_bullishRegimeCount = 0;
long g_bearishRegimeCount = 0;
long g_neutralRegimeCount = 0;
long g_longTriggerCount = 0;
long g_shortTriggerCount = 0;
long g_longAcceptedCount = 0;
long g_shortAcceptedCount = 0;
long g_longRegimeRejectedCount = 0;
long g_shortRegimeRejectedCount = 0;

string g_objectPrefix = "PB300_";
string g_fastTrendEmaName = "PB300_FAST_TREND_EMA";
string g_slowTrendEmaName = "PB300_SLOW_TREND_EMA";
string g_pullbackEmaName = "PB300_PULLBACK_EMA";
string g_virtualEntryName = "PB300_VIRTUAL_ENTRY";
string g_virtualStopName = "PB300_VIRTUAL_STOP";


//+------------------------------------------------------------------+
//| Libère tous les indicateurs                                      |
//+------------------------------------------------------------------+
void ReleaseIndicators(void) {
  if (g_fastTrendEmaHandle != INVALID_HANDLE) {
    IndicatorRelease(g_fastTrendEmaHandle);
    g_fastTrendEmaHandle = INVALID_HANDLE;
  }

  if (g_slowTrendEmaHandle != INVALID_HANDLE) {
    IndicatorRelease(g_slowTrendEmaHandle);
    g_slowTrendEmaHandle = INVALID_HANDLE;
  }

  if (g_pullbackEmaHandle != INVALID_HANDLE) {
    IndicatorRelease(g_pullbackEmaHandle);
    g_pullbackEmaHandle = INVALID_HANDLE;
  }

  if (g_rsiHandle != INVALID_HANDLE) {
    IndicatorRelease(g_rsiHandle);
    g_rsiHandle = INVALID_HANDLE;
  }

  if (g_atrHandle != INVALID_HANDLE) {
    IndicatorRelease(g_atrHandle);
    g_atrHandle = INVALID_HANDLE;
  }
}


//+------------------------------------------------------------------+
//| Initialise les indicateurs                                       |
//+------------------------------------------------------------------+
bool InitializeIndicators(void) {
  if (InpFastTrendEmaPeriod < 2 ||
    InpSlowTrendEmaPeriod <= InpFastTrendEmaPeriod ||
    InpSlowTrendSlopeLookback < 1 ||
    InpPullbackEmaPeriod < 2 ||
    InpRsiPeriod < 2 ||
    InpRsiResumeLevel <= 0.0 ||
    InpRsiResumeLevel >= 100.0 ||
    InpAtrPeriod < 2) {

    PrintFormat(
      "[%s][ERROR] Paramètres d'indicateurs invalides.",
      __FILE__);

    return false;
  }

  g_fastTrendEmaHandle = iMA(
    _Symbol,
    InpTrendTimeframe,
    InpFastTrendEmaPeriod,
    0,
    MODE_EMA,
    PRICE_CLOSE);

  g_slowTrendEmaHandle = iMA(
    _Symbol,
    InpTrendTimeframe,
    InpSlowTrendEmaPeriod,
    0,
    MODE_EMA,
    PRICE_CLOSE);

  g_pullbackEmaHandle = iMA(
    _Symbol,
    InpSignalTimeframe,
    InpPullbackEmaPeriod,
    0,
    MODE_EMA,
    PRICE_CLOSE);

  g_rsiHandle = iRSI(
    _Symbol,
    InpSignalTimeframe,
    InpRsiPeriod,
    PRICE_CLOSE);

  g_atrHandle = iATR(
    _Symbol,
    InpSignalTimeframe,
    InpAtrPeriod);

  if (g_fastTrendEmaHandle == INVALID_HANDLE ||
    g_slowTrendEmaHandle == INVALID_HANDLE ||
    g_pullbackEmaHandle == INVALID_HANDLE ||
    g_rsiHandle == INVALID_HANDLE ||
    g_atrHandle == INVALID_HANDLE) {

    PrintFormat(
      "[%s][ERROR] Création d'un indicateur impossible. Erreur=%d",
      __FILE__,
      GetLastError());

    ReleaseIndicators();
    return false;
  }

  return true;
}


//+------------------------------------------------------------------+
//| Lit une valeur d'indicateur                                      |
//+------------------------------------------------------------------+
bool ReadIndicatorValue(
  const int handle,
  const int bufferIndex,
  const int shift,
  double &value) {

  double buffer[1];
  ResetLastError();

  if (handle == INVALID_HANDLE ||
    CopyBuffer(
      handle,
      bufferIndex,
      shift,
      1,
      buffer) != 1) {

    return false;
  }

  value = buffer[0];
  return true;
}


//+------------------------------------------------------------------+
//| Évalue uniquement des bougies entièrement clôturées              |
//+------------------------------------------------------------------+
bool EvaluateClosedBar(
  SPbTrendSignalSnapshot &snapshot) {

  ZeroMemory(snapshot);
  snapshot.regime = PB_V3_REGIME_NEUTRAL;
  snapshot.signal = PB_V3_SIGNAL_NONE;

  snapshot.signalBarTime = iTime(
    _Symbol,
    InpSignalTimeframe,
    1);

  snapshot.signalOpen = iOpen(
    _Symbol,
    InpSignalTimeframe,
    1);

  snapshot.signalHigh = iHigh(
    _Symbol,
    InpSignalTimeframe,
    1);

  snapshot.signalLow = iLow(
    _Symbol,
    InpSignalTimeframe,
    1);

  snapshot.signalClose = iClose(
    _Symbol,
    InpSignalTimeframe,
    1);

  snapshot.previousHigh = iHigh(
    _Symbol,
    InpSignalTimeframe,
    2);

  snapshot.previousLow = iLow(
    _Symbol,
    InpSignalTimeframe,
    2);

  bool dataAvailable =
    snapshot.signalBarTime > 0 &&
    snapshot.signalOpen > 0.0 &&
    snapshot.signalHigh > 0.0 &&
    snapshot.signalLow > 0.0 &&
    snapshot.signalClose > 0.0 &&
    snapshot.previousHigh > 0.0 &&
    snapshot.previousLow > 0.0 &&
    ReadIndicatorValue(
      g_fastTrendEmaHandle,
      0,
      1,
      snapshot.fastTrendEma) &&
    ReadIndicatorValue(
      g_slowTrendEmaHandle,
      0,
      1,
      snapshot.slowTrendEma) &&
    ReadIndicatorValue(
      g_slowTrendEmaHandle,
      0,
      1 + InpSlowTrendSlopeLookback,
      snapshot.pastSlowTrendEma) &&
    ReadIndicatorValue(
      g_pullbackEmaHandle,
      0,
      1,
      snapshot.pullbackEma) &&
    ReadIndicatorValue(
      g_pullbackEmaHandle,
      0,
      2,
      snapshot.previousPullbackEma) &&
    ReadIndicatorValue(
      g_rsiHandle,
      0,
      1,
      snapshot.currentRsi) &&
    ReadIndicatorValue(
      g_rsiHandle,
      0,
      2,
      snapshot.previousRsi) &&
    ReadIndicatorValue(
      g_atrHandle,
      0,
      1,
      snapshot.atrPrice);

  if (!dataAvailable || snapshot.atrPrice <= 0.0)
    return false;

  snapshot.atrPoints = snapshot.atrPrice / _Point;

  if (snapshot.fastTrendEma > snapshot.slowTrendEma &&
    snapshot.slowTrendEma > snapshot.pastSlowTrendEma) {

    snapshot.regime = PB_V3_REGIME_BULLISH;
  }
  else if (snapshot.fastTrendEma < snapshot.slowTrendEma &&
    snapshot.slowTrendEma < snapshot.pastSlowTrendEma) {

    snapshot.regime = PB_V3_REGIME_BEARISH;
  }

  // LONG : la bougie précédente a touché l'EMA de repli,
  // puis le RSI et la clôture repassent au-dessus de leurs niveaux.
  snapshot.rawLongTrigger =
    snapshot.previousLow <= snapshot.previousPullbackEma &&
    snapshot.signalClose > snapshot.pullbackEma &&
    snapshot.previousRsi <= InpRsiResumeLevel &&
    snapshot.currentRsi > InpRsiResumeLevel;

  // SHORT : conditions exactement symétriques.
  snapshot.rawShortTrigger =
    snapshot.previousHigh >= snapshot.previousPullbackEma &&
    snapshot.signalClose < snapshot.pullbackEma &&
    snapshot.previousRsi >= InpRsiResumeLevel &&
    snapshot.currentRsi < InpRsiResumeLevel;

  bool allowLong =
    InpDirectionMode == PB_V3_DIRECTION_LONG_ONLY ||
    InpDirectionMode == PB_V3_DIRECTION_BOTH;

  bool allowShort =
    InpDirectionMode == PB_V3_DIRECTION_SHORT_ONLY ||
    InpDirectionMode == PB_V3_DIRECTION_BOTH;

  if (snapshot.rawLongTrigger &&
    snapshot.regime == PB_V3_REGIME_BULLISH &&
    allowLong) {

    snapshot.signal = PB_V3_SIGNAL_LONG;
  }
  else if (snapshot.rawShortTrigger &&
    snapshot.regime == PB_V3_REGIME_BEARISH &&
    allowShort) {

    snapshot.signal = PB_V3_SIGNAL_SHORT;
  }

  snapshot.isValid = true;
  return true;
}


//+------------------------------------------------------------------+
//| Met à jour une ligne horizontale                                 |
//+------------------------------------------------------------------+
void UpdateHorizontalLine(
  const string objectName,
  const double price,
  const color lineColor,
  const ENUM_LINE_STYLE lineStyle,
  const int lineWidth) {

  if (price <= 0.0)
    return;

  if (ObjectFind(0, objectName) < 0) {
    if (!ObjectCreate(
      0,
      objectName,
      OBJ_HLINE,
      0,
      0,
      price)) {

      PrintFormat(
        "[%s][ERROR] Création objet %s impossible. Erreur=%d",
        __FILE__,
        objectName,
        GetLastError());

      return;
    }
  }

  ObjectSetDouble(0, objectName, OBJPROP_PRICE, price);
  ObjectSetInteger(0, objectName, OBJPROP_COLOR, lineColor);
  ObjectSetInteger(0, objectName, OBJPROP_STYLE, lineStyle);
  ObjectSetInteger(0, objectName, OBJPROP_WIDTH, lineWidth);
  ObjectSetInteger(0, objectName, OBJPROP_BACK, true);
  ObjectSetInteger(0, objectName, OBJPROP_SELECTABLE, false);
}


//+------------------------------------------------------------------+
//| Dessine la flèche d'un signal accepté                            |
//+------------------------------------------------------------------+
void DrawSignalArrow(
  const SPbTrendSignalSnapshot &snapshot) {

  if (!InpShowSignalArrows ||
    snapshot.signal == PB_V3_SIGNAL_NONE) {

    return;
  }

  string objectName = StringFormat(
    "%s%s_%I64d",
    g_objectPrefix,
    V3SignalToString(snapshot.signal),
    (long)snapshot.signalBarTime);

  if (ObjectFind(0, objectName) >= 0)
    return;

  ENUM_OBJECT objectType =
    snapshot.signal == PB_V3_SIGNAL_LONG
    ? OBJ_ARROW_BUY
    : OBJ_ARROW_SELL;

  double offset = snapshot.atrPrice *
    MathMax(0.0, InpArrowOffsetAtr);

  double arrowPrice =
    snapshot.signal == PB_V3_SIGNAL_LONG
    ? snapshot.signalLow - offset
    : snapshot.signalHigh + offset;

  if (!ObjectCreate(
    0,
    objectName,
    objectType,
    0,
    snapshot.signalBarTime,
    arrowPrice)) {

    PrintFormat(
      "[%s][ERROR] Création flèche impossible. Erreur=%d",
      __FILE__,
      GetLastError());

    return;
  }

  ObjectSetInteger(
    0,
    objectName,
    OBJPROP_COLOR,
    snapshot.signal == PB_V3_SIGNAL_LONG
    ? InpBuyArrowColor
    : InpSellArrowColor);

  ObjectSetInteger(0, objectName, OBJPROP_WIDTH, 2);
  ObjectSetInteger(0, objectName, OBJPROP_SELECTABLE, false);
}


//+------------------------------------------------------------------+
//| Met à jour les niveaux de la position virtuelle                  |
//+------------------------------------------------------------------+
void UpdateVirtualPositionLines(void) {
  if (!InpShowVirtualPositionLevels ||
    !g_virtualPosition.IsOpen()) {

    ObjectDelete(0, g_virtualEntryName);
    ObjectDelete(0, g_virtualStopName);
    return;
  }

  UpdateHorizontalLine(
    g_virtualEntryName,
    g_virtualPosition.EntryPrice(),
    InpVirtualEntryColor,
    STYLE_DOT,
    1);

  UpdateHorizontalLine(
    g_virtualStopName,
    g_virtualPosition.StopLossPrice(),
    InpVirtualStopColor,
    STYLE_SOLID,
    2);
}


//+------------------------------------------------------------------+
//| Met à jour l'affichage du dernier état                           |
//+------------------------------------------------------------------+
void UpdateChartDisplay(
  const SPbTrendSignalSnapshot &snapshot) {

  if (InpShowTrendEmaLevels) {
    UpdateHorizontalLine(
      g_fastTrendEmaName,
      snapshot.fastTrendEma,
      InpFastTrendEmaColor,
      STYLE_DASH,
      1);

    UpdateHorizontalLine(
      g_slowTrendEmaName,
      snapshot.slowTrendEma,
      InpSlowTrendEmaColor,
      STYLE_DASH,
      2);
  }
  else {
    ObjectDelete(0, g_fastTrendEmaName);
    ObjectDelete(0, g_slowTrendEmaName);
  }

  if (InpShowPullbackEmaLevel) {
    UpdateHorizontalLine(
      g_pullbackEmaName,
      snapshot.pullbackEma,
      InpPullbackEmaColor,
      STYLE_SOLID,
      1);
  }
  else {
    ObjectDelete(0, g_pullbackEmaName);
  }

  DrawSignalArrow(snapshot);
  UpdateVirtualPositionLines();

  Comment(
    __FILE__, " — CONTINUATION APRÈS REPLI\n",
    "Symbole : ", _Symbol,
    " | Signal : ", EnumToString(InpSignalTimeframe),
    " | Direction : ", V3DirectionModeToString(InpDirectionMode), "\n",
    "Bougie clôturée : ",
    TimeToString(snapshot.signalBarTime, TIME_DATE|TIME_MINUTES), "\n",
    "Régime ", EnumToString(InpTrendTimeframe), " : ",
    V3TrendRegimeToString(snapshot.regime),
    " | EMA ", InpFastTrendEmaPeriod, " : ",
    DoubleToString(snapshot.fastTrendEma, _Digits),
    " | EMA ", InpSlowTrendEmaPeriod, " : ",
    DoubleToString(snapshot.slowTrendEma, _Digits), "\n",
    "Signal : ", V3SignalToString(snapshot.signal),
    " | Clôture : ", DoubleToString(snapshot.signalClose, _Digits),
    " | EMA repli : ", DoubleToString(snapshot.pullbackEma, _Digits), "\n",
    "RSI précédent/courant : ",
    DoubleToString(snapshot.previousRsi, 2), " / ",
    DoubleToString(snapshot.currentRsi, 2),
    " | Niveau : ", DoubleToString(InpRsiResumeLevel, 1), "\n",
    "ATR(", InpAtrPeriod, ") : ",
    DoubleToString(snapshot.atrPoints, 1), " points",
    " | SL : ", DoubleToString(InpInitialStopAtrMultiplier, 2),
    " ATR | Chandelier : ",
    DoubleToString(InpChandelierAtrMultiplier, 2), " ATR\n",
    g_virtualPosition.BuildStatusText(), "\n",
    "Bougies : ", g_processedBarCount,
    " | Signaux LONG/SHORT acceptés : ",
    g_longAcceptedCount, "/", g_shortAcceptedCount);
}


//+------------------------------------------------------------------+
//| Traite la dernière bougie clôturée                               |
//+------------------------------------------------------------------+
void ProcessClosedBar(
  const MqlTick &tick,
  const bool positionClosedEarlierThisTick) {

  SPbTrendSignalSnapshot snapshot;

  if (!EvaluateClosedBar(snapshot) || !snapshot.isValid)
    return;

  g_lastSnapshot = snapshot;
  g_hasLastSnapshot = true;
  g_processedBarCount++;

  if (snapshot.regime == PB_V3_REGIME_BULLISH)
    g_bullishRegimeCount++;
  else if (snapshot.regime == PB_V3_REGIME_BEARISH)
    g_bearishRegimeCount++;
  else
    g_neutralRegimeCount++;

  if (snapshot.rawLongTrigger) {
    g_longTriggerCount++;

    if (snapshot.signal == PB_V3_SIGNAL_LONG)
      g_longAcceptedCount++;
    else
      g_longRegimeRejectedCount++;
  }

  if (snapshot.rawShortTrigger) {
    g_shortTriggerCount++;

    if (snapshot.signal == PB_V3_SIGNAL_SHORT)
      g_shortAcceptedCount++;
    else
      g_shortRegimeRejectedCount++;
  }

  g_virtualPosition.UpdateAtr(
    snapshot.atrPrice,
    snapshot.atrPoints);

  bool closedAfterAtrUpdate =
    g_virtualPosition.ProcessTick(tick);

  if (!g_virtualPosition.IsOpen() &&
    !closedAfterAtrUpdate &&
    !positionClosedEarlierThisTick) {

    ENUM_PB_V3_POSITION_DIRECTION direction =
      PB_V3_POSITION_FLAT;

    if (snapshot.signal == PB_V3_SIGNAL_LONG)
      direction = PB_V3_POSITION_LONG;
    else if (snapshot.signal == PB_V3_SIGNAL_SHORT)
      direction = PB_V3_POSITION_SHORT;

    if (direction != PB_V3_POSITION_FLAT) {
      g_virtualPosition.OpenPosition(
        direction,
        snapshot.signalBarTime,
        snapshot.atrPrice,
        snapshot.atrPoints,
        tick);
    }
  }

  UpdateChartDisplay(snapshot);

  PrintFormat(
    "[%s][INFO] BARRE | Temps=%s | Régime=%s | Signal=%s | "
    "O=%.5f H=%.5f L=%.5f C=%.5f | "
    "EMA repli=%.5f | RSI précédent=%.2f courant=%.2f | "
    "EMA rapide=%.5f lente=%.5f passée=%.5f | "
    "ATR=%.1f points | Position=%s | Capital=%.2f",
    __FILE__,
    TimeToString(snapshot.signalBarTime, TIME_DATE|TIME_MINUTES),
    V3TrendRegimeToString(snapshot.regime),
    V3SignalToString(snapshot.signal),
    snapshot.signalOpen,
    snapshot.signalHigh,
    snapshot.signalLow,
    snapshot.signalClose,
    snapshot.pullbackEma,
    snapshot.previousRsi,
    snapshot.currentRsi,
    snapshot.fastTrendEma,
    snapshot.slowTrendEma,
    snapshot.pastSlowTrendEma,
    snapshot.atrPoints,
    V3PositionDirectionToString(g_virtualPosition.Direction()),
    g_virtualPosition.VirtualCapital());
}


//+------------------------------------------------------------------+
//| Vérifie l'apparition d'une nouvelle bougie                       |
//+------------------------------------------------------------------+
bool IsNewBar(void) {
  datetime currentBarTime = iTime(
    _Symbol,
    InpSignalTimeframe,
    0);

  if (currentBarTime <= 0)
    return false;

  if (g_currentBarTime == 0) {
    g_currentBarTime = currentBarTime;
    return true;
  }

  if (currentBarTime == g_currentBarTime)
    return false;

  g_currentBarTime = currentBarTime;
  return true;
}


//+------------------------------------------------------------------+
//| Initialisation                                                   |
//+------------------------------------------------------------------+
int OnInit(void) {
  if (!InitializeIndicators())
    return INIT_FAILED;

  if (!g_virtualPosition.Initialize(
    _Symbol,
    InpInitialCapital,
    InpRiskPercent,
    InpInitialStopAtrMultiplier,
    InpChandelierAtrMultiplier)) {

    ReleaseIndicators();
    return INIT_FAILED;
  }

  g_currentBarTime = 0;
  g_hasLastSnapshot = false;
  g_processedBarCount = 0;
  g_bullishRegimeCount = 0;
  g_bearishRegimeCount = 0;
  g_neutralRegimeCount = 0;
  g_longTriggerCount = 0;
  g_shortTriggerCount = 0;
  g_longAcceptedCount = 0;
  g_shortAcceptedCount = 0;
  g_longRegimeRejectedCount = 0;
  g_shortRegimeRejectedCount = 0;
  ZeroMemory(g_lastSnapshot);

  PrintFormat(
    "[%s][INFO] DÉMARRAGE | Symbole=%s | Signal=%s | Direction=%s | "
    "Tendance=%s EMA=%d/%d pente lente=%d | "
    "Repli EMA=%d | RSI=%d niveau=%.2f | ATR=%d | "
    "SL=%.2f ATR | Sortie=CHANDELIER_ONLY %.2f ATR | "
    "Capital=%.2f | Risque=%.2f%% | Mode=SIMULATION",
    __FILE__,
    _Symbol,
    EnumToString(InpSignalTimeframe),
    V3DirectionModeToString(InpDirectionMode),
    EnumToString(InpTrendTimeframe),
    InpFastTrendEmaPeriod,
    InpSlowTrendEmaPeriod,
    InpSlowTrendSlopeLookback,
    InpPullbackEmaPeriod,
    InpRsiPeriod,
    InpRsiResumeLevel,
    InpAtrPeriod,
    InpInitialStopAtrMultiplier,
    InpChandelierAtrMultiplier,
    InpInitialCapital,
    InpRiskPercent);

  return INIT_SUCCEEDED;
}


//+------------------------------------------------------------------+
//| Désinitialisation                                                |
//+------------------------------------------------------------------+
void OnDeinit(const int reason) {
  MqlTick tick;

  if (SymbolInfoTick(_Symbol, tick))
    g_virtualPosition.CloseAtTestEnd(tick);

  PrintFormat(
    "[%s][INFO] Résumé régimes : Bougies=%I64d | "
    "Haussier=%I64d | Baissier=%I64d | Neutre=%I64d | "
    "Tendance=%s EMA=%d/%d | Recul pente=%d",
    __FILE__,
    g_processedBarCount,
    g_bullishRegimeCount,
    g_bearishRegimeCount,
    g_neutralRegimeCount,
    EnumToString(InpTrendTimeframe),
    InpFastTrendEmaPeriod,
    InpSlowTrendEmaPeriod,
    InpSlowTrendSlopeLookback);

  PrintFormat(
    "[%s][INFO] Résumé signaux : "
    "LONG détectés=%I64d | Acceptés=%I64d | Refusés régime=%I64d | "
    "SHORT détectés=%I64d | Acceptés=%I64d | Refusés régime=%I64d | "
    "Repli EMA=%d | RSI=%d | Niveau=%.2f | Direction=%s",
    __FILE__,
    g_longTriggerCount,
    g_longAcceptedCount,
    g_longRegimeRejectedCount,
    g_shortTriggerCount,
    g_shortAcceptedCount,
    g_shortRegimeRejectedCount,
    InpPullbackEmaPeriod,
    InpRsiPeriod,
    InpRsiResumeLevel,
    V3DirectionModeToString(InpDirectionMode));

  g_virtualPosition.PrintFinalSummary();
  ReleaseIndicators();

  ObjectsDeleteAll(0, g_objectPrefix);
  Comment("");

  PrintFormat(
    "[%s][INFO] ARRÊT | Raison=%d",
    __FILE__,
    reason);
}


//+------------------------------------------------------------------+
//| Tick                                                             |
//+------------------------------------------------------------------+
void OnTick(void) {
  MqlTick tick;

  if (!SymbolInfoTick(_Symbol, tick))
    return;

  bool closedByStop =
    g_virtualPosition.ProcessTick(tick);

  if (closedByStop && g_hasLastSnapshot)
    UpdateChartDisplay(g_lastSnapshot);

  if (!IsNewBar())
    return;

  ProcessClosedBar(
    tick,
    closedByStop);
}
