//+------------------------------------------------------------------+
//|                       PbBzhConceptEA_v7_03.mq5                   |
//|  v7.03 : validation TP/SL du signal intraday GOLD               |
//+------------------------------------------------------------------+
#property copyright "Copyright 2026, PbBzhConcept"
#property version   "7.03"
#property strict
#property description "GOLD : ordre d'atteinte TP/SL après cassure M15"
#property description "Fenêtre 13h-15h, alignement EMA H1, suivi M1"
#property description "Analyse A/B/C et espérance théorique en R"
#property description "Aucun ordre réel ou virtuel n'est ouvert"

#include <PbBzhConcept\Analysis\GoldIntradayBarrierProfiler_v7_03.mqh>

input group "Unités de temps imposées"
input ENUM_TIMEFRAMES InpSignalTimeframe = PERIOD_M15;
input ENUM_TIMEFRAMES InpContextTimeframe = PERIOD_H1;
input ENUM_TIMEFRAMES InpBarrierMonitorTimeframe = PERIOD_M1;

input group "Contexte directionnel H1"
input int InpContextAtrPeriod = 14;
input int InpContextTrendEmaPeriod = 50;
input double InpTrendNeutralAtrBand = 0.10;

input group "Signal et volatilité préalable"
input int InpBreakoutLookbackBars = 4;
input double InpCompressionMaximumAtr = 0.75;
input double InpExpansionMinimumAtr = 1.25;

input group "Fenêtre horaire — heure serveur MT5"
input int InpEntryStartHour = 13;
input int InpEntryEndHour = 15;

input group "Suivi des barrières"
input int InpMaximumHoldingMinutes = 120;

input group "Affichage"
input bool InpShowStatusOnChart = true;

CGoldIntradayBarrierProfiler g_barrierProfiler;


//+------------------------------------------------------------------+
//| Vérifie que le symbole ressemble à GOLD ou XAU                  |
//+------------------------------------------------------------------+
bool SymbolLooksLikeGold(void) {
  string symbolName = _Symbol;
  StringToUpper(symbolName);

  return StringFind(symbolName, "GOLD") >= 0 ||
    StringFind(symbolName, "XAU") >= 0;
}


//+------------------------------------------------------------------+
//| Initialisation                                                   |
//+------------------------------------------------------------------+
int OnInit(void) {
  if (!SymbolLooksLikeGold()) {
    PrintFormat(
      "[%s][WARNING] La v7.03 est conçue pour GOLD/XAU. "
      "Symbole courant=%s",
      __FILE__,
      _Symbol);
  }

  if (!g_barrierProfiler.Initialize(
    _Symbol,
    InpSignalTimeframe,
    InpContextTimeframe,
    InpBarrierMonitorTimeframe,
    InpContextAtrPeriod,
    InpContextTrendEmaPeriod,
    InpTrendNeutralAtrBand,
    InpBreakoutLookbackBars,
    InpCompressionMaximumAtr,
    InpExpansionMinimumAtr,
    InpEntryStartHour,
    InpEntryEndHour,
    InpMaximumHoldingMinutes)) {

    return INIT_FAILED;
  }

  PrintFormat(
    "[%s][INFO] DÉMARRAGE | Profil=GOLD BARRIER PROFILER | "
    "Symbole=%s | Signal=%s | Contexte=%s EMA=%d ATR=%d | "
    "Suivi=%s | Fenêtre=%02dh-%02dh | Cassure=%d | "
    "Bande neutre=%.2f ATR | Compression exclue<%.2f ATR | "
    "Expansion>%.2f ATR | Durée=%d minutes | "
    "Scénarios=0.50/0.50,0.75/0.50,0.75/0.75,"
    "1.00/0.75,1.00/1.00 | Mode=ANALYSE_SANS_TRADING",
    __FILE__,
    _Symbol,
    EnumToString(InpSignalTimeframe),
    EnumToString(InpContextTimeframe),
    InpContextTrendEmaPeriod,
    InpContextAtrPeriod,
    EnumToString(InpBarrierMonitorTimeframe),
    InpEntryStartHour,
    InpEntryEndHour,
    InpBreakoutLookbackBars,
    InpTrendNeutralAtrBand,
    InpCompressionMaximumAtr,
    InpExpansionMinimumAtr,
    InpMaximumHoldingMinutes);

  return INIT_SUCCEEDED;
}


//+------------------------------------------------------------------+
//| Désinitialisation                                                |
//+------------------------------------------------------------------+
void OnDeinit(const int reason) {
  g_barrierProfiler.PrintFinalReport();
  g_barrierProfiler.Shutdown();
  Comment("");

  PrintFormat(
    "[%s][INFO] ARRÊT | Raison=%d",
    __FILE__,
    reason);
}


//+------------------------------------------------------------------+
//| Tick                                                             |
//+------------------------------------------------------------------+
void OnTick(void) {
  MqlTick tick;

  if (!SymbolInfoTick(_Symbol, tick))
    return;

  bool newSignalBar = g_barrierProfiler.ProcessTick(tick);

  if (InpShowStatusOnChart && newSignalBar) {
    Comment(
      __FILE__, "\n",
      g_barrierProfiler.BuildStatusText((datetime)tick.time));
  }
}
