//+------------------------------------------------------------------+
//|                       PbBzhConceptEA_v5_00.mq5                   |
//|  v5.00 : momentum temporel multi-actifs                         |
//+------------------------------------------------------------------+
#property copyright "Copyright 2026, PbBzhConcept"
#property version   "5.00"
#property strict
#property description "Recherche : momentum temporel de long terme"
#property description "Comparaison de la clôture D1 avec celle d'il y a 90 jours"
#property description "LONG et SHORT, stop ATR, sortie sur inversion du momentum"

#include <PbBzhConcept\Simulation\VirtualMomentumPositionManager.mqh>

enum ENUM_PB_V5_DIRECTION_MODE {
  PB_V5_DIRECTION_LONG_ONLY = 0,
    PB_V5_DIRECTION_SHORT_ONLY,
    PB_V5_DIRECTION_BOTH
};

struct SPbMomentumSnapshot {
  bool isValid;
  datetime signalBarTime;

  double signalOpen;
  double signalHigh;
  double signalLow;
  double signalClose;
  double pastClose;
  double momentumPercent;
  double atrPrice;
  double atrPoints;

  ENUM_PB_V5_POSITION_DIRECTION momentumDirection;
};

string V5DirectionModeToString(
  const ENUM_PB_V5_DIRECTION_MODE mode) {

  switch (mode) {
    case PB_V5_DIRECTION_LONG_ONLY:
      return "LONG_ONLY";

    case PB_V5_DIRECTION_SHORT_ONLY:
      return "SHORT_ONLY";

    case PB_V5_DIRECTION_BOTH:
      default:
      return "BOTH";
  }
}

input group "Général"
input ENUM_TIMEFRAMES InpSignalTimeframe = PERIOD_D1;
input ENUM_PB_V5_DIRECTION_MODE InpDirectionMode = PB_V5_DIRECTION_BOTH;

input group "Momentum temporel"
input int InpMomentumLookback = 90;

input group "Volatilité et protection"
input int InpAtrPeriod = 20;
input double InpInitialStopAtrMultiplier = 3.00;

input group "Simulation virtuelle"
input double InpInitialCapital = 10000.00;
input double InpRiskPercent = 1.00;

input group "Affichage"
input bool InpShowMomentumReference = true;
input bool InpShowEntryArrows = true;
input bool InpShowVirtualPositionLevels = true;
input double InpArrowOffsetAtr = 0.20;
input color InpMomentumReferenceColor = clrGold;
input color InpBuyArrowColor = clrLimeGreen;
input color InpSellArrowColor = clrTomato;
input color InpVirtualEntryColor = clrDeepSkyBlue;
input color InpVirtualStopColor = clrMagenta;

CVirtualMomentumPositionManager g_virtualPosition;

int g_atrHandle = INVALID_HANDLE;

datetime g_currentBarTime = 0;
bool g_hasLastSnapshot = false;
SPbMomentumSnapshot g_lastSnapshot;

ENUM_PB_V5_POSITION_DIRECTION g_previousMomentumDirection =
  PB_V5_POSITION_FLAT;

long g_processedBarCount = 0;
long g_longRegimeBarCount = 0;
long g_shortRegimeBarCount = 0;
long g_neutralRegimeBarCount = 0;
long g_longTransitionCount = 0;
long g_shortTransitionCount = 0;
long g_longOpenCount = 0;
long g_shortOpenCount = 0;

string g_objectPrefix = "PB500_";
string g_momentumReferenceName = "PB500_MOMENTUM_REFERENCE";
string g_virtualEntryName = "PB500_VIRTUAL_ENTRY";
string g_virtualStopName = "PB500_VIRTUAL_STOP";


//+------------------------------------------------------------------+
//| Libère l'indicateur ATR                                          |
//+------------------------------------------------------------------+
void ReleaseIndicators(void) {
  if (g_atrHandle != INVALID_HANDLE) {
    IndicatorRelease(g_atrHandle);
    g_atrHandle = INVALID_HANDLE;
  }
}


//+------------------------------------------------------------------+
//| Initialise l'ATR                                                  |
//+------------------------------------------------------------------+
bool InitializeIndicators(void) {
  if (InpMomentumLookback < 2 ||
    InpAtrPeriod < 2) {

    PrintFormat(
      "[%s][ERROR] Paramètres d'indicateurs invalides.",
      __FILE__);

    return false;
  }

  g_atrHandle = iATR(
    _Symbol,
    InpSignalTimeframe,
    InpAtrPeriod);

  if (g_atrHandle == INVALID_HANDLE) {
    PrintFormat(
      "[%s][ERROR] Création de l'ATR impossible. Erreur=%d",
      __FILE__,
      GetLastError());

    return false;
  }

  return true;
}


//+------------------------------------------------------------------+
//| Lit une valeur d'indicateur                                      |
//+------------------------------------------------------------------+
bool ReadIndicatorValue(
  const int handle,
  const int bufferIndex,
  const int shift,
  double &value) {

  double buffer[1];
  ResetLastError();

  if (handle == INVALID_HANDLE ||
    CopyBuffer(
      handle,
      bufferIndex,
      shift,
      1,
      buffer) != 1) {

    return false;
  }

  value = buffer[0];
  return true;
}


//+------------------------------------------------------------------+
//| Évalue le momentum avec des bougies clôturées                    |
//+------------------------------------------------------------------+
bool EvaluateClosedBar(
  SPbMomentumSnapshot &snapshot) {

  ZeroMemory(snapshot);
  snapshot.momentumDirection = PB_V5_POSITION_FLAT;

  snapshot.signalBarTime = iTime(
    _Symbol,
    InpSignalTimeframe,
    1);

  snapshot.signalOpen = iOpen(
    _Symbol,
    InpSignalTimeframe,
    1);

  snapshot.signalHigh = iHigh(
    _Symbol,
    InpSignalTimeframe,
    1);

  snapshot.signalLow = iLow(
    _Symbol,
    InpSignalTimeframe,
    1);

  snapshot.signalClose = iClose(
    _Symbol,
    InpSignalTimeframe,
    1);

  snapshot.pastClose = iClose(
    _Symbol,
    InpSignalTimeframe,
    1 + InpMomentumLookback);

  bool dataAvailable =
    snapshot.signalBarTime > 0 &&
    snapshot.signalOpen > 0.0 &&
    snapshot.signalHigh > 0.0 &&
    snapshot.signalLow > 0.0 &&
    snapshot.signalClose > 0.0 &&
    snapshot.pastClose > 0.0 &&
    ReadIndicatorValue(
    g_atrHandle,
    0,
    1,
    snapshot.atrPrice);

  if (!dataAvailable || snapshot.atrPrice <= 0.0)
  return false;

  snapshot.atrPoints = snapshot.atrPrice / _Point;
  snapshot.momentumPercent =
    (snapshot.signalClose / snapshot.pastClose - 1.0) * 100.0;

  if (snapshot.signalClose > snapshot.pastClose)
  snapshot.momentumDirection = PB_V5_POSITION_LONG;
  else if (snapshot.signalClose < snapshot.pastClose)
  snapshot.momentumDirection = PB_V5_POSITION_SHORT;

  snapshot.isValid = true;
  return true;
}


//+------------------------------------------------------------------+
//| Vérifie si une direction est autorisée                           |
//+------------------------------------------------------------------+
bool DirectionIsAllowed(
  const ENUM_PB_V5_POSITION_DIRECTION direction) {

  if (direction == PB_V5_POSITION_LONG) {
    return InpDirectionMode == PB_V5_DIRECTION_LONG_ONLY ||
      InpDirectionMode == PB_V5_DIRECTION_BOTH;
  }

  if (direction == PB_V5_POSITION_SHORT) {
    return InpDirectionMode == PB_V5_DIRECTION_SHORT_ONLY ||
      InpDirectionMode == PB_V5_DIRECTION_BOTH;
  }

  return false;
}


//+------------------------------------------------------------------+
//| Met à jour une ligne horizontale                                 |
//+------------------------------------------------------------------+
void UpdateHorizontalLine(
  const string objectName,
  const double price,
  const color lineColor,
  const ENUM_LINE_STYLE lineStyle,
  const int lineWidth) {

  if (price <= 0.0)
  return;

  if (ObjectFind(0, objectName) < 0) {
    if (!ObjectCreate(
        0,
        objectName,
        OBJ_HLINE,
        0,
        0,
        price)) {

      PrintFormat(
        "[%s][ERROR] Création objet %s impossible. Erreur=%d",
        __FILE__,
        objectName,
        GetLastError());

      return;
    }
  }

  ObjectSetDouble(0, objectName, OBJPROP_PRICE, price);
  ObjectSetInteger(0, objectName, OBJPROP_COLOR, lineColor);
  ObjectSetInteger(0, objectName, OBJPROP_STYLE, lineStyle);
  ObjectSetInteger(0, objectName, OBJPROP_WIDTH, lineWidth);
  ObjectSetInteger(0, objectName, OBJPROP_BACK, true);
  ObjectSetInteger(0, objectName, OBJPROP_SELECTABLE, false);
}


//+------------------------------------------------------------------+
//| Dessine une flèche lorsqu'une position est ouverte               |
//+------------------------------------------------------------------+
void DrawEntryArrow(
  const SPbMomentumSnapshot &snapshot,
  const ENUM_PB_V5_POSITION_DIRECTION direction) {

  if (!InpShowEntryArrows ||
    direction == PB_V5_POSITION_FLAT) {

    return;
  }

  string objectName = StringFormat(
    "%sENTRY_%s_%I64d",
    g_objectPrefix,
    V5PositionDirectionToString(direction),
    (long)snapshot.signalBarTime);

  if (ObjectFind(0, objectName) >= 0)
  return;

  ENUM_OBJECT objectType =
    direction == PB_V5_POSITION_LONG
    ? OBJ_ARROW_BUY
    : OBJ_ARROW_SELL;

  double offset = snapshot.atrPrice *
    MathMax(0.0, InpArrowOffsetAtr);

  double arrowPrice =
    direction == PB_V5_POSITION_LONG
    ? snapshot.signalLow - offset
    : snapshot.signalHigh + offset;

  if (!ObjectCreate(
      0,
      objectName,
      objectType,
      0,
      snapshot.signalBarTime,
      arrowPrice)) {

    return;
  }

  ObjectSetInteger(
    0,
    objectName,
    OBJPROP_COLOR,
    direction == PB_V5_POSITION_LONG
    ? InpBuyArrowColor
    : InpSellArrowColor);

  ObjectSetInteger(0, objectName, OBJPROP_WIDTH, 2);
  ObjectSetInteger(0, objectName, OBJPROP_SELECTABLE, false);
}


//+------------------------------------------------------------------+
//| Met à jour les niveaux de la position virtuelle                  |
//+------------------------------------------------------------------+
void UpdateVirtualPositionLines(void) {
  if (!InpShowVirtualPositionLevels ||
    !g_virtualPosition.IsOpen()) {

    ObjectDelete(0, g_virtualEntryName);
    ObjectDelete(0, g_virtualStopName);
    return;
  }

  UpdateHorizontalLine(
    g_virtualEntryName,
    g_virtualPosition.EntryPrice(),
    InpVirtualEntryColor,
    STYLE_DOT,
    1);

  UpdateHorizontalLine(
    g_virtualStopName,
    g_virtualPosition.StopLossPrice(),
    InpVirtualStopColor,
    STYLE_SOLID,
    2);
}


//+------------------------------------------------------------------+
//| Met à jour l'affichage                                           |
//+------------------------------------------------------------------+
void UpdateChartDisplay(
  const SPbMomentumSnapshot &snapshot) {

  if (InpShowMomentumReference) {
    UpdateHorizontalLine(
      g_momentumReferenceName,
      snapshot.pastClose,
      InpMomentumReferenceColor,
      STYLE_DASH,
      1);
  } else {
    ObjectDelete(0, g_momentumReferenceName);
  }

  UpdateVirtualPositionLines();

  Comment(
    __FILE__, " — MOMENTUM TEMPOREL\n",
    "Symbole : ", _Symbol,
    " | UT : ", EnumToString(InpSignalTimeframe),
    " | Direction : ", V5DirectionModeToString(InpDirectionMode), "\n",
    "Bougie clôturée : ",
    TimeToString(snapshot.signalBarTime, TIME_DATE|TIME_MINUTES), "\n",
    "Clôture actuelle : ", DoubleToString(snapshot.signalClose, _Digits),
    " | Clôture il y a ", InpMomentumLookback, " bougies : ",
    DoubleToString(snapshot.pastClose, _Digits), "\n",
    "Momentum : ", DoubleToString(snapshot.momentumPercent, 2), "%",
    " | Régime : ",
    V5PositionDirectionToString(snapshot.momentumDirection), "\n",
    "ATR(", InpAtrPeriod, ") : ",
    DoubleToString(snapshot.atrPoints, 1), " points",
    " | Stop initial : ",
    DoubleToString(InpInitialStopAtrMultiplier, 2), " ATR\n",
    g_virtualPosition.BuildStatusText(), "\n",
    "Bougies : ", g_processedBarCount,
    " | Transitions LONG/SHORT : ",
    g_longTransitionCount, "/", g_shortTransitionCount,
    " | Ouvertures LONG/SHORT : ",
    g_longOpenCount, "/", g_shortOpenCount);
}


//+------------------------------------------------------------------+
//| Met à jour les statistiques de régime                            |
//+------------------------------------------------------------------+
void UpdateRegimeCounters(
  const ENUM_PB_V5_POSITION_DIRECTION direction) {

  if (direction == PB_V5_POSITION_LONG)
  g_longRegimeBarCount++;
  else if (direction == PB_V5_POSITION_SHORT)
  g_shortRegimeBarCount++;
  else
  g_neutralRegimeBarCount++;

  if (g_previousMomentumDirection != PB_V5_POSITION_FLAT &&
    direction != PB_V5_POSITION_FLAT &&
    direction != g_previousMomentumDirection) {

    if (direction == PB_V5_POSITION_LONG)
    g_longTransitionCount++;
    else
    g_shortTransitionCount++;
  }

  if (direction != PB_V5_POSITION_FLAT)
  g_previousMomentumDirection = direction;
}


//+------------------------------------------------------------------+
//| Traite la dernière bougie clôturée                               |
//+------------------------------------------------------------------+
void ProcessClosedBar(
  const MqlTick &tick,
  const bool positionClosedEarlierThisTick) {

  SPbMomentumSnapshot snapshot;

  if (!EvaluateClosedBar(snapshot) || !snapshot.isValid)
  return;

  g_lastSnapshot = snapshot;
  g_hasLastSnapshot = true;
  g_processedBarCount++;

  UpdateRegimeCounters(snapshot.momentumDirection);

  // Une inversion clôture la position existante. Contrairement à une
  // sortie par stop, elle peut être suivie immédiatement de l'ouverture
  // de la direction opposée au même premier tick de la nouvelle bougie.
  g_virtualPosition.ProcessMomentumExit(
    snapshot.momentumDirection,
    tick);

  bool opened = false;

  if (!g_virtualPosition.IsOpen() &&
    !positionClosedEarlierThisTick &&
    DirectionIsAllowed(snapshot.momentumDirection)) {

    opened = g_virtualPosition.OpenPosition(
      snapshot.momentumDirection,
      snapshot.signalBarTime,
      snapshot.atrPrice,
      snapshot.atrPoints,
      tick);

    if (opened) {
      if (snapshot.momentumDirection == PB_V5_POSITION_LONG)
      g_longOpenCount++;
      else
      g_shortOpenCount++;

      DrawEntryArrow(
        snapshot,
        snapshot.momentumDirection);
    }
  }

  UpdateChartDisplay(snapshot);

  PrintFormat(
    "[%s][INFO] BARRE | Temps=%s | "
    "O=%.5f H=%.5f L=%.5f C=%.5f | "
    "Clôture passée=%.5f | Momentum=%.2f%% | Régime=%s | "
    "ATR=%.1f points | Ouverture=%s | Position=%s | Capital=%.2f",
    __FILE__,
    TimeToString(snapshot.signalBarTime, TIME_DATE|TIME_MINUTES),
    snapshot.signalOpen,
    snapshot.signalHigh,
    snapshot.signalLow,
    snapshot.signalClose,
    snapshot.pastClose,
    snapshot.momentumPercent,
    V5PositionDirectionToString(snapshot.momentumDirection),
    snapshot.atrPoints,
    opened ? "OUI" : "NON",
    V5PositionDirectionToString(g_virtualPosition.Direction()),
    g_virtualPosition.VirtualCapital());
}


//+------------------------------------------------------------------+
//| Vérifie l'apparition d'une nouvelle bougie                       |
//+------------------------------------------------------------------+
bool IsNewBar(void) {
  datetime currentBarTime = iTime(
    _Symbol,
    InpSignalTimeframe,
    0);

  if (currentBarTime <= 0)
  return false;

  if (g_currentBarTime == 0) {
    g_currentBarTime = currentBarTime;
    return true;
  }

  if (currentBarTime == g_currentBarTime)
  return false;

  g_currentBarTime = currentBarTime;
  return true;
}


//+------------------------------------------------------------------+
//| Initialisation                                                   |
//+------------------------------------------------------------------+
int OnInit(void) {
  if (!InitializeIndicators())
  return INIT_FAILED;

  if (!g_virtualPosition.Initialize(
      _Symbol,
      InpInitialCapital,
      InpRiskPercent,
      InpInitialStopAtrMultiplier)) {

    ReleaseIndicators();
    return INIT_FAILED;
  }

  g_currentBarTime = 0;
  g_hasLastSnapshot = false;
  g_previousMomentumDirection = PB_V5_POSITION_FLAT;
  g_processedBarCount = 0;
  g_longRegimeBarCount = 0;
  g_shortRegimeBarCount = 0;
  g_neutralRegimeBarCount = 0;
  g_longTransitionCount = 0;
  g_shortTransitionCount = 0;
  g_longOpenCount = 0;
  g_shortOpenCount = 0;
  ZeroMemory(g_lastSnapshot);

  PrintFormat(
    "[%s][INFO] DÉMARRAGE | Symbole=%s | UT=%s | Direction=%s | "
    "Momentum=%d bougies | ATR=%d | SL=%.2f ATR | "
    "Sortie=MOMENTUM_REVERSAL | Capital=%.2f | Risque=%.2f%% | "
    "Mode=SIMULATION",
    __FILE__,
    _Symbol,
    EnumToString(InpSignalTimeframe),
    V5DirectionModeToString(InpDirectionMode),
    InpMomentumLookback,
    InpAtrPeriod,
    InpInitialStopAtrMultiplier,
    InpInitialCapital,
    InpRiskPercent);

  return INIT_SUCCEEDED;
}


//+------------------------------------------------------------------+
//| Désinitialisation                                                |
//+------------------------------------------------------------------+
void OnDeinit(const int reason) {
  MqlTick tick;

  if (SymbolInfoTick(_Symbol, tick))
  g_virtualPosition.CloseAtTestEnd(tick);

  PrintFormat(
    "[%s][INFO] Résumé momentum : Bougies=%I64d | "
    "Régime LONG=%I64d | Régime SHORT=%I64d | Neutre=%I64d | "
    "Transitions LONG=%I64d | Transitions SHORT=%I64d | "
    "Ouvertures LONG=%I64d | Ouvertures SHORT=%I64d | "
    "UT=%s | Recul=%d",
    __FILE__,
    g_processedBarCount,
    g_longRegimeBarCount,
    g_shortRegimeBarCount,
    g_neutralRegimeBarCount,
    g_longTransitionCount,
    g_shortTransitionCount,
    g_longOpenCount,
    g_shortOpenCount,
    EnumToString(InpSignalTimeframe),
    InpMomentumLookback);

  g_virtualPosition.PrintFinalSummary();
  ReleaseIndicators();

  ObjectsDeleteAll(0, g_objectPrefix);
  Comment("");

  PrintFormat(
    "[%s][INFO] ARRÊT | Raison=%d",
    __FILE__,
    reason);
}


//+------------------------------------------------------------------+
//| Tick                                                             |
//+------------------------------------------------------------------+
void OnTick(void) {
  MqlTick tick;

  if (!SymbolInfoTick(_Symbol, tick))
  return;

  bool closedByStop =
    g_virtualPosition.ProcessTick(tick);

  if (closedByStop && g_hasLastSnapshot)
  UpdateChartDisplay(g_lastSnapshot);

  if (!IsNewBar())
  return;

  ProcessClosedBar(
    tick,
    closedByStop);
}
