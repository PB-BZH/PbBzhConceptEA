//+------------------------------------------------------------------+
//|                       PbBzhConceptEA_v4_00.mq5                   |
//|  v4.00 : retour à la moyenne Bollinger / RSI en régime calme    |
//+------------------------------------------------------------------+
#property copyright "Copyright 2026, PbBzhConcept"
#property version   "4.00"
#property strict
#property description "Recherche : retour à la moyenne après excès"
#property description "Réintégration Bollinger, confirmation RSI, filtre ADX"
#property description "LONG et SHORT, SL initial ATR, sortie moyenne centrale"

#include <PbBzhConcept\Simulation\VirtualMeanReversionPositionManager.mqh>

enum ENUM_PB_V4_DIRECTION_MODE {
  PB_V4_DIRECTION_LONG_ONLY = 0,
  PB_V4_DIRECTION_SHORT_ONLY,
  PB_V4_DIRECTION_BOTH
};

enum ENUM_PB_V4_SIGNAL {
  PB_V4_SIGNAL_NONE = 0,
  PB_V4_SIGNAL_LONG,
  PB_V4_SIGNAL_SHORT
};

struct SPbMeanReversionSnapshot {
  bool isValid;
  datetime signalBarTime;

  double signalOpen;
  double signalHigh;
  double signalLow;
  double signalClose;
  double previousClose;

  double middleBand;
  double upperBand;
  double lowerBand;
  double previousMiddleBand;
  double previousUpperBand;
  double previousLowerBand;

  double currentRsi;
  double previousRsi;
  double currentAdx;
  double atrPrice;
  double atrPoints;

  bool rangeAllowed;
  bool rawLongTrigger;
  bool rawShortTrigger;
  ENUM_PB_V4_SIGNAL signal;
};

string V4DirectionModeToString(
  const ENUM_PB_V4_DIRECTION_MODE mode) {

  switch (mode) {
    case PB_V4_DIRECTION_LONG_ONLY:
      return "LONG_ONLY";

    case PB_V4_DIRECTION_SHORT_ONLY:
      return "SHORT_ONLY";

    case PB_V4_DIRECTION_BOTH:
    default:
      return "BOTH";
  }
}

string V4SignalToString(
  const ENUM_PB_V4_SIGNAL signal) {

  switch (signal) {
    case PB_V4_SIGNAL_LONG:
      return "LONG";

    case PB_V4_SIGNAL_SHORT:
      return "SHORT";

    case PB_V4_SIGNAL_NONE:
    default:
      return "NONE";
  }
}

input group "Général"
input ENUM_TIMEFRAMES InpSignalTimeframe = PERIOD_H1;
input ENUM_PB_V4_DIRECTION_MODE InpDirectionMode = PB_V4_DIRECTION_BOTH;

input group "Bandes de Bollinger"
input int InpBollingerPeriod = 20;
input double InpBollingerDeviation = 2.00;

input group "Confirmation RSI"
input int InpRsiPeriod = 14;
input double InpRsiOversoldLevel = 30.0;
input double InpRsiOverboughtLevel = 70.0;

input group "Filtre de marché sans tendance"
input bool InpUseRangeFilter = true;
input ENUM_TIMEFRAMES InpAdxTimeframe = PERIOD_H4;
input int InpAdxPeriod = 14;
input double InpMaximumAdx = 25.0;

input group "Volatilité et protection"
input int InpAtrPeriod = 14;
input double InpInitialStopAtrMultiplier = 2.00;

input group "Simulation virtuelle"
input double InpInitialCapital = 10000.00;
input double InpRiskPercent = 1.00;

input group "Affichage"
input bool InpShowBollingerLevels = true;
input bool InpShowSignalArrows = true;
input bool InpShowVirtualPositionLevels = true;
input double InpArrowOffsetAtr = 0.20;
input color InpMiddleBandColor = clrGold;
input color InpOuterBandColor = clrSlateGray;
input color InpBuyArrowColor = clrLimeGreen;
input color InpSellArrowColor = clrTomato;
input color InpVirtualEntryColor = clrDeepSkyBlue;
input color InpVirtualStopColor = clrMagenta;

CVirtualMeanReversionPositionManager g_virtualPosition;

int g_bollingerHandle = INVALID_HANDLE;
int g_rsiHandle = INVALID_HANDLE;
int g_adxHandle = INVALID_HANDLE;
int g_atrHandle = INVALID_HANDLE;

datetime g_currentBarTime = 0;
bool g_hasLastSnapshot = false;
SPbMeanReversionSnapshot g_lastSnapshot;

long g_processedBarCount = 0;
long g_rangeAllowedBarCount = 0;
long g_rangeRejectedBarCount = 0;
long g_longTriggerCount = 0;
long g_shortTriggerCount = 0;
long g_longAcceptedCount = 0;
long g_shortAcceptedCount = 0;
long g_longAdxRejectedCount = 0;
long g_shortAdxRejectedCount = 0;
long g_longDirectionRejectedCount = 0;
long g_shortDirectionRejectedCount = 0;

string g_objectPrefix = "PB400_";
string g_middleBandName = "PB400_MIDDLE_BAND";
string g_upperBandName = "PB400_UPPER_BAND";
string g_lowerBandName = "PB400_LOWER_BAND";
string g_virtualEntryName = "PB400_VIRTUAL_ENTRY";
string g_virtualStopName = "PB400_VIRTUAL_STOP";


//+------------------------------------------------------------------+
//| Libère tous les indicateurs                                      |
//+------------------------------------------------------------------+
void ReleaseIndicators(void) {
  if (g_bollingerHandle != INVALID_HANDLE) {
    IndicatorRelease(g_bollingerHandle);
    g_bollingerHandle = INVALID_HANDLE;
  }

  if (g_rsiHandle != INVALID_HANDLE) {
    IndicatorRelease(g_rsiHandle);
    g_rsiHandle = INVALID_HANDLE;
  }

  if (g_adxHandle != INVALID_HANDLE) {
    IndicatorRelease(g_adxHandle);
    g_adxHandle = INVALID_HANDLE;
  }

  if (g_atrHandle != INVALID_HANDLE) {
    IndicatorRelease(g_atrHandle);
    g_atrHandle = INVALID_HANDLE;
  }
}


//+------------------------------------------------------------------+
//| Initialise les indicateurs                                       |
//+------------------------------------------------------------------+
bool InitializeIndicators(void) {
  if (InpBollingerPeriod < 2 ||
    InpBollingerDeviation <= 0.0 ||
    InpRsiPeriod < 2 ||
    InpRsiOversoldLevel <= 0.0 ||
    InpRsiOverboughtLevel >= 100.0 ||
    InpRsiOversoldLevel >= InpRsiOverboughtLevel ||
    InpAdxPeriod < 2 ||
    InpMaximumAdx <= 0.0 ||
    InpAtrPeriod < 2) {

    PrintFormat(
      "[%s][ERROR] Paramètres d'indicateurs invalides.",
      __FILE__);

    return false;
  }

  g_bollingerHandle = iBands(
    _Symbol,
    InpSignalTimeframe,
    InpBollingerPeriod,
    0,
    InpBollingerDeviation,
    PRICE_CLOSE);

  g_rsiHandle = iRSI(
    _Symbol,
    InpSignalTimeframe,
    InpRsiPeriod,
    PRICE_CLOSE);

  g_adxHandle = iADX(
    _Symbol,
    InpAdxTimeframe,
    InpAdxPeriod);

  g_atrHandle = iATR(
    _Symbol,
    InpSignalTimeframe,
    InpAtrPeriod);

  if (g_bollingerHandle == INVALID_HANDLE ||
    g_rsiHandle == INVALID_HANDLE ||
    g_adxHandle == INVALID_HANDLE ||
    g_atrHandle == INVALID_HANDLE) {

    PrintFormat(
      "[%s][ERROR] Création d'un indicateur impossible. Erreur=%d",
      __FILE__,
      GetLastError());

    ReleaseIndicators();
    return false;
  }

  return true;
}


//+------------------------------------------------------------------+
//| Lit une valeur d'indicateur                                      |
//+------------------------------------------------------------------+
bool ReadIndicatorValue(
  const int handle,
  const int bufferIndex,
  const int shift,
  double &value) {

  double buffer[1];
  ResetLastError();

  if (handle == INVALID_HANDLE ||
    CopyBuffer(
      handle,
      bufferIndex,
      shift,
      1,
      buffer) != 1) {

    return false;
  }

  value = buffer[0];
  return true;
}


//+------------------------------------------------------------------+
//| Évalue uniquement des bougies entièrement clôturées              |
//+------------------------------------------------------------------+
bool EvaluateClosedBar(
  SPbMeanReversionSnapshot &snapshot) {

  ZeroMemory(snapshot);
  snapshot.signal = PB_V4_SIGNAL_NONE;

  snapshot.signalBarTime = iTime(
    _Symbol,
    InpSignalTimeframe,
    1);

  snapshot.signalOpen = iOpen(
    _Symbol,
    InpSignalTimeframe,
    1);

  snapshot.signalHigh = iHigh(
    _Symbol,
    InpSignalTimeframe,
    1);

  snapshot.signalLow = iLow(
    _Symbol,
    InpSignalTimeframe,
    1);

  snapshot.signalClose = iClose(
    _Symbol,
    InpSignalTimeframe,
    1);

  snapshot.previousClose = iClose(
    _Symbol,
    InpSignalTimeframe,
    2);

  // iBands : buffer 0 = moyenne, 1 = bande supérieure,
  // 2 = bande inférieure.
  bool dataAvailable =
    snapshot.signalBarTime > 0 &&
    snapshot.signalOpen > 0.0 &&
    snapshot.signalHigh > 0.0 &&
    snapshot.signalLow > 0.0 &&
    snapshot.signalClose > 0.0 &&
    snapshot.previousClose > 0.0 &&
    ReadIndicatorValue(
      g_bollingerHandle,
      0,
      1,
      snapshot.middleBand) &&
    ReadIndicatorValue(
      g_bollingerHandle,
      1,
      1,
      snapshot.upperBand) &&
    ReadIndicatorValue(
      g_bollingerHandle,
      2,
      1,
      snapshot.lowerBand) &&
    ReadIndicatorValue(
      g_bollingerHandle,
      0,
      2,
      snapshot.previousMiddleBand) &&
    ReadIndicatorValue(
      g_bollingerHandle,
      1,
      2,
      snapshot.previousUpperBand) &&
    ReadIndicatorValue(
      g_bollingerHandle,
      2,
      2,
      snapshot.previousLowerBand) &&
    ReadIndicatorValue(
      g_rsiHandle,
      0,
      1,
      snapshot.currentRsi) &&
    ReadIndicatorValue(
      g_rsiHandle,
      0,
      2,
      snapshot.previousRsi) &&
    ReadIndicatorValue(
      g_adxHandle,
      0,
      1,
      snapshot.currentAdx) &&
    ReadIndicatorValue(
      g_atrHandle,
      0,
      1,
      snapshot.atrPrice);

  if (!dataAvailable ||
    snapshot.atrPrice <= 0.0 ||
    snapshot.lowerBand >= snapshot.middleBand ||
    snapshot.middleBand >= snapshot.upperBand) {

    return false;
  }

  snapshot.atrPoints = snapshot.atrPrice / _Point;
  snapshot.rangeAllowed =
    !InpUseRangeFilter ||
    snapshot.currentAdx <= InpMaximumAdx;

  // LONG : excès sous la bande inférieure, puis réintégration.
  // La clôture doit rester sous la moyenne, qui demeure la cible.
  snapshot.rawLongTrigger =
    snapshot.previousClose < snapshot.previousLowerBand &&
    snapshot.signalClose >= snapshot.lowerBand &&
    snapshot.signalClose < snapshot.middleBand &&
    snapshot.previousRsi <= InpRsiOversoldLevel &&
    snapshot.currentRsi > InpRsiOversoldLevel;

  // SHORT : conditions exactement symétriques.
  snapshot.rawShortTrigger =
    snapshot.previousClose > snapshot.previousUpperBand &&
    snapshot.signalClose <= snapshot.upperBand &&
    snapshot.signalClose > snapshot.middleBand &&
    snapshot.previousRsi >= InpRsiOverboughtLevel &&
    snapshot.currentRsi < InpRsiOverboughtLevel;

  bool allowLong =
    InpDirectionMode == PB_V4_DIRECTION_LONG_ONLY ||
    InpDirectionMode == PB_V4_DIRECTION_BOTH;

  bool allowShort =
    InpDirectionMode == PB_V4_DIRECTION_SHORT_ONLY ||
    InpDirectionMode == PB_V4_DIRECTION_BOTH;

  if (snapshot.rawLongTrigger &&
    snapshot.rangeAllowed &&
    allowLong) {

    snapshot.signal = PB_V4_SIGNAL_LONG;
  }
  else if (snapshot.rawShortTrigger &&
    snapshot.rangeAllowed &&
    allowShort) {

    snapshot.signal = PB_V4_SIGNAL_SHORT;
  }

  snapshot.isValid = true;
  return true;
}


//+------------------------------------------------------------------+
//| Met à jour une ligne horizontale                                 |
//+------------------------------------------------------------------+
void UpdateHorizontalLine(
  const string objectName,
  const double price,
  const color lineColor,
  const ENUM_LINE_STYLE lineStyle,
  const int lineWidth) {

  if (price <= 0.0)
    return;

  if (ObjectFind(0, objectName) < 0) {
    if (!ObjectCreate(
      0,
      objectName,
      OBJ_HLINE,
      0,
      0,
      price)) {

      PrintFormat(
        "[%s][ERROR] Création objet %s impossible. Erreur=%d",
        __FILE__,
        objectName,
        GetLastError());

      return;
    }
  }

  ObjectSetDouble(0, objectName, OBJPROP_PRICE, price);
  ObjectSetInteger(0, objectName, OBJPROP_COLOR, lineColor);
  ObjectSetInteger(0, objectName, OBJPROP_STYLE, lineStyle);
  ObjectSetInteger(0, objectName, OBJPROP_WIDTH, lineWidth);
  ObjectSetInteger(0, objectName, OBJPROP_BACK, true);
  ObjectSetInteger(0, objectName, OBJPROP_SELECTABLE, false);
}


//+------------------------------------------------------------------+
//| Dessine la flèche d'un signal accepté                            |
//+------------------------------------------------------------------+
void DrawSignalArrow(
  const SPbMeanReversionSnapshot &snapshot) {

  if (!InpShowSignalArrows ||
    snapshot.signal == PB_V4_SIGNAL_NONE) {

    return;
  }

  string objectName = StringFormat(
    "%s%s_%I64d",
    g_objectPrefix,
    V4SignalToString(snapshot.signal),
    (long)snapshot.signalBarTime);

  if (ObjectFind(0, objectName) >= 0)
    return;

  ENUM_OBJECT objectType =
    snapshot.signal == PB_V4_SIGNAL_LONG
    ? OBJ_ARROW_BUY
    : OBJ_ARROW_SELL;

  double offset = snapshot.atrPrice *
    MathMax(0.0, InpArrowOffsetAtr);

  double arrowPrice =
    snapshot.signal == PB_V4_SIGNAL_LONG
    ? snapshot.signalLow - offset
    : snapshot.signalHigh + offset;

  if (!ObjectCreate(
    0,
    objectName,
    objectType,
    0,
    snapshot.signalBarTime,
    arrowPrice)) {

    PrintFormat(
      "[%s][ERROR] Création flèche impossible. Erreur=%d",
      __FILE__,
      GetLastError());

    return;
  }

  ObjectSetInteger(
    0,
    objectName,
    OBJPROP_COLOR,
    snapshot.signal == PB_V4_SIGNAL_LONG
    ? InpBuyArrowColor
    : InpSellArrowColor);

  ObjectSetInteger(0, objectName, OBJPROP_WIDTH, 2);
  ObjectSetInteger(0, objectName, OBJPROP_SELECTABLE, false);
}


//+------------------------------------------------------------------+
//| Met à jour les niveaux de la position virtuelle                  |
//+------------------------------------------------------------------+
void UpdateVirtualPositionLines(void) {
  if (!InpShowVirtualPositionLevels ||
    !g_virtualPosition.IsOpen()) {

    ObjectDelete(0, g_virtualEntryName);
    ObjectDelete(0, g_virtualStopName);
    return;
  }

  UpdateHorizontalLine(
    g_virtualEntryName,
    g_virtualPosition.EntryPrice(),
    InpVirtualEntryColor,
    STYLE_DOT,
    1);

  UpdateHorizontalLine(
    g_virtualStopName,
    g_virtualPosition.StopLossPrice(),
    InpVirtualStopColor,
    STYLE_SOLID,
    2);
}


//+------------------------------------------------------------------+
//| Met à jour l'affichage du dernier état                           |
//+------------------------------------------------------------------+
void UpdateChartDisplay(
  const SPbMeanReversionSnapshot &snapshot) {

  if (InpShowBollingerLevels) {
    UpdateHorizontalLine(
      g_middleBandName,
      snapshot.middleBand,
      InpMiddleBandColor,
      STYLE_SOLID,
      2);

    UpdateHorizontalLine(
      g_upperBandName,
      snapshot.upperBand,
      InpOuterBandColor,
      STYLE_DASH,
      1);

    UpdateHorizontalLine(
      g_lowerBandName,
      snapshot.lowerBand,
      InpOuterBandColor,
      STYLE_DASH,
      1);
  }
  else {
    ObjectDelete(0, g_middleBandName);
    ObjectDelete(0, g_upperBandName);
    ObjectDelete(0, g_lowerBandName);
  }

  DrawSignalArrow(snapshot);
  UpdateVirtualPositionLines();

  Comment(
    __FILE__, " — RETOUR À LA MOYENNE\n",
    "Symbole : ", _Symbol,
    " | UT : ", EnumToString(InpSignalTimeframe),
    " | Direction : ", V4DirectionModeToString(InpDirectionMode), "\n",
    "Bougie clôturée : ",
    TimeToString(snapshot.signalBarTime, TIME_DATE|TIME_MINUTES), "\n",
    "Signal : ", V4SignalToString(snapshot.signal),
    " | Clôture précédente/courante : ",
    DoubleToString(snapshot.previousClose, _Digits), " / ",
    DoubleToString(snapshot.signalClose, _Digits), "\n",
    "Bollinger inférieure/moyenne/supérieure : ",
    DoubleToString(snapshot.lowerBand, _Digits), " / ",
    DoubleToString(snapshot.middleBand, _Digits), " / ",
    DoubleToString(snapshot.upperBand, _Digits), "\n",
    "RSI précédent/courant : ",
    DoubleToString(snapshot.previousRsi, 2), " / ",
    DoubleToString(snapshot.currentRsi, 2),
    " | Seuils : ", DoubleToString(InpRsiOversoldLevel, 1),
    " / ", DoubleToString(InpRsiOverboughtLevel, 1), "\n",
    "ADX ", EnumToString(InpAdxTimeframe), " : ",
    DoubleToString(snapshot.currentAdx, 2),
    " | Maximum : ", DoubleToString(InpMaximumAdx, 2),
    " | Régime : ", snapshot.rangeAllowed ? "ACCEPTÉ" : "REFUSÉ", "\n",
    "ATR(", InpAtrPeriod, ") : ",
    DoubleToString(snapshot.atrPoints, 1), " points",
    " | SL : ", DoubleToString(InpInitialStopAtrMultiplier, 2), " ATR\n",
    g_virtualPosition.BuildStatusText(), "\n",
    "Bougies : ", g_processedBarCount,
    " | Signaux LONG/SHORT acceptés : ",
    g_longAcceptedCount, "/", g_shortAcceptedCount);
}


//+------------------------------------------------------------------+
//| Comptabilise les signaux et les refus                            |
//+------------------------------------------------------------------+
void UpdateSignalCounters(
  const SPbMeanReversionSnapshot &snapshot) {

  bool allowLong =
    InpDirectionMode == PB_V4_DIRECTION_LONG_ONLY ||
    InpDirectionMode == PB_V4_DIRECTION_BOTH;

  bool allowShort =
    InpDirectionMode == PB_V4_DIRECTION_SHORT_ONLY ||
    InpDirectionMode == PB_V4_DIRECTION_BOTH;

  if (snapshot.rawLongTrigger) {
    g_longTriggerCount++;

    if (!snapshot.rangeAllowed)
      g_longAdxRejectedCount++;
    else if (!allowLong)
      g_longDirectionRejectedCount++;
    else
      g_longAcceptedCount++;
  }

  if (snapshot.rawShortTrigger) {
    g_shortTriggerCount++;

    if (!snapshot.rangeAllowed)
      g_shortAdxRejectedCount++;
    else if (!allowShort)
      g_shortDirectionRejectedCount++;
    else
      g_shortAcceptedCount++;
  }
}


//+------------------------------------------------------------------+
//| Traite la dernière bougie clôturée                               |
//+------------------------------------------------------------------+
void ProcessClosedBar(
  const MqlTick &tick,
  const bool positionClosedEarlierThisTick) {

  SPbMeanReversionSnapshot snapshot;

  if (!EvaluateClosedBar(snapshot) || !snapshot.isValid)
    return;

  g_lastSnapshot = snapshot;
  g_hasLastSnapshot = true;
  g_processedBarCount++;

  if (snapshot.rangeAllowed)
    g_rangeAllowedBarCount++;
  else
    g_rangeRejectedBarCount++;

  UpdateSignalCounters(snapshot);

  // La cible est évaluée sur la clôture H1, puis exécutée au tick
  // disponible à l'ouverture de la nouvelle bougie.
  bool closedByMiddleBand =
    g_virtualPosition.ProcessMiddleBandExit(
      snapshot.signalClose,
      snapshot.middleBand,
      tick);

  if (!g_virtualPosition.IsOpen() &&
    !closedByMiddleBand &&
    !positionClosedEarlierThisTick) {

    ENUM_PB_V4_POSITION_DIRECTION direction =
      PB_V4_POSITION_FLAT;

    if (snapshot.signal == PB_V4_SIGNAL_LONG)
      direction = PB_V4_POSITION_LONG;
    else if (snapshot.signal == PB_V4_SIGNAL_SHORT)
      direction = PB_V4_POSITION_SHORT;

    if (direction != PB_V4_POSITION_FLAT) {
      g_virtualPosition.OpenPosition(
        direction,
        snapshot.signalBarTime,
        snapshot.atrPrice,
        snapshot.atrPoints,
        tick);
    }
  }

  UpdateChartDisplay(snapshot);

  PrintFormat(
    "[%s][INFO] BARRE | Temps=%s | Signal=%s | "
    "O=%.5f H=%.5f L=%.5f C=%.5f | C précédente=%.5f | "
    "Bandes=%.5f/%.5f/%.5f | RSI=%.2f->%.2f | "
    "ADX=%.2f Régime=%s | ATR=%.1f points | "
    "Position=%s | Capital=%.2f",
    __FILE__,
    TimeToString(snapshot.signalBarTime, TIME_DATE|TIME_MINUTES),
    V4SignalToString(snapshot.signal),
    snapshot.signalOpen,
    snapshot.signalHigh,
    snapshot.signalLow,
    snapshot.signalClose,
    snapshot.previousClose,
    snapshot.lowerBand,
    snapshot.middleBand,
    snapshot.upperBand,
    snapshot.previousRsi,
    snapshot.currentRsi,
    snapshot.currentAdx,
    snapshot.rangeAllowed ? "ACCEPTÉ" : "REFUSÉ",
    snapshot.atrPoints,
    V4PositionDirectionToString(g_virtualPosition.Direction()),
    g_virtualPosition.VirtualCapital());
}


//+------------------------------------------------------------------+
//| Vérifie l'apparition d'une nouvelle bougie                       |
//+------------------------------------------------------------------+
bool IsNewBar(void) {
  datetime currentBarTime = iTime(
    _Symbol,
    InpSignalTimeframe,
    0);

  if (currentBarTime <= 0)
    return false;

  if (g_currentBarTime == 0) {
    g_currentBarTime = currentBarTime;
    return true;
  }

  if (currentBarTime == g_currentBarTime)
    return false;

  g_currentBarTime = currentBarTime;
  return true;
}


//+------------------------------------------------------------------+
//| Initialisation                                                   |
//+------------------------------------------------------------------+
int OnInit(void) {
  if (!InitializeIndicators())
    return INIT_FAILED;

  if (!g_virtualPosition.Initialize(
    _Symbol,
    InpInitialCapital,
    InpRiskPercent,
    InpInitialStopAtrMultiplier)) {

    ReleaseIndicators();
    return INIT_FAILED;
  }

  g_currentBarTime = 0;
  g_hasLastSnapshot = false;
  g_processedBarCount = 0;
  g_rangeAllowedBarCount = 0;
  g_rangeRejectedBarCount = 0;
  g_longTriggerCount = 0;
  g_shortTriggerCount = 0;
  g_longAcceptedCount = 0;
  g_shortAcceptedCount = 0;
  g_longAdxRejectedCount = 0;
  g_shortAdxRejectedCount = 0;
  g_longDirectionRejectedCount = 0;
  g_shortDirectionRejectedCount = 0;
  ZeroMemory(g_lastSnapshot);

  PrintFormat(
    "[%s][INFO] DÉMARRAGE | Symbole=%s | UT=%s | Direction=%s | "
    "Bollinger=%d/%.2f | RSI=%d seuils=%.2f/%.2f | "
    "Filtre range=%s | ADX=%s/%d maximum=%.2f | ATR=%d | "
    "SL=%.2f ATR | Sortie=MIDDLE_BAND_ONLY | "
    "Capital=%.2f | Risque=%.2f%% | Mode=SIMULATION",
    __FILE__,
    _Symbol,
    EnumToString(InpSignalTimeframe),
    V4DirectionModeToString(InpDirectionMode),
    InpBollingerPeriod,
    InpBollingerDeviation,
    InpRsiPeriod,
    InpRsiOversoldLevel,
    InpRsiOverboughtLevel,
    InpUseRangeFilter ? "ACTIF" : "INACTIF",
    EnumToString(InpAdxTimeframe),
    InpAdxPeriod,
    InpMaximumAdx,
    InpAtrPeriod,
    InpInitialStopAtrMultiplier,
    InpInitialCapital,
    InpRiskPercent);

  return INIT_SUCCEEDED;
}


//+------------------------------------------------------------------+
//| Désinitialisation                                                |
//+------------------------------------------------------------------+
void OnDeinit(const int reason) {
  MqlTick tick;

  if (SymbolInfoTick(_Symbol, tick))
    g_virtualPosition.CloseAtTestEnd(tick);

  PrintFormat(
    "[%s][INFO] Résumé régimes : Bougies=%I64d | "
    "ADX accepté=%I64d | ADX refusé=%I64d | "
    "Filtre=%s | ADX=%s/%d | Maximum=%.2f",
    __FILE__,
    g_processedBarCount,
    g_rangeAllowedBarCount,
    g_rangeRejectedBarCount,
    InpUseRangeFilter ? "ACTIF" : "INACTIF",
    EnumToString(InpAdxTimeframe),
    InpAdxPeriod,
    InpMaximumAdx);

  PrintFormat(
    "[%s][INFO] Résumé signaux : "
    "LONG détectés=%I64d | Acceptés=%I64d | Refusés ADX=%I64d | "
    "Refusés direction=%I64d | SHORT détectés=%I64d | "
    "Acceptés=%I64d | Refusés ADX=%I64d | Refusés direction=%I64d | "
    "Bollinger=%d/%.2f | RSI=%d seuils=%.2f/%.2f | Direction=%s",
    __FILE__,
    g_longTriggerCount,
    g_longAcceptedCount,
    g_longAdxRejectedCount,
    g_longDirectionRejectedCount,
    g_shortTriggerCount,
    g_shortAcceptedCount,
    g_shortAdxRejectedCount,
    g_shortDirectionRejectedCount,
    InpBollingerPeriod,
    InpBollingerDeviation,
    InpRsiPeriod,
    InpRsiOversoldLevel,
    InpRsiOverboughtLevel,
    V4DirectionModeToString(InpDirectionMode));

  g_virtualPosition.PrintFinalSummary();
  ReleaseIndicators();

  ObjectsDeleteAll(0, g_objectPrefix);
  Comment("");

  PrintFormat(
    "[%s][INFO] ARRÊT | Raison=%d",
    __FILE__,
    reason);
}


//+------------------------------------------------------------------+
//| Tick                                                             |
//+------------------------------------------------------------------+
void OnTick(void) {
  MqlTick tick;

  if (!SymbolInfoTick(_Symbol, tick))
    return;

  bool closedByStop =
    g_virtualPosition.ProcessTick(tick);

  if (closedByStop && g_hasLastSnapshot)
    UpdateChartDisplay(g_lastSnapshot);

  if (!IsNewBar())
    return;

  ProcessClosedBar(
    tick,
    closedByStop);
}
