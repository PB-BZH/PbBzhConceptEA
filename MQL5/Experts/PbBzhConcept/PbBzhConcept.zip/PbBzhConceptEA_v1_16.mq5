//+------------------------------------------------------------------+
//|                                              PbBzhConceptEA.mq5  |
//|              Version 1.16 - Observateur avec signaux graphiques  |
//+------------------------------------------------------------------+
#property copyright "Copyright 2026, PbBzhConcept"
#property link      "https://www.mql5.com"
#property version   "1.16"
#property strict
#property description "EA pédagogique : signaux et positions virtuelles"

#include <PbBzhConcept\Core\BarClock.mqh>
#include <PbBzhConcept\Core\EaLogger.mqh>
#include <PbBzhConcept\Signals\MaPriceCrossSignal.mqh>
#include <PbBzhConcept\Presentation\ChartSignalRenderer.mqh>
#include <PbBzhConcept\Statistics\SignalStatistics.mqh>
#include <PbBzhConcept\Simulation\VirtualPositionManager.mqh>
#include <PbBzhConcept\Simulation\ExecutionQuoteProvider.mqh>
#include <PbBzhConcept\Simulation\VirtualVolumeCalculator.mqh>

//--- Paramètres généraux
input group "Général"
input string             InpExpertName       = "PbBzhConceptEA";
input ENUM_TIMEFRAMES    InpSignalTimeframe  = PERIOD_CURRENT;

//--- Paramètres du signal
input group "Signal : croisement cours / moyenne mobile"
input int                InpMaPeriod         = 12;
input int                InpMaShift          = 0;
input ENUM_MA_METHOD     InpMaMethod         = MODE_SMA;
input ENUM_APPLIED_PRICE InpMaAppliedPrice   = PRICE_CLOSE;

//--- Paramètres d'affichage
input group "Affichage graphique"
input bool               InpShowSignalArrows       = true;
input int                InpSignalArrowOffsetPoints= 50;
input color              InpBuyArrowColor          = clrLimeGreen;
input color              InpSellArrowColor         = clrTomato;

input group "Simulation : protections virtuelles"
input int InpVirtualStopLossPoints   = 200;
input int InpVirtualTakeProfitPoints = 400;

input group "Simulation : gestion du volume"
input ENUM_PB_VIRTUAL_VOLUME_MODE InpVirtualVolumeMode= PB_VIRTUAL_VOLUME_RISK_PERCENT;
input double InpVirtualFixedVolumeLots=0.10;
input double InpVirtualRiskPercent=1.00;

input group "Signal : confirmation de tendance"
input bool InpUseMaSlopeFilter = true;

//--- Objets principaux
CEaLogger                 g_logger;
CBarClock                 g_barClock;
CMaPriceCrossSignal       g_signal;
CChartSignalRenderer      g_renderer;
CSignalStatistics         g_statistics;
CVirtualPositionManager   g_virtualPositions;
CExecutionQuoteProvider   g_quoteProvider;

ENUM_TIMEFRAMES           g_timeframe=PERIOD_CURRENT;

//+------------------------------------------------------------------+
//| Initialisation                                                    |
//+------------------------------------------------------------------+
int OnInit(void)
  {
   // ==================================================
   // 1. Initialisation générale.
   // ==================================================
   g_logger.Init(InpExpertName);
   g_statistics.Reset();

   g_timeframe=
      (InpSignalTimeframe==PERIOD_CURRENT)
      ? (ENUM_TIMEFRAMES)_Period
      : InpSignalTimeframe;


   // ==================================================
   // 2. Identification explicite de la version testée.
   // ==================================================
   g_logger.Info(
      StringFormat(
         "DÉMARRAGE | "
         "Version=1.16 | "
         "Source=%s | "
         "Compilation=%s | "
         "Mode volume=%s | "
         "Risque=%.2f%% | "
         "Filtre pente MA=%s",

         __FILE__,

         TimeToString(
            __DATETIME__,
            TIME_DATE|TIME_SECONDS),

         VirtualVolumeModeToString(
            InpVirtualVolumeMode),

         InpVirtualRiskPercent,

         InpUseMaSlopeFilter
         ? "ACTIF"
         : "INACTIF"));


   // ==================================================
   // 3. Horloge de bougies.
   // ==================================================
   if(!g_barClock.Init(
         _Symbol,
         g_timeframe))
     {
      g_logger.Error(
         "Initialisation de l'horloge de bougies impossible.");

      return INIT_FAILED;
     }


   // ==================================================
   // 4. Signal de moyenne mobile.
   // ==================================================
   if(!g_signal.Init(
         _Symbol,
         g_timeframe,
         InpMaPeriod,
         InpMaShift,
         InpMaMethod,
         InpMaAppliedPrice,
         InpUseMaSlopeFilter))
     {
      g_logger.Error(
         "Initialisation du signal de moyenne mobile impossible.");

      return INIT_FAILED;
     }


   // ==================================================
   // 5. Affichage graphique.
   // ==================================================
   if(!g_renderer.Init(
         ChartID(),
         InpExpertName,
         _Symbol,
         g_timeframe,
         InpShowSignalArrows,
         InpSignalArrowOffsetPoints,
         InpBuyArrowColor,
         InpSellArrowColor))
     {
      g_logger.Error(
         "Initialisation de l'affichage graphique impossible.");

      return INIT_FAILED;
     }


   // ==================================================
   // 6. Fournisseur de cotations.
   // ==================================================
   if(!g_quoteProvider.Init(_Symbol))
     {
      g_logger.Error(
         "Initialisation du fournisseur de cotations impossible.");

      return INIT_FAILED;
     }


   // ==================================================
   // 7. Gestionnaire de positions virtuelles.
   // ==================================================
   string virtualPositionInitError;

   if(!g_virtualPositions.Init(
         _Symbol,
         InpVirtualStopLossPoints,
         InpVirtualTakeProfitPoints,
         InpVirtualVolumeMode,
         InpVirtualFixedVolumeLots,
         InpVirtualRiskPercent,
         virtualPositionInitError))
     {
      g_logger.Error(
         StringFormat(
            "Initialisation du gestionnaire de positions "
            "virtuelles impossible : %s",
            virtualPositionInitError));

      return INIT_FAILED;
     }


   // ==================================================
   // 8. Fin de l'initialisation.
   // ==================================================
   g_logger.Warning(
      "Cette version simule des positions en mémoire "
      "mais ne peut envoyer aucun ordre.");

   g_logger.Info(
      StringFormat(
         "Prêt : symbole=%s, période=%s, MA=%d, "
         "filtre pente=%s, flèches=%s.",
         _Symbol,
         EnumToString(g_timeframe),
         InpMaPeriod,
         InpUseMaSlopeFilter ? "ACTIF" : "INACTIF",
         InpShowSignalArrows ? "OUI" : "NON"));

   return INIT_SUCCEEDED;
  }

//+------------------------------------------------------------------+
//| Libération des ressources                                         |
//+------------------------------------------------------------------+
void OnDeinit(const int reason)
  {
      if(!g_virtualPositions.IsConsistent())
     {
      g_logger.Error(
         "Incohérence détectée dans les statistiques "
         "des positions virtuelles.");
     }
   else
     {
      g_logger.Info(
         "Contrôle de cohérence des positions "
         "virtuelles : OK.");
     }   

   g_logger.Info(StringFormat("Résumé MA=%d : %s",InpMaPeriod,g_statistics.BuildSummary()));
   LogVirtualPositionSummary();
   g_logger.Info(g_virtualPositions.BuildDrawdownTimingSummary());
   g_logger.Info(g_virtualPositions.BuildLongSummary());
   g_logger.Info(g_virtualPositions.BuildShortSummary());
   g_logger.Info(g_virtualPositions.BuildLongExitMatrixSummary());
   g_logger.Info(g_virtualPositions.BuildShortExitMatrixSummary());
   g_logger.Info(g_virtualPositions.BuildLongSignalDetailSummary());
   g_logger.Info(g_virtualPositions.BuildShortSignalDetailSummary());
   g_logger.Info(g_virtualPositions.BuildInversionTradeSummary());
   g_logger.Info(g_virtualPositions.BuildInversionDirectionSummary());
   g_logger.Info(g_virtualPositions.BuildFlatEntryTradeSummary());
   g_logger.Info(g_virtualPositions.BuildFlatEntryDirectionSummary());
   g_logger.Info(g_virtualPositions.BuildSignalExitSummary());
   g_logger.Info(g_virtualPositions.BuildStopLossSummary());
   g_logger.Info(g_virtualPositions.BuildTakeProfitSummary());   
   g_signal.Deinit();
   g_logger.Info(StringFormat("Arrêt de l'EA. Motif=%d.",reason));
  }
  
  
//+------------------------------------------------------------------+
//| Traitement d'un nouveau tick                                      |
//+------------------------------------------------------------------+
void OnTick(void)
  {
   // ==================================================
   // 1. Lecture de la cotation à CHAQUE tick.
   // ==================================================
   SExecutionQuote executionQuote;

   if(!g_quoteProvider.Read(executionQuote))
     {
      // CExecutionQuoteProvider écrit déjà le détail
      // de l'erreur dans le journal.
      return;
     }


   // ==================================================
   // 2. Surveillance de la position à CHAQUE tick.
   // ==================================================
   string protectionEvent;

   if(!g_virtualPositions.ProcessTick(
         executionQuote.time,
         executionQuote.bid,
         executionQuote.ask,
         protectionEvent))
     {
      g_logger.Error(
         StringFormat(
            "Erreur de surveillance virtuelle : %s",
            protectionEvent));

      return;
     }

   if(protectionEvent!="")
     {
      g_logger.Info(
         StringFormat(
            "SIMULATION | %s",
            protectionEvent));
     }


   // ==================================================
   // 3. Le signal reste limité aux nouvelles bougies.
   // ==================================================
   if(!g_barClock.IsNewBar())
      return;


   // ==================================================
   // 4. Calcul du signal sur les bougies clôturées.
   // ==================================================
   SMaPriceCrossSnapshot snapshot;

   if(!g_signal.Evaluate(snapshot))
     {
      g_statistics.RecordError();

      g_logger.Error(
         "Le signal n'a pas pu être calculé "
         "pour la nouvelle bougie.");

      return;
     }

   g_statistics.RecordSignal(snapshot.signal);


   string message=StringFormat(
      "SignalBar[1]=%s | "
      "Bar[0]=%s Open[0]=%.*f | "
      "Close[2]=%.*f MA[2]=%.*f | "
      "Close[1]=%.*f MA[1]=%.*f | "
      "Décision=%s",

      TimeToString(
         snapshot.bar1OpenTime,
         TIME_DATE|TIME_MINUTES),

      TimeToString(
         snapshot.bar0OpenTime,
         TIME_DATE|TIME_MINUTES),

      _Digits,
      snapshot.bar0Open,

      _Digits,
      snapshot.bar2Close,

      _Digits,
      snapshot.bar2Ma,

      _Digits,
      snapshot.bar1Close,

      _Digits,
      snapshot.bar1Ma,

      TradeSignalToString(snapshot.signal));


   // ==================================================
   // 5. Journalisation et affichage.
   // ==================================================
   if(snapshot.signal==PB_SIGNAL_NONE)
     {
      g_logger.Info(message);
     }
   else
     {
      g_logger.Signal(message);

      g_logger.Info(
         StringFormat(
            "COTATION | Date=%s | "
            "Open[0]=%.*f | "
            "Bid=%.*f | Ask=%.*f | "
            "Spread=%.1f points",

            TimeToString(
               executionQuote.time,
               TIME_DATE|TIME_MINUTES),

            _Digits,
            snapshot.bar0Open,

            _Digits,
            executionQuote.bid,

            _Digits,
            executionQuote.ask,

            executionQuote.spreadPoints));

      if(!g_renderer.Draw(
            snapshot.signal,
            snapshot.bar1OpenTime,
            snapshot.bar1High,
            snapshot.bar1Low))
        {
         g_logger.Warning(
            "Le signal a été calculé, mais sa flèche "
            "n'a pas pu être affichée.");
        }
     }


   // ==================================================
   // 6. Traitement du signal à la nouvelle bougie.
   // ==================================================
   string virtualEvent;

   if(!g_virtualPositions.ProcessSignal(
         snapshot.signal,
         executionQuote.time,
         executionQuote.bid,
         executionQuote.ask,
         virtualEvent))
     {
      g_logger.Error(
         StringFormat(
            "Erreur de simulation : %s",
            virtualEvent));

      return;
     }

   if(virtualEvent!="")
     {
      g_logger.Info(
         StringFormat(
            "SIMULATION | %s",
            virtualEvent));
     }
  }
  
  // --------------------------------------------------
// Affiche le résumé des positions virtuelles sur
// plusieurs lignes afin d'éviter sa troncature dans
// le journal du Testeur.
// --------------------------------------------------
void LogVirtualPositionSummary(void)
  {
   string summary=
      g_virtualPositions.BuildSummary();


   // Les marqueurs correspondent aux séparations
   // déjà présentes dans BuildSummary().
   string performanceMarker=
      " | Somme gains=";

   string capitalMarker=
      " | Mode volume=";

   string positionMarker=
      " | Position ouverte=";


   int performancePosition=
      StringFind(
         summary,
         performanceMarker);

   int capitalPosition=
      StringFind(
         summary,
         capitalMarker);

   int positionPosition=
      StringFind(
         summary,
         positionMarker);


   // ------------------------------------------------
   // Sécurité :
   // si la structure du résumé a été modifiée et que
   // les marqueurs ne sont plus trouvés, on conserve
   // l'ancien affichage.
   // ------------------------------------------------
   if(performancePosition<0 ||
      capitalPosition<0 ||
      positionPosition<0 ||
      performancePosition>=capitalPosition ||
      capitalPosition>=positionPosition)
     {
      g_logger.Info(
         StringFormat(
            "Résumé positions virtuelles : %s",
            summary));

      return;
     }


   // Longueur de la chaîne séparatrice " | ".
   const int separatorLength=3;


   // ------------------------------------------------
   // Ligne 1 : nombres de trades et résultats points.
   // ------------------------------------------------
   string positionsSummary=
      StringSubstr(
         summary,
         0,
         performancePosition);


   // ------------------------------------------------
   // Ligne 2 : performances monétaires.
   // ------------------------------------------------
   int performanceStart=
      performancePosition+
      separatorLength;

   string performanceSummary=
      StringSubstr(
         summary,
         performanceStart,
         capitalPosition-
         performanceStart);


   // ------------------------------------------------
   // Ligne 3 : capital et gestion du volume.
   // ------------------------------------------------
   int capitalStart=
      capitalPosition+
      separatorLength;

   string capitalSummary=
      StringSubstr(
         summary,
         capitalStart,
         positionPosition-
         capitalStart);


   // ------------------------------------------------
   // Ligne 4 : position éventuellement encore ouverte.
   // ------------------------------------------------
   int positionStart=
      positionPosition+
      separatorLength;

   string openPositionSummary=
      StringSubstr(
         summary,
         positionStart);


   g_logger.Info(
      StringFormat(
         "Résumé positions [1/4] : %s",
         positionsSummary));

   g_logger.Info(
      StringFormat(
         "Résumé performances [2/4] : %s",
         performanceSummary));

   g_logger.Info(
      StringFormat(
         "Résumé capital [3/4] : %s",
         capitalSummary));

   g_logger.Info(
      StringFormat(
         "Résumé position finale [4/4] : %s",
         openPositionSummary));
  }
