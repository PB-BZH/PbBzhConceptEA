PbBzhConceptEA v2.01 - Donchian + position virtuelle

Fichiers à copier :

1) Experts\PbBzhConcept\PbBzhConceptEA_v2_01.mq5
   vers MQL5\Experts\PbBzhConcept\PbBzhConceptEA_v2_01.mq5

2) Include\PbBzhConcept\Signals\DonchianBreakoutSignal.mqh
   vers MQL5\Include\PbBzhConcept\Signals\DonchianBreakoutSignal.mqh

3) Include\PbBzhConcept\Simulation\VirtualDonchianPositionManager.mqh
   vers MQL5\Include\PbBzhConcept\Simulation\VirtualDonchianPositionManager.mqh

Fonctionnement v2.01 :
- entrée Donchian 20 sur clôture H1 ;
- position virtuelle uniquement ;
- SL initial = 2 ATR ;
- aucun TP ;
- sortie LONG si clôture sous le canal bas Donchian 10 ;
- sortie SHORT si clôture au-dessus du canal haut Donchian 10 ;
- risque virtuel = 1 % du capital ;
- aucun trailing ATR dans cette version.
